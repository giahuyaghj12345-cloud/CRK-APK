// Smoke test for CRK's browser-API shim. Run: node tests/bridge.test.cjs
const vm = require('node:vm');
const fs = require('node:fs');
const assert = require('node:assert/strict');
const source = fs.readFileSync('app/src/main/assets/bridge.js','utf8');
const db = {foo: {value: 1}};
const messages=[];
const native={
 getStore(keys){const q=JSON.parse(keys);const result={};
  const list=q===null?Object.keys(db):typeof q==='string'?[q]:Array.isArray(q)?q:Object.keys(q);
  for(const k of list)if(Object.hasOwn(db,k))result[k]=db[k];
  return JSON.stringify(result);
 },
 setStore(json){Object.assign(db,JSON.parse(json));},
 removeStore(json){const k=JSON.parse(json);for(const x of Array.isArray(k)?k:[k])delete db[x];},
 clearStore(){for(const k of Object.keys(db))delete db[k];},
 getActiveTab(){return JSON.stringify({id:1,url:'https://chatgpt.com/c/00000000-0000-0000-0000-000000000000'});},
 message(kind,msg,id){messages.push({kind,msg:JSON.parse(msg),id});},
 reply(id,payload){messages.push({reply:id,payload:JSON.parse(payload)});},
 setAlarm(){},getAlarm(){return 'null'},clearAlarm(){return true},copyText(){}
};
const ctx={window:null, AndroidCRK:native, setTimeout, console,
 location:{hostname:'chatgpt.com',pathname:'/c/'},navigator:{}};
ctx.window=ctx;
vm.createContext(ctx);
vm.runInContext(source,ctx);
(async()=>{
 assert.equal(ctx.chrome.runtime.getManifest().version,'1.1.1');
 assert.equal((await ctx.chrome.storage.local.get('foo')).foo.value,1);
 await ctx.chrome.storage.local.set({hello:[1,2]});
 assert.equal(JSON.stringify((await ctx.chrome.storage.local.get('hello')).hello),'[1,2]');
 await ctx.chrome.storage.local.remove('foo');
 assert.equal((await ctx.chrome.storage.local.get('foo')).foo,undefined);
 let alarmName;
 ctx.chrome.alarms.onAlarm.addListener(x=>alarmName=x.name);
 ctx.__crkFireAlarm('rpgmb-cloud-sync');
 assert.equal(alarmName,'rpgmb-cloud-sync');
 const promise=ctx.chrome.tabs.sendMessage(1,{type:'rpgmb-inspect'});
 assert.equal(messages[0].kind,'content');
 ctx.__crkResult(messages[0].id,JSON.stringify({ok:true,found:5}));
 assert.equal((await promise).found,5);
 let received;
 ctx.chrome.runtime.onMessage.addListener((msg,sender,send)=>{received=msg;send({ok:true});return true;});
 ctx.__crkReceive(JSON.stringify({type:'ping'}),'incoming1');
 assert.equal(received.type,'ping');
 assert.equal(messages[1].payload.ok,true);
 await ctx.chrome.storage.local.clear();
 assert.deepEqual(Object.keys(db),[]);
 console.log('CRK bridge tests OK');
})().catch(e=>{console.error(e);process.exitCode=1});
