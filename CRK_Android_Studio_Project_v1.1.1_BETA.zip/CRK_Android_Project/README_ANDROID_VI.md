# CRK RAW Keeper Android (bản chuyển đổi thử nghiệm từ Chrome extension v1.1.1)

## Trạng thái

- Đây là **MÃ NGUỒN dự án Android**, **CHƯA PHẢI APK**.
- Chưa có Android SDK / trình giả lập trong môi trường tạo dự án nên chưa thể build hay xác minh APK thực tế.
- Ứng dụng thử nghiệm sử dụng WebView ChatGPT và một WebView CRK riêng.
- Dữ liệu RAW lưu vào SQLite cục bộ riêng của ứng dụng Android, **không đọc được kho Chrome extension cũ**. Hãy xuất JSON từ extension và nhập lại nếu cần. Sao lưu trước khi thử.
- Cloud/Supabase chạy trong WebView của ứng dụng khi ứng dụng mở; **không có đồng bộ khi ứng dụng đã đóng**, không bảo đảm dịch vụ nền.
- Đăng nhập ChatGPT trong Android WebView **có thể bị giới hạn**, đặc biệt với OAuth / Đăng nhập bằng Google. Chưa kiểm chứng.
- Script bắt RAW vốn dựa vào DOM trang ChatGPT desktop. Trên giao diện mobile, những bộ chọn DOM có thể khác; **chưa xác minh thu thập/Edit/Retry đúng trên thiết bị thật**.

## Tạo APK với Android Studio

1. Mở **Android Studio**, chọn **Open** và chọn thư mục dự án này.
2. Cài Android SDK 35 (được Android Studio hướng dẫn) và JDK 17.
3. Chờ Gradle tải Android Gradle Plugin 8.8.2; cần Internet.
4. Chọn **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. APK debug sẽ xuất hiện tại `app/build/outputs/apk/debug/app-debug.apk`.
6. Chép APK vào điện thoại Android 10+ (API 29+), cho phép cài từ nguồn này nếu cần.

## Hoặc tạo APK bằng GitHub Actions

1. Đẩy nguyên nội dung dự án (kể cả thư mục `.github`) lên một repository GitHub riêng tư.
2. Vào tab **Actions**, chọn **Build CRK Android APK**, bấm **Run workflow**.
3. Sau khi workflow chạy thành công, tải artifact `CRK-RAW-Keeper-Android-debug-APK`.
4. Giải nén artifact để lấy `app-debug.apk`. APK debug chỉ dùng thử; APK phân phối chính thức cần khóa ký riêng.

## Cách dùng và kiểm tra

1. Mở ứng dụng, đăng nhập ChatGPT bằng phương pháp mà WebView chấp nhận.
2. Mở một hội thoại test có URL dạng `https://chatgpt.com/c/<chat-uuid>`.
3. Chuyển sang tab **📦 CRK** để tạo Campaign, gán hội thoại, kiểm tra diagnostic.
4. Trở lại tab ChatGPT, mở thêm nội dung hội thoại, quan sát dữ liệu RAW được cập nhật trong CRK.
5. Sao lưu JSON, kiểm tra nhánh Active Timeline, rồi **trên chat test** thực hiện Edit/Retry và đối chiếu bằng mắt trước khi dùng chat thật.
6. Chỉ bật Cloud sau khi bạn đã kiểm tra dữ liệu cục bộ. Đồng bộ cloud chỉ thực hiện khi ứng dụng chạy.
7. File TXT / JSON xuất ra sẽ nằm ở `Downloads/CRK_RAW_Keeper`.

## Quyền và dữ liệu

- Chỉ yêu cầu quyền mạng; không yêu cầu đọc toàn bộ tệp điện thoại.
- SQLite cục bộ lưu bằng dữ liệu ứng dụng, không dùng shared cloud khác trừ Supabase do chính bạn cấu hình. Cấu hình Supabase/refresh token lưu cục bộ **chưa được mã hóa bằng Android Keystore**.
- `android:allowBackup="false"` để Android không sao lưu tự động kho CRK sang đám mây.
- Cửa sổ chat được chạy trong WebView riêng, không chia sẻ cookie với Chrome của điện thoại.
- Ứng dụng dùng JavaScript bridge với hạn chế các khóa lưu trữ mà trang ChatGPT có thể truy cập. **Chưa có kiểm toán bảo mật**, không xem là bản sản xuất.

## Các khác biệt với extension Chrome

- Không có Chrome `Manifest V3 service worker` thật. `cloud.js` được chạy trong WebView ẩn và shim các API Chrome cần thiết.
- Alarm chỉ hoạt động trong vòng đời Activity Android; khi ứng dụng bị hệ thống ngừng thì không đảm bảo.
- Không có chức năng gắn extension lên tab Chrome bên ngoài ứng dụng. Chỉ thu thập trong màn hình ChatGPT tích hợp.
- Những hành vi khác của mobile ChatGPT và cơ chế đăng nhập cần kiểm chứng độc lập.
