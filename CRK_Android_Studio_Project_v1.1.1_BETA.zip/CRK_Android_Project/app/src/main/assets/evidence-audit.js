// v0.9.25. Content equality is not turn identity. This module reports repeated
// DOM text and collapses cross-device copies only if an ENTIRE viewport is
// corroborated position by position (same chat, URL, signature, role, token).
(function(root){
 'use strict';
 const norm=s=>String(s||'').replace(/\r\n?/g,'\n').replace(/\u00a0/g,' ').trim();
 function metrics(occurrences){
  const list=Array.isArray(occurrences)?occurrences:[],seen=new Set();let repeatText=0;
  for(const o of list){const k=(o?.role||'')+'\u001f'+norm(o?.text);if(seen.has(k))repeatText++;else seen.add(k);}
  return {observations:list.length,distinctRoleText:seen.size,repeatedRoleText:repeatText,
   caution:'Trùng nguyên văn không chứng minh cùng một lượt. Không xóa hoặc gộp theo văn bản.'};
 }
 function sameFrame(a,b){
  return !!a&&!!b&&a.chatId===b.chatId&&a.sourceUrl===b.sourceUrl&&
   a.campaignId===b.campaignId&&
   // A USER-only mobile viewport has no GM context. Identical short choices
   // are not sufficient cross-device identity evidence, even if every word
   // matches. Keep both observations for branch review instead of aliasing.
   Array.isArray(a.turns)&&a.turns.some(t=>t.role==='user')&&a.turns.some(t=>t.role==='assistant')&&
   Array.isArray(b.turns)&&b.turns.some(t=>t.role==='user')&&b.turns.some(t=>t.role==='assistant')&&
   typeof a.signature==='string'&&a.signature.length===64&&a.signature===b.signature&&
   Array.isArray(a.turns)&&a.turns.length>0&&a.turns.length===b.turns?.length&&
   a.turns.every((t,i)=>t?.token&&t.token===b.turns[i]?.token&&t.role===b.turns[i]?.role);
 }
 // Return unchanged JSON-compatible evidence for an immutable backup. We do not
 // throw away alternate/retry versions, even if their text is identical.
 function merge(local,remote,chatId,sourceUrl){
  const old=local||{},incoming=remote||{},isGood=o=>o&&o.sourceChatId===chatId&&o.sourceUrl===sourceUrl&&
   typeof o.observationId==='string'&&['user','assistant'].includes(o.role)&&typeof o.text==='string';
  const occurrences=[...(old.provisionalOccurrences||[])],frames=[...(old.viewportEvidence||[])];
  const byId=new Map(occurrences.map(x=>[x.observationId,x]));
  const ids=new Set(frames.map(x=>x.frameId));const aliases=new Map();const conflicts=[];
  const remoteFrames=(incoming.viewportEvidence||[]).filter(f=>f?.chatId===chatId&&f.sourceUrl===sourceUrl&&Array.isArray(f.turns));
  for(const remoteFrame of remoteFrames){
   // Exact viewport repeated on two devices: the same positions were visible.
   // Only accept alias if both observations have identical role and text.
   const match=frames.find(f=>sameFrame(f,remoteFrame));
   if(!match)continue;
   for(let i=0;i<remoteFrame.turns.length;i++){
    const r=remoteFrame.turns[i],l=match.turns[i];
    if(!r?.observationId||!l?.observationId||r.observationId===l.observationId)continue;
    const src=(incoming.provisionalOccurrences||[]).find(o=>o.observationId===r.observationId);
    const dst=byId.get(l.observationId);
    if(!isGood(src)||!isGood(dst)||src.role!==dst.role||norm(src.text)!==norm(dst.text))continue;
    const prev=aliases.get(r.observationId);
    if(prev&&prev!==l.observationId){aliases.delete(r.observationId);conflicts.push({reason:'ambiguous-cross-frame-alias',id:r.observationId});}
    else aliases.set(r.observationId,l.observationId);
   }
  }
  let addedOccurrences=0,mergedDuplicates=0,addedFrames=0;
  for(const o of incoming.provisionalOccurrences||[]){
   if(!isGood(o))continue;
   const alias=aliases.get(o.observationId);
   if(alias&&alias!==o.observationId){mergedDuplicates++;continue;}
   const before=byId.get(o.observationId);
   if(!before){occurrences.push(o);byId.set(o.observationId,o);addedOccurrences++;}
   else if(norm(before.text)!==norm(o.text)||before.role!==o.role||before.campaignId!==o.campaignId)
    conflicts.push({reason:before.campaignId!==o.campaignId?'same-observation-id-different-campaign':'same-observation-id-different-content',id:o.observationId,localText:before.text,remoteText:o.text,localRole:before.role,remoteRole:o.role,localCampaign:before.campaignId||null,remoteCampaign:o.campaignId||null});
  }
  for(const f of remoteFrames){
   if(!f.frameId||ids.has(f.frameId))continue;
   const turns=f.turns.map(t=>({...t,observationId:aliases.get(t.observationId)||t.observationId}));
   if(turns.some(t=>t.observationId&&!byId.has(t.observationId)))continue;
   const normalizedFrame={...f,turns};
   if(frames.some(existing=>sameFrame(existing,normalizedFrame)))continue;
   frames.push(normalizedFrame);ids.add(f.frameId);addedFrames++;
  }
  return {occurrences,frames,addedOccurrences,mergedDuplicates,addedFrames,conflicts};
 }
 root.RPGMBEvidenceAudit={metrics,merge,sameFrame};
})(typeof globalThis==='undefined'?self:globalThis);
