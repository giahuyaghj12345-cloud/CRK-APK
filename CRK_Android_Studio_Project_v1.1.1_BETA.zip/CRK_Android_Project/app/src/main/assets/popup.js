const $=s=>document.getElementById(s), P='rpgmb:', C='rpgmb-campaigns-v04', A='rpgmb-assign-v04', Q='rpgmb-proposals-v05';
const SECTIONS=['GM_RULE','WORLD_BUILDING','CANON_STATE','NPC','char_dev','RAW_CHAT','REVISION_LOG'];let chats=[],campaigns={},assign={},matches=[],proposals=[];
const EXT_VERSION=chrome.runtime.getManifest().version;
const DELETED_CAMPAIGNS='rpgmb-deleted-campaigns-v095';
const DELETED_KEY='rpgmb-deleted-campaign-v095:';
const SELECTED_CAMPAIGN='rpgmb-selected-campaign-v096';
const BRANCH_CHOICES='rpgmb-local-branch-choices-v0934';
const DETACHED_CHOICES='rpgmb-local-detached-choices-v103';
let branchChoices={},detachedChoices={};
let selectedCampaign=null,scopedCache=new WeakMap();
let forensicCache=new WeakMap();
const analyzed=c=>{let x=forensicCache.get(c);if(!x){x={};forensicCache.set(c,x);}return x.analysis||(x.analysis=RPGMBTimeline.analyze(c));};
const projected=c=>{let x=forensicCache.get(c);if(!x){x={};forensicCache.set(c,x);}return x.projection||(x.projection=RPGMBTimeline.project(c,{selectedPathId:branchChoices[(c.campaignScopeId||current())+'|'+c.chatId],selectedDetachedId:detachedChoices[(c.campaignScopeId||current())+'|'+c.chatId]}));};
const versionNode=document.getElementById('extension-version');if(versionNode)versionNode.textContent='v'+EXT_VERSION;
const stamp=()=>new Date().toISOString(); const info=s=>{ $('notice').textContent=s; if(!document.querySelector('.view[data-view="memory"]').classList.contains('active')){ let n=document.getElementById('flash'); if(!n){n=document.createElement('div');n.id='flash';n.className='hint';document.querySelector('.view.active')?.prepend(n);}n.textContent=s;} }; 
async function persist(){
 // Keep familiar local Save UI and scoped Cloud objects in one storage transaction.
 // Never upload the old global C/A/Q maps: a fresh-chat test must not leak old campaigns.
 const before=await chrome.storage.local.get(null);
 // Tombstones are authoritative for LOCAL Save too. A popup left open during
 // Cloud sync must not resurrect a deleted Campaign on its next Save click.
 const deleted=before[DELETED_CAMPAIGNS]||{};
 for(const id of Object.keys(campaigns))if(deleted[id])delete campaigns[id];
 for(const id of Object.keys(assign))if(deleted[assign[id]])delete assign[id];
 proposals=proposals.filter(p=>!deleted[p?.campaignId]);
 const next={[C]:campaigns,[A]:assign,[Q]:proposals};
 for(const [id,value] of Object.entries(campaigns)){
   const k=RPGMBMeta.campaignKey(id);next[k]=await RPGMBMeta.prepare('campaign',id,value,before[k]);
 }
 for(const [chatId,campaignId] of Object.entries(assign)){
   const k=RPGMBMeta.assignKey(chatId);next[k]=await RPGMBMeta.prepare('assign',chatId,campaignId,before[k]);
 }
 const groups={};for(const p of proposals)if(p?.campaignId&&campaigns[p.campaignId]){
  (groups[p.campaignId]??=[]).push(p);
 }
 for(const [id,items] of Object.entries(groups)){
   const k=RPGMBMeta.proposalKey(id);next[k]=await RPGMBMeta.prepare('proposals',id,items,before[k]);
 }
 await chrome.storage.local.set(next);
}
function current(){return $('campaign').value;}
function campaignView(chat,id){
 if(!chat)return null;
 let scoped=scopedCache.get(chat);if(!scoped){scoped=new Map();scopedCache.set(chat,scoped);}
 if(!scoped.has(id))scoped.set(id,RPGMBCampaignScope.scope(chat,id));
 return scoped.get(id);
}
function campaignChats(id){return chats.filter(c=>assign[c.chatId]===id && !RPGMBBranch.isCheckpoint(campaigns[id],c.chatId)).map(c=>campaignView(c,id));}
function campaignAudit(id){
 const linked=chats.filter(c=>assign[c.chatId]===id&&!RPGMBBranch.isCheckpoint(campaigns[id],c.chatId));
 return linked.reduce((a,chat)=>{
  const b=RPGMBCampaignScope.audit(chat,id);
  for(const key of Object.keys(a))a[key]+=b[key]||0;
  return a;
 },{assignedObservations:0,assignedFrames:0,assignedNative:0,unattributedObservations:0,otherCampaignObservations:0,unattributedFrames:0,otherCampaignFrames:0,unattributedNative:0,otherCampaignNative:0,legacyRaw:0});
}

function scopedEvidence(chat){return (chat.provisionalOccurrences||[]).filter(o=>RPGMBSafe.trustedOccurrence(o,chat.chatId));}
function raw(id){
 // Ordered by ChatGPT viewport overlaps, NOT the time each block was first seen.
 // Unresolved branches are deliberately excluded from a seamless RAW stream.
 const assigned=campaigns[id]?.chatOrder||[];
 const list=campaignChats(id).sort((a,b)=>{
  const ai=assigned.indexOf(a.chatId),bi=assigned.indexOf(b.chatId);
  return (ai<0?1e9:ai)-(bi<0?1e9:bi);
 });
 return list.flatMap(c=>{
  const view=analyzed(c),native=RPGLedger.ledger(c).messages;
  return [
   ...native.map((m,i)=>({c,m:{...m,position:i,verified:true,kind:'NATIVE_VERIFIED'}})),
   ...view.ordered.map((o,i)=>({c,m:{id:o.observationId,role:o.role,text:o.text,
    position:i,sourceTurn:null,firstSeen:o.firstSeen,kind:'DOM_OBSERVED',verified:false}}))
  ];
 });
}
function selectedRaw(id,mode='candidate'){
 if(mode==='strict')return raw(id);
 const items=[];
 for(const c of campaignChats(id)){
  const turns=mode==='reviewed'?RPGMBPathReview.reviewedTurnsSync(c):projected(c).turns;
  for(const [i,o] of turns.entries())items.push({c,m:{id:o.observationId,role:o.role,text:o.text,position:i,
   kind:mode==='reviewed'?'USER_REVIEWED_DOM_LOCAL':'OBSERVED_CANDIDATE_NOT_CANON',verified:false}});
 }
 return items;
}
function saveRawText(id,limit=Infinity){
 const reviewed=selectedRaw(id,'reviewed'),candidate=selectedRaw(id,'candidate');
 const entries=reviewed.length?reviewed:candidate.length?candidate:raw(id);
 const disclaimer=reviewed.length?'[RAW DOM DO NGƯỜI DÙNG CHỌN CỤC BỘ; CHƯA XÁC MINH UUID/NHÁNH CHATGPT. KHÔNG PHẢI CANON TỰ ĐỘNG.]\n\n':candidate.length?'[RAW TỰ ĐỘNG TỪ DOM; THỨ TỰ ỨNG VIÊN CÓ THỂ SAI SAU EDIT/THỬ LẠI. KHÔNG ĐƯỢC XEM LÀ ACTIVE PATH/CANON ĐÃ XÁC MINH. GIỮ JSON ĐỂ KIỂM CHỨNG.]\n\n':'';
 return disclaimer+entries.slice(-limit).map(({c,m})=>
 `[CHAT ${c.chatId} | ${m.role.toUpperCase()} | ${m.kind||'PROVISIONAL'} | ${m.id} | ${m.verified?'NATIVE SOURCE VERIFIED':'DOM ONLY, UUID UNVERIFIED'}]\n${m.text}`).join('\n\n');
}
function fillOptions(el,items,keep){el.replaceChildren();for(const [val,name] of items){let o=document.createElement('option');o.value=val;o.textContent=name;el.append(o);}if(items.some(([v])=>v===keep))el.value=keep;}
function fillChatOptions(el,campaignId,keep){
 el.replaceChildren();const empty=document.createElement('option');empty.value='';empty.textContent='-- Chọn hội thoại, không tự chọn --';el.append(empty);
 for(const [title,list] of [['Đã gán vào campaign',chats.filter(c=>assign[c.chatId]===campaignId)],['Chat khác / chưa gán',chats.filter(c=>assign[c.chatId]!==campaignId)]]){
  if(!list.length)continue;const group=document.createElement('optgroup');group.label=title;
  for(const x of list){const opt=document.createElement('option');opt.value=x.chatId;const matched=campaignView(x,campaignId);opt.textContent=`${x.title||x.chatId} (${matched?.messages?.length||0}+${matched?scopedEvidence(matched).length:0} RAW thuộc Campaign)${assign[x.chatId]===campaignId?' ✓':''}`;group.append(opt)}el.append(group);
 }
 el.value=chats.some(c=>c.chatId===keep)?keep:'';
 document.getElementById('assign').disabled=!el.value||!campaigns[campaignId]||assign[el.value]===campaignId;
}
function sectionsRefresh(){let id=current(),sec=$('section').value;let isRaw=sec==='RAW_CHAT';$('section-text').value=isRaw?saveRawText(id):(campaigns[id]?.sections?.[sec]||'');$('section-text').readOnly=isRaw;$('raw-help').hidden=!isRaw;$('save-section').disabled=isRaw;}
function renderSearch(showNotice=false){
 const id=current(),query=$('query').value.toLocaleLowerCase().trim(),mode=$('memory-source')?.value||'candidate';
 matches=selectedRaw(id,mode).filter(({m})=>!query||m.text.toLocaleLowerCase().includes(query));
 $('results').replaceChildren();
 for(const {c,m} of matches.slice(-30).reverse()){
  const d=document.createElement('div');d.className='result',title=document.createElement('div');title.className='meta';
  title.textContent=`${c.title||c.chatId} • ${m.role} • ${m.kind||'DOM_PROVISIONAL'} • #${(m.position??0)+1}`;
  const p=document.createElement('div');p.className='excerpt';p.textContent=m.text.slice(0,1000);d.append(title,p);$('results').append(d);
 }
 if(showNotice)info(`${matches.length} kết quả trong nguồn: ${mode==='strict'?'RAW xác minh':mode==='reviewed'?'DOM người dùng duyệt':'ỨNG VIÊN DOM (chưa xác minh)'}. Không suy ra nhánh active chỉ từ kết quả tìm kiếm.`);
}
// Evidence-only access: preserves every unresolved observation without calling
// it canon, sending it to RAW_CHAT, Day auto-save, memory packs or Cloud.
let visibleEvidence=[];
function evidenceOnly(id){
 const result=[];
 for(const c of campaignChats(id)){
  const view=analyzed(c);
  for(const [segmentIndex,seg] of view.segments.entries()){
   if(seg.kind!=='unresolved')continue;
   for(const o of seg.turns)result.push({c,o,segmentIndex,kind:'UNRESOLVED_EVIDENCE'});
  }
  for(const o of view.orphanObservations||[])
   result.push({c,o,segmentIndex:-1,kind:'PARTIAL_USER_ONLY'});
 }
 return result;
}
function renderEvidence(){
 const el=$('evidence-results'),count=$('evidence-count');if(!el||!count)return;
 const query=$('evidence-query').value.trim().toLocaleLowerCase();
 const all=evidenceOnly(current()),found=all.filter(x=>!query||x.o.text.toLocaleLowerCase().includes(query));
 visibleEvidence=found.slice(-12).reverse();el.replaceChildren();
 count.textContent=`${all.length} lượt CHỨNG CỨ chưa phân giải · ${found.length} kết quả khớp · hiển thị ${visibleEvidence.length} mục gần cuối. Chưa xác nhận nhánh hiện hành.`;
 for(const {c,o,segmentIndex,kind} of visibleEvidence){
  const d=document.createElement('div');d.className='result evidence-result';
  const head=document.createElement('div');head.className='meta';
  head.textContent=kind==='PARTIAL_USER_ONLY'
   ? `KHUNG USER THIẾU GM · CHƯA NỐI · ${c.title||c.chatId}`
   : `CHỨNG CỨ, KHÔNG PHẢI CANON · ${o.role} · cụm ${segmentIndex+1} · ${c.title||c.chatId}`;
  const body=document.createElement('div');body.className='excerpt';body.textContent=o.text.slice(0,1200);
  d.append(head,body);el.append(d);
 }
}

// Explicit, read-only export of a non-canonical working reconstruction.
// Never feed this into RAW_CHAT/Day/memory/Cloud, or mark source UUID verified.
function projectionChats(){
 const cid=current(),preferred=campaigns[cid]?.chatOrder||[];
 return campaignChats(cid).sort((a,b)=>{
  const x=preferred.indexOf(a.chatId),y=preferred.indexOf(b.chatId);
  return (x<0?1e9:x)-(y<0?1e9:y);
 }).map(c=>({c,projection:projected(c)}));
}
function projectedText(items,tail=Infinity){
 const sections=['CRK CAMPAIGN RAW KEEPER · TIMELINE ỨNG VIÊN (CHỈ QUAN SÁT DOM) · v'+EXT_VERSION,
  'CẢNH BÁO: KHÔNG PHẢI CANON / ACTIVE PATH ĐÃ XÁC MINH. Không xác minh đầy đủ lịch sử hoặc UUID ChatGPT.',
  'Dựa trên chồng lấn khung DOM; không sắp theo giờ trong truyện/giờ ghi nhận.',
  'CHỈ DÙNG ĐỂ ĐỐI CHIẾU CHAT GỐC. JSON giữ nguyên tất cả bản cũ và nhánh.'];
 for(const {c,projection:p} of items){
  sections.push('===== CHAT '+c.chatId+' | '+c.title+' =====');
  if(p.retroFork)sections.push('⚠️ SỬA GIỮA LỊCH SỬ TẠI LƯỢT #'+(p.retroFork.pivot+1)+': '+(p.retroFork.requiresChoice?'CHƯA CHỌN NHÁNH. CHỈ XUẤT PHẦN CHUNG.':'ĐÃ CHỌN NHÁNH CỤC BỘ '+p.branchChoice+'. KHÔNG PHẢI XÁC MINH UUID.'));
  sections.push('Bản dựng ứng viên '+p.turns.length+'/'+p.observationCount+' quan sát, '+p.frameCount+' khung; '+p.unused.length+' bằng chứng khác chưa chọn; '+p.issues.length+' điểm cần xem xét.');
  if(!p.connected)sections.push('⚠️ Có khung không nối được/chèn giữa không đủ neo. KHÔNG suy ra chuỗi hoàn chỉnh.');
  const begin=Math.max(0,p.turns.length-tail);
  p.turns.slice(begin).forEach((o,i)=>sections.push('[ỨNG VIÊN '+(begin+i+1)+' | '+o.role+' | '+o.observationId+' | '+o.captureStatus+' | DOM ONLY, UUID CHƯA XÁC MINH]\n'+o.text));
  if(tail===Infinity&&p.unused.length)sections.push('[KHÔNG ĐƯA VÀO BẢN DỰNG TẠM: '+p.unused.length+' QUAN SÁT. CÒN NGUYÊN TRONG CAMPAIGN JSON. ID: '+p.unused.map(o=>o.observationId).join(', ')+']');
 }
 return sections.join('\n\n');
}
// Automatically readable, locally captured RAW. It intentionally does not claim
// that a DOM candidate is the ChatGPT server's active branch or canonical UUID path.
function autoRawText(items,{audit=false}={}){
 if(items.some(x=>x.projection?.detachedTail?.count))return RPGMBWorkingRaw.generate(items,EXT_VERSION,{audit});
 const out=['CRK CAMPAIGN RAW KEEPER · RAW TỰ ĐỘNG TỪ DOM · v'+EXT_VERSION,
  'CẢNH BÁO: ĐÂY LÀ LỊCH SỬ ĐÃ QUAN SÁT, ĐƯỜNG XẾP ỨNG VIÊN; CHƯA XÁC MINH NHÁNH ĐANG HOẠT ĐỘNG/UUID CHATGPT.',
  'Không sắp theo thời gian trong câu chuyện; không tự gộp Retry/Edit thành canon. Backup JSON bảo toàn tất cả chứng cứ.'];
 for(const {c,projection:p} of items){
  out.push('===== '+(c.title||c.chatId)+' · CHAT '+c.chatId+' · '+p.turns.length+' lượt =====');
  if(p.detachedTail)out.push('⚠️ CỤM RAW RỜI: '+p.detachedTail.count+' quan sát trong đường mới CHƯA CÓ NEO nối với TXT. KHÔNG tự nối vì có thể thiếu các lượt ở giữa. Xuất riêng qua nút đối chiếu.');
  if(p.coreIntegrity?.unlinkedRecentFrames)out.push('⚠️ CORE V1: Có '+p.coreIntegrity.unlinkedRecentFrames+' khung mới gần đuôi chưa nối vào nhánh được chọn. Đối chiếu ChatGPT gốc, giữ Backup JSON.');
  if(p.coreIntegrity?.tailCompletion==='plausibly-streaming')out.push('⚠️ GM cuối có thể chưa hoàn chỉnh; tiếp tục Capture và đối chiếu.');
  if(p.retroFork)out.push('⚠️ RETRO EDIT TẠI LƯỢT #'+(p.retroFork.pivot+1)+': '+(p.retroFork.requiresChoice?'CHƯA CHỌN NHÁNH: TXT CHỈ CÓ PHẦN CHUNG, PHẦN SAU VẪN TRONG JSON.':'ĐÃ CHỌN NHÁNH TRÊN MÁY NÀY ('+p.branchChoice+'); CHƯA XÁC MINH UUID/ACTIVE PATH.'));
  if(p.branchOptions?.some(b=>b.kind==='retry'))out.push('⚠️ GM THỬ LẠI TẠI ĐUÔI CHAT: có các phiên bản GM khác nhau. '+(p.branchChoice?.startsWith('retry:')?'Đã chọn một phương án từ DOM, chưa xác minh active path.':'Đang dùng phiên bản GM trước; có thể chọn phiên bản Thử lại riêng trong tiện ích, KHÔNG tự trộn.') );
  if(p.unused.length||p.issues.length||!p.connected)out.push('⚠️ Có '+p.unused.length+' quan sát chưa đưa vào chuỗi (có thể là quét lặp, Edit/Retry, trạng thái xử lý phụ hoặc khung chưa nối) + '+p.issues.length+' điểm mơ hồ; đối chiếu chat gốc khi cần.');
  p.turns.forEach((o,i)=>out.push('[#'+(i+1)+' · '+(o.role==='user'?'PLAYER':'GM')+(audit?' · '+o.observationId+' · DOM_ONLY':'')+']\n'+o.text));
  if(audit&&(p.auxiliaryStatusObservations||[]).length)out.push('TRẠNG THÁI XỬ LÝ PHỤ (không đếm như GM; vẫn trong JSON): '+p.auxiliaryStatusObservations.map(o=>o.observationId).join(', '));
  if(audit&&p.unused.length)out.push('QUAN SÁT KHÁC (chưa đưa vào đường ứng viên): '+p.unused.map(o=>o.observationId).join(', '));
 }
 return out.join('\n\n');
}
// The hero dashboard counts *selected, exportable candidate turns*, not DOM
// observation events. Viewport scans can record the same displayed message
// several times. Those records are still preserved for Edit/Retry forensics.
function autoRawStats(){
 const items=projectionChats(),{count,player,gm,mainCount,detachedCount,gapCount}=RPGMBWorkingRaw.tally(items),
  captured=items.reduce((n,{c})=>n+scopedEvidence(c).length,0),
  different=items.reduce((n,{projection:p})=>n+p.unused.length,0),
  issues=items.reduce((n,{projection:p})=>n+p.issues.length,0),
  frames=items.reduce((n,{projection:p})=>n+p.frameCount,0),
  repeatedText=items.reduce((n,{c})=>n+RPGMBEvidenceAudit.metrics(scopedEvidence(c)).repeatedRoleText,0),
  partial=items.reduce((n,{projection:p})=>n+(p.orphanObservations?.length||0),0),
  auxiliary=items.reduce((n,{projection:p})=>n+(p.auxiliaryStatusObservations?.length||0),0),
  nativeVerified=campaignChats(current()).reduce((sum,chat)=>sum+RPGLedger.ledger(chat).messages.length,0);
 return {items,count,player,gm,mainCount,detachedCount,gapCount,captured,different,issues,frames,repeatedText,partial,auxiliary,nativeVerified};
}
function activeItems(){return campaignChats(current()).filter(c=>c.activeTimeline?.schema===1&&c.activeTimeline.turns?.length).map(c=>({c}));}
function renderActiveTimeline(){
 const status=$('crk-active-status'),a=$('crk-active-export'),b=$('crk-active-audit');
 if(!status)return;
 const rows=activeItems(),count=rows.reduce((sum,x)=>sum+x.c.activeTimeline.turns.length,0);
 const cut=rows.reduce((sum,x)=>sum+x.c.activeTimeline.generation,0);
 const warnings=rows.reduce((sum,x)=>sum+(x.c.activeTimeline.issues?.length||0),0);
 const backups=rows.reduce((sum,x)=>sum+(x.c.activeTimeline.backups?.length||0),0);
 const recent=rows.at(-1)?.c.activeTimeline;
 const issue=recent?.issues?.at(-1)?.reason;
 status.textContent=count?
   `${count} lượt hiện hành / ${rows.length} chat. ${cut} lần cắt nhánh, ${backups} backup, ${warnings} cảnh báo. Mới nhất: ${recent?.lastOperation||'?'}${issue?' | '+issue:''}. CRK ID không phải UUID ChatGPT.`:
   'Chưa có nhánh CRK mới. Hãy mở chat đã gán và để Capture nhận một khung ổn định. RAW v1.0.13 vẫn giữ nguyên.';
 a.disabled=b.disabled=!count;
}
function renderAutoRaw(){
 const node=$('auto-raw-summary');if(!node)return;
 const m=autoRawStats(),name=campaigns[current()]?.name||'Campaign này';
 node.replaceChildren();
 if(m.items.length){
  const headline=document.createElement('div');headline.className='raw-summary-head';
  const unresolved=m.items.filter(({projection:p})=>p.retroFork?.requiresChoice).length;
  headline.textContent=m.gapCount?`${name}: ${m.count.toLocaleString('vi-VN')} lượt đã ghi nhận · A ${m.mainCount} + B ${m.detachedCount}`:
   unresolved?`${name}: ${m.count.toLocaleString('vi-VN')} lượt chung · ${unresolved} chat cần chọn nhánh`:`${name}: ${m.count.toLocaleString('vi-VN')} lượt dự kiến trong TXT`;
  const detail=document.createElement('div');detail.className='raw-summary-sub';
  detail.textContent=m.gapCount?`${m.player} PLAYER + ${m.gm} GM qua các đoạn có thể xuất. Có ${m.gapCount} khoảng trống chưa xác minh; không coi A + B là canon liền mạch.`:`${m.player} PLAYER + ${m.gm} GM theo chuỗi ứng viên đã nối. Không cộng số lần quét DOM thành lượt hội thoại.`;
  const status=document.createElement('div');status.className='raw-summary-status';
  status.textContent=m.nativeVerified?'Có UUID nguồn được xác minh; các lượt DOM còn lại vẫn là ứng viên.':'Chưa xác minh nhánh đang hoạt động (0 UUID nguồn).';
  if(unresolved)status.textContent='⚠️ Sửa giữa lịch sử: TXT tạm dừng tại điểm rẽ. Chọn nhánh bên dưới để xuất phần sau.';
  else {const pendingRetry=m.items.find(({projection:p})=>p.branchOptions?.some(b=>b.kind==='retry')&&!p.branchChoice?.startsWith('retry:'));
   if(pendingRetry){const r=pendingRetry.projection.branchOptions.find(b=>b.kind==='retry');status.textContent=`⚠️ Phát hiện GM Thử lại ở lượt #${r.pivot+1}: ${pendingRetry.projection.turns.length} lượt đang chọn; có đường ${r.count} lượt để tự đối chiếu và chọn bên dưới.`;}
  }
  if(m.gapCount)status.textContent+=` ⚠️ TXT xuất cả A và B với dấu KHOẢNG TRỐNG. Số ${m.count} là lượt đã quan sát, không phải canon liền mạch.`;
  const repaired=m.items.map(x=>x.c.identityRecovery).filter(Boolean);
  if(repaired.length){
    const copies=repaired.reduce((n,x)=>n+(x.duplicateIdsReconciled||0),0);
    const statuses=repaired.reduce((n,x)=>n+(x.auxiliaryGmStatuses||0),0);
    status.textContent+=` Đối chiếu cục bộ ${copies} ID quan sát bị dựng lại; tách ${statuses} GM xử lý phụ. JSON gốc và Cloud không thay đổi.`;
  }
  const statusCleanup=m.items.reduce((n,x)=>n+(x.c.stateRecovery?.statusObservationsSuppressed||0),0);
  if(statusCleanup)status.textContent+=` Đã đối chiếu ${statusCleanup} trạng thái GM đang xử lý với phản hồi dài cùng vị trí; chỉ loại khỏi TXT ứng viên, giữ nguyên Backup JSON.`;
  // v1.0 integrity is assessed separately from branch choice. Do not label a
  // DOM-only branch as native-verified or claim a repeat scan is a new turn.
  const detached=m.items.filter(x=>x.projection.detachedTail?.count);
  const detPanel=$('detached-tail-panel'),detDesc=$('detached-tail-desc');
  if(detPanel){detPanel.hidden=!detached.length;
   if(detached.length&&detDesc)detDesc.textContent=detached.map(x=>{
    const r=x.projection.detachedTail;
    // Contrast the selected B tail with captured evidence, not with a hardcoded count.
    // New DOM observations may be reload/old branches; never call them new RPG turns.
    const selectedIds=new Set([...(x.projection.turns||[]),...(r.turns||[])].map(o=>o.observationId));
    const tailSeen=String(r.turns?.at(-1)?.firstSeen||'');
    const recent=(x.c.provisionalOccurrences||[]).filter(o=>o.sourceChatId===x.c.chatId&&
      o.campaignId===current()&&o.firstSeen&&tailSeen&&o.firstSeen>tailSeen&&
      !selectedIds.has(o.observationId)&&['user','assistant'].includes(o.role)&&
      !/(?:^|\n)\s*(?:Hủy|Huỷ)\s*\n\s*Gửi\s*$/i.test(String(o.text||'').slice(-200)));
    const newUser=recent.filter(o=>o.role==='user').length,newGM=recent.filter(o=>o.role==='assistant').length;
    const lastFrame=x.c.viewportEvidence?.at(-1)?.at;
    const stamp=lastFrame?new Date(lastFrame).toLocaleString('vi-VN'):null;
    const maxOther=Math.max(0,...(r.branchOptions||[]).map(o=>o.count||0));
    return `Đoạn A: ${x.projection.turns.length} lượt TXT chính · Đoạn B: ${r.count} lượt RAW rời (${r.userCount} PLAYER + ${r.gmCount} GM).\n`+
     `${r.resumedAfterStatus?`Đã thay ${r.resumedAfterStatus} GM xử lý bằng phản hồi đầy đủ. `:''}`+
     `${r.branchOptions?.length>1?'Có nhiều phiên bản Edit/Retry trong RAW rời; chọn bên dưới. ':''}`+
     `${r.lastGMStatus?'GM cuối có thể vẫn đang xử lý. ':''}`+
     `${r.weakTailAnchors?`Đã nối ${r.weakTailAnchors} khung qua mốc GM dài duy nhất (chưa xác minh nhánh nguồn). `:''}`+
     `${maxOther>r.count?`⚠️ Có đường RAW rời khác dài ${maxOther} lượt, hãy đối chiếu và chọn đúng nhánh. `:''}`+
     `${recent.length?`⚠️ Có ${recent.length} quan sát DOM chưa thuộc đường đang xuất, được thấy sau tin cuối B (${newUser} PLAYER + ${newGM} GM). Có thể là Edit/Retry, quét lặp hoặc phần nối bị kẹt; không tự đếm thành lượt. `:''}`+
     `${stamp?`Khung DOM cuối ghi nhận: ${stamp}. `:''}`+
     `Hai đoạn chưa có bằng chứng nối liền, không được cộng thành lượt canon.`;
   }).join('\n\n');
  }
  renderIslandBranchPicker(detached);
  const health=$('core-health');
  if(health){
   const checks=m.items.map(x=>x.projection.coreIntegrity).filter(Boolean);
   const unresolvedCount=checks.filter(x=>x.branchUnresolved).length;
   const notLinked=checks.reduce((n,x)=>n+(x.unlinkedRecentFrames||0),0);
   const recovered=checks.reduce((n,x)=>n+(x.appended||0),0);
   const promoted=checks.reduce((n,x)=>n+(x.prefixPromotions||0)+(x.replacedProgress||0),0);
   const partial=checks.filter(x=>x.tailCompletion==='plausibly-streaming'||x.tailCompletion==='not-confirmed').length;
   const fallback=checks.filter(x=>x.warnings?.includes('CORE_RECOVERY_FALLBACK')).length;
   const detachedLag=m.items.reduce((sum,{c,projection:p})=>{
    const b=p.detachedTail;if(!b?.turns?.length)return sum;
    const used=new Set([...(p.turns||[]),...b.turns].map(o=>o.observationId));
    const at=b.turns.at(-1)?.firstSeen||'';
    const fresh=(c.provisionalOccurrences||[]).filter(o=>o.campaignId===current()&&o.sourceChatId===c.chatId&&
      o.firstSeen&&o.firstSeen>at&&!used.has(o.observationId));
    // At least one PLAYER is stronger evidence than GM renderer updates alone.
    return sum+(fresh.some(o=>o.role==='user')?1:0);
   },0);
   health.dataset.state=(unresolvedCount||notLinked||fallback||detachedLag)?'warn':'safe';
   health.textContent=fallback?`⚠️ ${fallback} hội thoại bị lỗi khi kiểm tra nối RAW. TXT dùng đường dự phòng, hãy giữ Backup JSON.`:
    unresolvedCount?`🌿 ${unresolvedCount} chat đang chờ chọn nhánh. TXT chỉ xuất phần lịch sử chung; không tự đoán canon.`:
    notLinked?`⚠️ ${notLinked} khung gần đuôi có PLAYER chưa vào TXT theo nhánh đã chọn. RAW vẫn được lưu; kiểm tra Edit/Retry và Backup JSON.`:
    detachedLag?`⚠️ ${detachedLag} hội thoại có quan sát PLAYER mới hơn cuối đoạn B đang chọn. Capture đã có bằng chứng, nhưng TXT/nhánh chưa theo kịp. Kiểm tra nhánh RAW rời và Backup JSON.`:
    `✓ Đã kiểm tra tính liên tục của TXT (${recovered} lượt nối thêm; ${promoted} lần thay GM tạo dở). Không có nghĩa đã xác minh nhánh ChatGPT.`;
   if(!unresolvedCount&&!notLinked&&!fallback&&partial)health.textContent+=`\nℹ️ ${partial} phản hồi GM cuối ngắn hoặc có dấu hiệu đang tạo; chưa chứng minh đã hoàn chỉnh.`;
  }
  node.append(headline,detail,status);
 }else {node.textContent='Chưa có chat đã gán Campaign. Gán chat tại tab Campaign rồi mở ChatGPT để tiện ích bắt RAW.';const h=$('core-health');if(h){h.dataset.state='warn';h.textContent='Chưa có RAW trong Campaign này để kiểm tra tính liên tục.';}}
 const num=(id,n)=>{const e=$(id);if(e)e.textContent=Number.isFinite(n)?n.toLocaleString('vi-VN'):'0';};
 const metricLabel=$('metric-candidates-label');if(metricLabel)metricLabel.textContent=m.gapCount?'Lượt RAW xuất được':'Lượt TXT ứng viên';
 num('metric-candidates',m.count);
 num('metric-player',m.player);
 num('metric-gm',m.gm);
 num('metric-uuid',m.nativeVerified);
 const tech=$('raw-diagnostics-body');if(tech)tech.textContent=m.items.length?
  `Đã ghi nhận: ${m.captured} quan sát DOM từ ${m.frames} khung. Đây là bản ghi kỹ thuật, KHÔNG phải ${m.captured} lượt chat.\n`+
  `${m.repeatedText} quan sát có cùng vai và nguyên văn với quan sát khác (không đủ để kết luận là trùng lượt).\n`+
  `${m.different} quan sát chưa được chọn vào TXT, có thể gồm bản quét lặp hoặc phiên bản Edit/Retry; KHÔNG đồng nghĩa thiếu ${m.different} lượt.\n`+
  `${m.partial} quan sát thuộc khung thiếu GM; ${m.issues} điểm cần đối chiếu khi ghép khung.\n`+
  `${m.auxiliary} quan sát trạng thái xử lý ngắn đứng cạnh phản hồi GM hoàn chỉnh được giữ trong JSON, không cộng thành lượt GM ở TXT.\n`+
  `Core v1.0: ${m.items.reduce((n,x)=>n+(x.projection.coreIntegrity?.unlinkedRecentFrames||0),0)} khung nghi chưa nối ở đuôi; ${m.items.reduce((n,x)=>n+(x.projection.coreIntegrity?.replacedProgress||0),0)} GM status thay bằng bản hoàn chỉnh; ${m.items.reduce((n,x)=>n+(x.projection.coreIntegrity?.prefixPromotions||0),0)} GM tạo dở được nâng phiên bản.\n`+
  `Toàn bộ chứng cứ vẫn nằm trong Backup JSON. Không tự xóa hoặc gộp các phiên bản chỉ dựa trên nội dung giống nhau.`:
  'Chưa có dữ liệu kỹ thuật của Campaign này.';
 const capture=$('quick-capture');if(capture){const b=m.items.reduce((n,x)=>n+(x.projection.detachedTail?.count||0),0);
 capture.textContent=b?`RAW xuất được ${m.count} · A ${m.mainCount} + B ${b} (có khoảng trống)`:m.count?`${m.count} lượt trong TXT ứng viên`:m.captured?'Có quan sát, chưa ghép được TXT':m.items.length?'Chưa ghi nhận RAW':'Chưa gán hội thoại';}
 renderActiveTimeline();
 $('auto-raw-export-clean').disabled=!m.count;
 $('auto-raw-export-audit').disabled=!m.count;
 renderRetroBranchPicker(m.items);
}

// v1.0.3: select an alternative ONLY inside the isolated RAW island. Never
// mutate the main timeline, native UUID claims, RAW evidence, or Cloud.
function renderIslandBranchPicker(items){
 const panel=$('island-branch-picker'),chat=$('island-branch-chat'),choice=$('island-branch-choice'),preview=$('island-branch-preview');
 if(!panel||!chat||!choice||!preview)return;
 const forks=items.filter(x=>x.projection.detachedTail?.branchOptions?.length>1);
 panel.hidden=!forks.length;if(!forks.length)return;
 const oldChat=chat.value;
 chat.replaceChildren();
 for(const {c,projection:p} of forks){const option=document.createElement('option');
  option.value=c.chatId;option.textContent=`${c.title||c.chatId} · B ${p.detachedTail.count} lượt`;chat.append(option);}
 chat.value=forks.some(x=>x.c.chatId===oldChat)?oldChat:forks[0].c.chatId;
 const item=forks.find(x=>x.c.chatId===chat.value);choice.replaceChildren();
 for(const entry of item.projection.detachedTail.branchOptions){const option=document.createElement('option');
  option.value=entry.id;option.textContent=`${entry.label} · ${entry.count} lượt`;choice.append(option);}
 const key=current()+'|'+chat.value;
 choice.value=item.projection.detachedTail.branchOptions.some(x=>x.id===detachedChoices[key])?detachedChoices[key]:'';
 updateIslandPreview();
}
function updateIslandPreview(){
 const id=$('island-branch-chat')?.value,choice=$('island-branch-choice'),preview=$('island-branch-preview');
 const candidate=projectionChats().find(x=>x.c.chatId===id)?.projection.detachedTail;
 const option=candidate?.branchOptions.find(x=>x.id===choice.value);
 if(!preview||!option)return;
 preview.textContent=`Đoạn B: ${option.count} lượt. ${option.label}.\n`+
  `Kết thúc: ${(option.lastText||'').slice(0,190)}\n`+
  `⚠️ Không xác minh nhánh ChatGPT đang hoạt động. TXT chính vẫn giữ điểm dừng của đoạn A.`;
}
$('island-branch-chat').onchange=()=>renderIslandBranchPicker(projectionChats().filter(x=>x.projection.detachedTail?.count));
$('island-branch-choice').onchange=updateIslandPreview;
$('island-branch-apply').onclick=async()=>{
 const cid=current(),id=$('island-branch-chat').value,selected=$('island-branch-choice').value;
 const item=projectionChats().find(x=>x.c.chatId===id),opts=item?.projection.detachedTail?.branchOptions||[];
 if(!opts.some(x=>x.id===selected))return info('Phiên bản RAW rời không còn trong Backup. Hãy tải lại tiện ích và kiểm tra.');
 const key=cid+'|'+id;
 if(selected)detachedChoices[key]=selected;else delete detachedChoices[key];
 await chrome.storage.local.set({[DETACHED_CHOICES]:detachedChoices});
 forensicCache=new WeakMap();render();
 $('island-branch-chat').value=id;renderIslandBranchPicker(projectionChats().filter(x=>x.projection.detachedTail?.count));
 info('Đã lưu lựa chọn RAW rời riêng trên máy. JSON, TXT chính và Cloud không thay đổi.');
};

// Local-only branch selection: never declare a last-seen viewport canonical.
// Settings remain device-local and NEVER mutate RAW, Campaign JSON or Supabase.
function renderRetroBranchPicker(items){
 const panel=$('retro-branch-panel'),chatSel=$('retro-branch-chat'),choiceSel=$('retro-branch-choice'),preview=$('retro-branch-preview');
 if(!panel||!chatSel||!choiceSel||!preview)return;
 const forks=items.filter(x=>x.projection.branchOptions?.length);
 panel.hidden=!forks.length;
 if(!forks.length)return;
 const previous=chatSel.value;
 chatSel.replaceChildren();
 for(const {c,projection:p} of forks){const opt=document.createElement('option');opt.value=c.chatId;opt.textContent=(c.title||c.chatId)+' · rẽ từ #'+(p.retroFork.pivot+1);chatSel.append(opt);}
 chatSel.value=forks.some(x=>x.c.chatId===previous)?previous:forks[0].c.chatId;
 const selected=forks.find(x=>x.c.chatId===chatSel.value),p=selected.projection;
 choiceSel.replaceChildren();
 for(const [value,label] of [['','Chưa chọn · chỉ xuất phần chung'],...p.branchOptions.map(x=>[x.id,x.label+' · '+x.count+' lượt'])]){
  const opt=document.createElement('option');opt.value=value;opt.textContent=label;choiceSel.append(opt);
 }
 const key=current()+'|'+selected.c.chatId,stored=branchChoices[key]||'';
 choiceSel.value=p.branchOptions.some(x=>x.id===stored)?stored:'';
 updateRetroPreview();
}
function updateRetroPreview(){
 const chat=$('retro-branch-chat')?.value,select=$('retro-branch-choice'),preview=$('retro-branch-preview');
 if(!chat||!select||!preview)return;
 const c=campaignChats(current()).find(x=>x.chatId===chat),p=c?projected(c):null;
 if(!p?.branchOptions?.length)return;
 const chosen=p.branchOptions.find(x=>x.id===select.value),pivot=p.retroFork.pivot;
 preview.textContent=chosen?`Từ lượt #${pivot+1}: ${chosen.kind==='old'?'nhánh cũ':chosen.kind==='retry'?'GM Thử lại':'nhánh đã sửa'} · ${chosen.count} lượt ứng viên.\nBắt đầu: ${chosen.firstText.slice(0,135)}\nKết thúc: ${chosen.lastText.slice(0,135)}\n${chosen.hasUiChrome?'⚠️ Nhánh này có quan sát PLAYER chứa nút Hủy/Gửi từ lúc Edit; hãy kiểm tra trước khi dùng TXT.\n':''}⚠️ Phải đối chiếu ChatGPT gốc trước khi dùng làm canon.`:
  `Có ${p.branchOptions.length} nhánh tại lượt #${pivot+1}. Chưa chọn: xuất đúng ${pivot} lượt chung, không giả vờ có một đường hội thoại đã xác minh.`;
}
$('retro-branch-chat').onchange=()=>renderRetroBranchPicker(projectionChats());
$('retro-branch-choice').onchange=updateRetroPreview;
$('retro-branch-apply').onclick=async()=>{
 const chatId=$('retro-branch-chat').value,cid=current(),selected=$('retro-branch-choice').value;
 const c=campaignChats(cid).find(x=>x.chatId===chatId),p=c?projected(c):null;
 if(!p?.branchOptions?.length||selected&&!p.branchOptions.some(x=>x.id===selected))return info('Nhánh không tồn tại trong bằng chứng hiện tại.');
 const key=cid+'|'+chatId;
 if(selected)branchChoices[key]=selected;else delete branchChoices[key];
 await chrome.storage.local.set({[BRANCH_CHOICES]:branchChoices});
 forensicCache=new WeakMap();render();
 $('retro-branch-chat').value=chatId;renderRetroBranchPicker(projectionChats());
 info(selected?'Đã chọn nhánh trên máy này. RAW gốc không đổi. Đối chiếu với chat ChatGPT trước khi sử dụng TXT.':'Đã bỏ lựa chọn: TXT sẽ chỉ chứa phần chung khi có Edit giữa lịch sử.');
};
// The popup can stay open while the chat content script captures new turns.
// Export must read the most recent local snapshots instead of the UI's old
// in-memory `chats` array. Only read storage: never mutate RAW on export.
async function refreshedAutoRawStats(){
 const store=await chrome.storage.local.get(null);
 const cid=current();
 chats=Object.entries(store).filter(([k,v])=>k.startsWith(P)&&Array.isArray(v?.messages))
  .map(([,v])=>v).sort((a,b)=>(a.updatedAt||'').localeCompare(b.updatedAt||''));
 campaigns=store[C]&&typeof store[C]==='object'&&!Array.isArray(store[C])?store[C]:{};
 assign=store[A]||{};branchChoices=store[BRANCH_CHOICES]||{};detachedChoices=store[DETACHED_CHOICES]||{};
 forensicCache=new WeakMap();scopedCache=new WeakMap();
 if(campaigns[cid]){$('campaign').value=cid;$('home-campaign').value=cid;}
 return autoRawStats();
}
$('auto-raw-export-clean').onclick=async()=>{
 try{
  const m=await refreshedAutoRawStats();if(!m.count)return info('Chưa có RAW quan sát trong Campaign.');
  downloadText('RPG_RAW_AUTO_DOM_'+stamp().slice(0,10)+'.txt',autoRawText(m.items),'text/plain;charset=utf-8');
  renderAutoRaw();
  info('Đã xuất '+m.count+' lượt'+(m.gapCount?' với '+m.gapCount+' khoảng trống đã đánh dấu':'')+'. '+(m.items.some(x=>x.projection.retroFork?.requiresChoice)?'⚠️ Có nhánh chưa chọn: TXT chỉ chứa phần chung.':'Sau Edit/Retry cần đối chiếu với chat gốc.'));
 }catch(e){info('Lỗi đọc RAW mới nhất: '+e.message);}
};
$('auto-raw-export-audit').onclick=async()=>{
 try{
  const m=await refreshedAutoRawStats();if(!m.count)return info('Chưa có RAW quan sát trong Campaign.');
  downloadText('RPG_RAW_AUTO_DOM_AUDIT_'+stamp().slice(0,10)+'.txt',autoRawText(m.items,{audit:true}),'text/plain;charset=utf-8');
  renderAutoRaw();
  info('Đã xuất dữ liệu mới nhất kèm ID/cảnh báo; các phiên bản cũ còn trong Backup JSON.');
 }catch(e){info('Lỗi đọc RAW mới nhất: '+e.message);}
};
function renderProjection(){
 const count=$('projection-count'),prev=$('projection-preview');if(!count||!prev)return;
 const projects=projectionChats(),total=projects.reduce((v,x)=>v+x.projection.turns.length,0);
 const unused=projects.reduce((v,x)=>v+x.projection.unused.length,0);
 const anomalies=projects.reduce((v,x)=>v+x.projection.issues.length,0);
 count.textContent=`${total} lượt thuộc bản dựng quan sát tạm · ${unused} quan sát khác giữ trong JSON · ${anomalies} mốc cần kiểm tra. Không có chứng thực nhánh hiện hành.`;
 prev.replaceChildren();
 for(const {c,projection:p} of projects)for(const o of p.turns.slice(-3)){
  const d=document.createElement('div');d.className='result';
  const h=document.createElement('div');h.className='meta';h.textContent=`ỨNG VIÊN · ${o.role} · ${c.title||c.chatId}`;
  const body=document.createElement('div');body.className='excerpt';body.textContent=o.text.slice(0,240);
  d.append(h,body);prev.append(d);
 }
}
let pendingReview=null;
function reviewSelected(){
 const chatId=$('review-chat')?.value;
 const c=chats.find(c=>c.chatId===chatId&&assign[c.chatId]===current());return c?campaignView(c,current()):null;
}
function renderReviewPanel(){
 const el=$('review-chat');if(!el)return;
 const prev=el.value,projects=projectionChats();
 fillOptions(el,projects.map(({c})=>[c.chatId,c.title||c.chatId]),prev);
 const c=reviewSelected(),status=$('review-status'),diff=$('review-diff');diff.replaceChildren();
 if(!c){status.textContent='Chưa có chat thuộc Campaign đang chọn.';return;}
 const p=projected(c),s=RPGMBPathReview.pathStatus(c,p);
 const names={'not-reviewed':'CHƯA DUYỆT','current':'ĐÃ DUYỆT, ĐANG KHỚP',
  'appended':'CÓ LƯỢT MỚI CẦN DUYỆT','changed':'ĐƯỜNG QUAN SÁT ĐÃ THAY ĐỔI, CẦN SOÁT NHÁNH','broken':'BẢN DUYỆT KHÔNG CÒN ĐỦ CHỨNG CỨ'};
 status.textContent=`${names[s.kind]||s.kind}\nĐã duyệt: ${s.reviewed} · Ứng viên lúc này: ${s.candidate} · Chưa duyệt thêm: ${s.additional}\n${p.unused.length} quan sát khác được giữ; ${p.issues.length} điểm phiên bản/khung cần xem.${c.reviewedPath?'\nDuyệt lần cuối: '+c.reviewedPath.reviewedAt:''}`;
 function item(title,o){
  const d=document.createElement('div');d.className='result',h=document.createElement('div');h.className='meta';
  h.textContent=title;const b=document.createElement('div');b.className='excerpt';b.textContent=o?.text?.slice(0,420)||'(trống)';d.append(h,b);diff.append(d);
 }
 if(s.kind==='changed'&&s.firstChange!==null){
  const oldId=c.reviewedPath?.ids?.[s.firstChange],before=RPGMBPathReview.observationMap(c).get(oldId);
  item('BẢN ĐÃ DUYỆT tại vị trí #'+(s.firstChange+1),before);
  item('ỨNG VIÊN tại vị trí #'+(s.firstChange+1),p.turns[s.firstChange]);
 }else{
  if(p.turns.length){item('ĐẦU BẢN ỨNG VIÊN #1',p.turns[0]);
   if(p.turns.length>1)item('CUỐI BẢN ỨNG VIÊN #'+p.turns.length,p.turns.at(-1));}
  if(s.kind==='appended')item('LƯỢT MỚI ĐẦU TIÊN #'+(s.reviewed+1),p.turns[s.reviewed]);
 }
 $('review-export').disabled=!c.reviewedPath;
 $('review-copy').disabled=!c.reviewedPath;
 $('review-export-clean').disabled=!c.reviewedPath;
}
$('review-chat').onchange=()=>{pendingReview=null;$('review-agree').checked=false;renderReviewPanel();};
$('review-agree').onchange=()=>{pendingReview=null;};
$('review-approve').onclick=async()=>{
 const c=reviewSelected();if(!c)return info('Chọn hội thoại trước.');
 if(!$('review-agree').checked)return info('Cần tích xác nhận đã đối chiếu với ChatGPT gốc. Không tự suy đoán active branch.');
 const p=projected(c);if(p.retroFork?.requiresChoice)return info('Phát hiện sửa giữa lịch sử. Hãy chọn nhánh rồi mới duyệt RAW.');if(!p.turns.length)return info('Chưa có bản ứng viên để duyệt.');
 const marker=c.chatId+'|'+p.turns.map(o=>o.observationId).join('|');
 if(pendingReview!==marker){
  pendingReview=marker;$('review-status').textContent+=`\n\n⚠️ CHỜ XÁC NHẬN: Nhấn Duyệt lần thứ hai để lưu ${p.turns.length} lượt đang xem.`;return info(`⚠️ Chốt ${p.turns.length} lượt DOM cho ${c.title||c.chatId}? ${p.unused.length} phiên bản khác và ${p.issues.length} điểm cần xem vẫn giữ riêng. Bấm Duyệt LẦN NỮA nếu đã soát đúng.`);
 }
 try{
  const apply=async()=>{
   const key=P+c.chatId,latest=(await chrome.storage.local.get(key))[key];
   if(!latest||!RPGMBSafe.matchesChat(latest,key))throw Error('Hội thoại đổi nguồn hoặc không còn dữ liệu');
   const currentPath=RPGMBTimeline.project(RPGMBCampaignScope.scope(latest,current()),{selectedPathId:branchChoices[current()+'|'+c.chatId]});
   if(c.chatId+'|'+currentPath.turns.map(o=>o.observationId).join('|')!==marker)throw Error('Chat vừa cập nhật. Kiểm tra lại trước khi chốt.');
   const result=await RPGMBPathReview.approve(latest,currentPath,stamp());
   if(result.changed){result.chat.updatedAt=stamp();await chrome.storage.local.set({[key]:result.chat});}
   return {count:currentPath.turns.length,changed:result.changed};
  };
  const result=navigator.locks?.request?await navigator.locks.request('rpgmb-write-'+c.chatId,{mode:'exclusive'},apply):await apply();
  pendingReview=null;$('review-agree').checked=false;await load();$('review-chat').value=c.chatId;renderReviewPanel();
  info(result.changed?`Đã lưu đường DOM người dùng chọn: ${result.count} lượt, có checksum. Bản trước (nếu có) giữ trong lịch sử. Không tự công nhận canon.`:'Bản này đã được duyệt trước đó; không ghi trùng.');
 }catch(e){pendingReview=null;info('Chưa thể duyệt: '+e.message);}
};
function reviewedText(items,tail=Infinity){
 const parts=['CRK CAMPAIGN RAW KEEPER · USER-SELECTED DOM PATH · v'+EXT_VERSION,
 'CHỈ LÀ ĐƯỜNG NGƯỜI DÙNG ĐÃ ĐỐI CHIẾU/CHỌN TỪ DOM. KHÔNG XÁC MINH UUID/ACTIVE BRANCH BỞI CHATGPT.',
 'Không tự trộn phiên bản Edit/Thử lại. Giữ Campaign JSON để tra cứu toàn bộ chứng cứ.'];
 for(const {c,turns} of items){
  const n=turns.length,from=Math.max(0,n-tail);
  parts.push('===== CHAT '+c.chatId+' | '+(c.title||'')+' | REVIEW '+c.reviewedPath.reviewedAt+' | '+n+' lượt =====');
  for(let i=from;i<n;i++)parts.push('[#'+(i+1)+' | '+turns[i].role.toUpperCase()+' | DOM ĐÃ DUYỆT | '+turns[i].observationId+']\n'+turns[i].text);
 }
 return parts.join('\n\n');
}
async function reviewedItems(){
 const c=reviewSelected();if(!c)throw Error('Chưa chọn chat');
 const result=await RPGMBPathReview.reviewedTurns(c);
 if(result.error)throw Error(result.error);
 return [{c,turns:result.turns}];
}
$('review-export').onclick=async()=>{
 try{const items=await reviewedItems(),c=items[0].c;
  downloadText('RAW_USER_REVIEWED_DOM_'+c.chatId+'_'+stamp().slice(0,10)+'.txt',reviewedText(items),'text/plain;charset=utf-8');
  info('Đã yêu cầu xuất RAW DOM do bạn chọn; chưa xác nhận UUID/nhánh active tự động.');
 }catch(e){info('Không xuất được: '+e.message);}
};
$('review-copy').onclick=async()=>{try{await copy(reviewedText(await reviewedItems(),10));}catch(e){info('Không sao chép được: '+e.message);}};
$('review-export-clean').onclick=async()=>{
 try{const items=await reviewedItems(),{c,turns}=items[0];
  const result=['RPG RAW · ĐƯỜNG DOM NGƯỜI DÙNG CHỌN · '+(c.title||c.chatId),
   'Chưa xác minh active path/UUID ChatGPT; đối chiếu chat gốc trước khi dùng làm canon.',
   ...turns.map((m,i)=>`[#${i+1} · ${m.role==='user'?'PLAYER':'GM'}]\n${m.text}`)].join('\n\n');
  downloadText('RPG_RAW_GM_REVIEWED_'+c.chatId+'_'+stamp().slice(0,10)+'.txt',result,'text/plain;charset=utf-8');
  info('Đã yêu cầu xuất TXT gọn cho GM từ các lượt bạn đã duyệt; vẫn ghi cảnh báo nguồn DOM.');
 }catch(e){info('Không xuất được TXT gọn: '+e.message);}
};
function render(){
 let prev=current()||selectedCampaign;
 fillOptions($('campaign'),Object.entries(campaigns).map(([id,c])=>[id,c.name]),prev);
 fillOptions($('home-campaign'),Object.entries(campaigns).map(([id,c])=>[id,c.name]),current());
 let c=current(),missing=!Object.keys(campaigns).length;
 const notice=$('save-recovery-hint');if(notice)notice.hidden=!missing;
 $('assign').disabled=missing;$('save-section').disabled=missing;$('recall').disabled=missing;$('parse-proposal').disabled=missing;
 let prevChat=$('chat').value;fillChatOptions($('chat'),c,prevChat);
 // One analysis per assigned chat. Large ambiguous campaigns have a non-trivial
 // common-anchor calculation; recomputing six times froze some mobile popups.
 const included=campaignChats(c),views=included.map(x=>analyzed(x));
 const sum=key=>views.reduce((n,v)=>n+v[key],0);
 const verifiedNative=included.reduce((n,x)=>n+RPGLedger.ledger(x).messages.length,0);
 const orderedDom=views.reduce((n,v)=>n+v.ordered.length,0);
 const excluded=sum('progressCount'),unresolved=sum('ambiguousCount');
 const partialUserOnly=views.reduce((n,v)=>n+(v.orphanObservations?.length||0),0);
 const islands=views.reduce((n,v)=>n+Math.max(0,v.componentCount-1),0);
 const orderConflicts=sum('orderConflictCount'),replays=sum('possibleReplayCount'),spine=sum('sharedAnchorCount');
  const candidateCount=included.reduce((n,x)=>n+projected(x).turns.length,0);
 const reviewedCount=included.reduce((n,x)=>n+RPGMBPathReview.reviewedTurnsSync(x).length,0);
 const total=included.reduce((n,x)=>n+RPGLedger.ledger(x).messages.length,0);
 const textualRepeats=included.reduce((n,x)=>n+RPGMBEvidenceAudit.metrics(scopedEvidence(x)).repeatedRoleText,0);
 const provenance=campaignAudit(c);
 const unknown=provenance.unattributedObservations+provenance.unattributedNative+provenance.legacyRaw;
 const legacy=included.reduce((n,x)=>n+(x.legacyMessages?.length||0),0);
 const provisional=included.reduce((n,x)=>n+(x.provisionalObservations?.length||0),0);
 const occurrences=included.reduce((n,x)=>n+(x.provisionalOccurrences?.length||0),0);
 const unconfirmed=included.reduce((n,x)=>n+(x.messages||[]).filter(m=>RPGLedger.nativeId(m.id)&&!m.identityVerified).length,0);
 const identityWarnings=included.reduce((n,x)=>n+(x.identityConflicts?.length||0),0);
$('status').textContent=`RAW DOM ĐÃ BẮT: ${included.reduce((n,x)=>n+scopedEvidence(x).length,0)} quan sát · RAW có thứ tự ứng viên: ${candidateCount} lượt\nRAW do bạn duyệt: ${reviewedCount} lượt · RAW xác minh UUID: ${verifiedNative} lượt\n${included.length} hội thoại thuộc Campaign đang chọn (không cộng chat khác)\n${total} lượt UUID nguồn xác minh trong Campaign · ${unconfirmed} ID cũ CHƯA xác minh · ${identityWarnings} cảnh báo ID\n${legacy} bản legacy · ${provisional} quan sát kiểu cũ · ${occurrences} quan sát DOM trong Campaign\n${orderedDom} lượt DOM có bằng chứng thứ tự (CHƯA xác minh UUID) · ${partialUserOnly} USER từ khung thiếu GM (tách riêng) · ${excluded} bản đang sinh/đã mở rộng giữ trong JSON · ${unresolved} lượt thuộc nhánh chưa phân giải · ${islands} khoảng chưa nối · ${orderConflicts} mâu thuẫn thứ tự đã chặn
${spine} mốc chung trong vùng nhánh · ${replays} phản hồi lặp dài cần kiểm tra\n${textualRepeats} quan sát có vai + nội dung trùng nguyên văn (CHƯA chắc cùng lượt; vẫn giữ JSON)
${unknown} chứng cứ cũ CHƯA GẮN Campaign, không cộng vào RAW sạch`;
 const warning=$('unattributed-warning');
 if(warning)warning.textContent=missing?'Chưa có Campaign được chọn. Chọn hoặc khôi phục Campaign trước.':unknown||provenance.otherCampaignObservations?`⚠️ Chỉ thống kê ${campaigns[c]?.name||'Campaign đang chọn'} (ID: ${c}). ${unknown} quan sát/tin native cũ chưa xác định Campaign, ${provenance.otherCampaignObservations} quan sát được gắn Campaign khác đang nằm chung Chat ID: đều KHÔNG được cộng. Backup JSON vẫn giữ dữ liệu này để đối chiếu. Không tự chuyển chủ sở hữu RAW cũ.`:`✅ Các số liệu RAW bên trên chỉ lấy bản ghi có Campaign ID ${c}.`;
sectionsRefresh();renderSearch();renderEvidence();renderProjection();renderAutoRaw();renderReviewPanel();renderProposals();if(window.renderBranch)window.renderBranch();if(missing){$('save-section').disabled=true;$('home-summary').textContent='⚠️ Chưa có Campaign local. Nếu vừa nâng cấp, đừng tạo lại tên cũ hoặc đồng bộ trước khi kiểm tra v0.9.2 / backup JSON.';}else{$('home-summary').textContent='';}refreshHealth().catch(()=>{});}
async function load(){forensicCache=new WeakMap();scopedCache=new WeakMap();const all=await chrome.storage.local.get(null);selectedCampaign=all[SELECTED_CAMPAIGN]||selectedCampaign;branchChoices=all[BRANCH_CHOICES]||{};detachedChoices=all[DETACHED_CHOICES]||{};chats=Object.entries(all).filter(([k,v])=>k.startsWith(P)&&Array.isArray(v?.messages)).map(([,v])=>v).sort((a,b)=>(a.updatedAt||'').localeCompare(b.updatedAt||''));campaigns=all[C]&&typeof all[C]==='object'&&!Array.isArray(all[C])?all[C]:{};assign=all[A]||{};proposals=all[Q]||[];await harvestProposals();// Read-only popup load: do not create new metadata or sync revisions just by viewing Save.
if(selectedCampaign&&campaigns[selectedCampaign])$('campaign').value=selectedCampaign;
const d=all['rpgmb-diagnostic'];$('diag').textContent=d?`Chẩn đoán ${d.version||'?'}: ${d.found??'?'} đoạn, ${d.unknown??'?'} unknown, ${d.method||'?'}; role=${d.metrics?.role??0}, turns=${d.metrics?.turns??0}, markdown=${d.metrics?.markdown??0}. ${d.reason||''}`:'Chưa có dữ liệu capture. Mở một chat ChatGPT và tải lại trang.';render();if(window.renderDay)window.renderDay();}
async function refreshHealth(){
 const keys=['rpgmb-cloud-v06','rpgmb-cloud-state-v06','rpgmb-diagnostic','rpgmb-cloud-conflicts-v06','rpgmb-cloud-armed-v0916'];
 const x=await chrome.storage.local.get(keys),c=x[keys[0]],st=x[keys[1]]||{},d=x[keys[2]]||{},conf=x[keys[3]]||[];
 const active=!!(c?.refresh_token&&c?.user_id),last=st.lastSuccess?new Date(st.lastSuccess).toLocaleString('vi-VN'):'Chưa có';
 const cloud=!x['rpgmb-cloud-armed-v0916']?'⛔ Cloud bị khóa an toàn sau clean':!active?'Cloud chưa đăng nhập':st.status==='ok'?`Cloud đã xác minh: ${last} · RAW chờ: ${st.pendingRawCount??'?'}`:`Cloud ${st.status||'chưa sync'} · ${st.error||'Chưa có lần xác nhận thành công'}`;
 const diagnostic=d.time?`Lần ghi nhận từ tab: ${new Date(d.time).toLocaleString('vi-VN')} · ${d.found??'?'} lượt nhìn thấy`:'Chưa có tín hiệu capture ở thiết bị này';
 const mismatch=d.version&&d.version!==EXT_VERSION?`⚠️ Bộ đọc tab: v${d.version}, tiện ích: v${EXT_VERSION}. Hãy tải lại tab ChatGPT một lần.\n`:'';
 const el=$('home-health'); if(el)el.textContent=`${mismatch}${diagnostic}\n${cloud}\n${conf.length} xung đột đang chờ xét. RAW local không đồng nghĩa đã lên cloud. Không cần mở popup để lưu.`;
 const quickCloud=$('quick-cloud');
 if(quickCloud)quickCloud.textContent=!x['rpgmb-cloud-armed-v0916']?'Đang khóa an toàn':!active?'Chưa đăng nhập':st.status==='ok'?'Đã đồng bộ thành công':st.error?'Có lỗi, xem tab Cloud':'Đã bật, chưa xác nhận đồng bộ';
 const cloudDot=$('quick-cloud-indicator');if(cloudDot)cloudDot.className='quick-dot '+(active&&x['rpgmb-cloud-armed-v0916']&&st.status==='ok'?'dot-green':'dot-amber');
}
async function chooseCampaign(cid){
 if(!campaigns[cid])return;
 selectedCampaign=cid;await chrome.storage.local.set({[SELECTED_CAMPAIGN]:cid});
 $('campaign').value=cid;cleanupCampaignPending=null;$('chat').value='';
 render();if(window.renderDay)window.renderDay();
}
$('refresh').onclick=load;
$('campaign').onchange=()=>chooseCampaign($('campaign').value);
$('home-campaign').onchange=()=>chooseCampaign($('home-campaign').value);$('section').onchange=sectionsRefresh;$('chat').onchange=()=>{pendingMove=null;$('assign').disabled=!$('chat').value||!campaigns[current()]||assign[$('chat').value]===current();};$('memory-source').onchange=()=>renderSearch(false);$('query').oninput=()=>renderSearch(false);$('search').onclick=()=>renderSearch(true);
$('evidence-query').oninput=renderEvidence;$('evidence-search').onclick=renderEvidence;
$('gap-review-export').onclick=async()=>{
 await refreshedAutoRawStats();
 const items=projectionChats();
 const content=globalThis.RPGMBGapReview?.generate(items,EXT_VERSION);
 if(!content)return info('Campaign hiện tại chưa có cụm RAW rời được phát hiện.');
 downloadText('RPG_RAW_GAP_REVIEW_NOT_CANON_'+current()+'_'+stamp().slice(0,10)+'.txt',content,'text/plain;charset=utf-8');
 info('Đã xuất bản đọc hai đoạn với cảnh báo khoảng trống. KHÔNG tự ghép hoặc thay đổi TXT chính / JSON / Cloud.');
};
$('detached-tail-export').onclick=async()=>{
 await refreshedAutoRawStats();
 const items=projectionChats().filter(x=>x.projection.detachedTail?.count);
 if(!items.length)return info('Không tìm thấy cụm RAW rời trong Campaign đang xem.');
 const lines=['CRK CAMPAIGN RAW KEEPER v1.0.3 · ĐOẠN RAW RỜI ĐỂ ĐỐI CHIẾU',
 '⚠️ KHÔNG PHẢI CANON. Chưa có bằng chứng nối liền với TXT được chọn. Có thể thiếu lượt ở khoảng trống. Không tự nhập vào nhánh chính.',
 '⚠️ Nếu đang sửa tin PLAYER, bản cuối có thể là nhánh chưa có GM phản hồi. Đối chiếu đúng hội thoại trên ChatGPT trước khi sử dụng.'];
 for(const {c,projection:p} of items){const r=p.detachedTail;
  lines.push('===== '+(c.title||c.chatId)+' | '+r.count+' lượt RỜI | '+r.userCount+' PLAYER + '+r.gmCount+' GM =====');
  lines.push('CẢNH BÁO: Bắt đầu cụm rời '+r.firstPreview+' | Kết thúc '+r.lastPreview);
  if(r.pendingEdit)lines.push('⚠️ Có sửa tin PLAYER gần cuối. Nhánh cũ vẫn nằm trong Backup JSON; chưa xác minh nhánh đang hoạt động.');
  r.turns.forEach((o,i)=>lines.push('[RỜI '+(i+1)+' · '+(o.role==='user'?'PLAYER':'GM')+' · '+o.observationId+' · CHƯA NỐI]\n'+o.text));
 }
 downloadText('RPG_RAW_DETACHED_REVIEW_'+current()+'_'+stamp().slice(0,10)+'.txt',lines.join('\n\n'),'text/plain;charset=utf-8');
 info('Đã xuất đoạn RAW rời để đối chiếu. Không tự ghép vào TXT chính hoặc Cloud.');
};
$('projection-export').onclick=()=>{
 const items=projectionChats();if(!items.length)return info('Chưa có hội thoại trong Campaign.');
 downloadText('OBSERVED_CANDIDATE_NOT_CANON_'+current()+'_'+stamp().slice(0,10)+'.txt',projectedText(items),'text/plain;charset=utf-8');
 info('Đã yêu cầu xuất TXT ỨNG VIÊN. Không thay thế RAW canon. Giữ JSON để kiểm tra các nhánh.');
};
$('projection-copy').onclick=()=>copy(projectedText(projectionChats(),10));
$('evidence-copy').onclick=()=>{if(!visibleEvidence.length)return info('Không có chứng cứ nào đang hiển thị.');copy(visibleEvidence.map(({c,o,segmentIndex})=>`[CHỨNG CỨ CHƯA PHÂN GIẢI | CHAT ${c.chatId} | ${o.role} | ${o.observationId} | cụm ${segmentIndex+1}]\n${o.text}`).join('\n\n'));};
let cleanupCampaignPending=null;
$('keep-only-campaign').onclick=async()=>{
 const selected=current();if(!selected||!campaigns[selected])return info('Hãy chọn Campaign cần giữ.');
 const victims=Object.keys(campaigns).filter(id=>id!==selected);
 if(!victims.length)return info('Đang chỉ có một Campaign. Không cần dọn.');
 if(cleanupCampaignPending!==selected){
   cleanupCampaignPending=selected;
   $('export').click(); // Trigger a FULL backup download, never delete RAW.
   return info(`Đã yêu cầu tải Backup JSON. Kiểm tra file đã tải, rồi bấm lại để chỉ giữ ${campaigns[selected].name}. ${victims.length} Campaign khác sẽ bị ẩn/xóa khỏi danh sách local và đánh dấu xóa cho Cloud. RAW chat gốc vẫn giữ.`);
 }
 try{
  const before=await chrome.storage.local.get([DELETED_CAMPAIGNS]);
  const deleted={...(before[DELETED_CAMPAIGNS]||{})},now=stamp(),records={};
  const nextCamps={...campaigns},nextAssign={...assign};
  for(const id of victims){
   delete nextCamps[id];deleted[id]={deletedAt:now,reason:'explicit-user-cleanup'};
   records[DELETED_KEY+id]={format:'rpgmb-campaign-tombstone-v095',campaignId:id,deletedAt:now};
  }
  for(const [chat,id] of Object.entries(nextAssign))if(victims.includes(id))delete nextAssign[chat];
  const nextProposals=proposals.filter(p=>!victims.includes(p?.campaignId));
  await chrome.storage.local.set({...records,[DELETED_CAMPAIGNS]:deleted,
    [C]:nextCamps,[A]:nextAssign,[Q]:nextProposals});
  campaigns=nextCamps;assign=nextAssign;proposals=nextProposals;
  cleanupCampaignPending=null;
  await load();$('campaign').value=selected;render();
  info(`Đã giữ ${campaigns[selected].name}, ẩn ${victims.length} Campaign khác và tạo dấu xóa cho Cloud. Không xóa nội dung RAW. Cloud sẽ truyền dấu xóa khi được bật và đồng bộ.`);
 }catch(e){cleanupCampaignPending=null;info('Không dọn được Campaign: '+e.message);}
};
$('create-campaign').onclick=async()=>{let name=$('new-campaign').value.trim();if(!name)return info('Hãy nhập tên campaign');let id='camp-'+Date.now();campaigns[id]={name,sections:{},createdAt:stamp()};await persist();render();$('campaign').value=id;render();if(window.renderDay)window.renderDay();$('new-campaign').value='';info('Đã tạo campaign. Chọn hội thoại rồi bấm Gán chat.');};
let pendingMove=null;
$('assign').onclick=async()=>{if(!campaigns[current()])return info('Chưa có Campaign. Nếu vừa nâng cấp, hãy phục hồi từ v0.9.2 hoặc backup JSON trước.');let chat=$('chat').value;if(!chat)return info('Chưa có chat để gán');if(assign[chat]&&assign[chat]!==current()&&pendingMove!==chat+'|'+current()){pendingMove=chat+'|'+current();return info('⚠️ Chat này đang ở '+(campaigns[assign[chat]]?.name||assign[chat])+'. Bấm Gán chat LẦN NỮA để chuyển sang Campaign hiện tại. RAW gốc không đổi.');}pendingMove=null;assign[chat]=current();{const id=current();const order=Array.isArray(campaigns[id]?.chatOrder)?campaigns[id].chatOrder.filter(x=>x!==chat):[];order.push(chat);campaigns[id].chatOrder=order;}await persist();render();if(window.renderDay)window.renderDay();info('Đã gán chat vào campaign; RAW của chat này sẽ hiện ở đây.');};

// Read-only chat identity check; never infer an ID from a shared link, page text,
// previously stored records, or a different tab. This does not enable capture.
async function activeChatContext(){
 const [tab]=await chrome.tabs.query({active:true,currentWindow:true});
 const raw=tab?.url||'';
 if(!tab)return {tab:null,chatId:null,reason:'Không tìm thấy tab đang hoạt động trong cửa sổ hiện tại.'};
 if(!raw)return {tab,chatId:null,reason:'Trình duyệt chưa cung cấp URL của tab hiện tại. Kiểm tra quyền truy cập ChatGPT và thử Reload tiện ích / tab.'};
 let url;try{url=new URL(raw);}catch{return {tab,chatId:null,reason:'URL của tab không hợp lệ.'};}
 if(url.protocol!=='https:'||url.hostname!=='chatgpt.com')return {tab,chatId:null,reason:'Tab đang hoạt động không phải https://chatgpt.com. Hãy chọn tab ChatGPT cần lưu.'};
 const chatId=RPGMBSafe.chatIdFromUrl(raw);
 if(chatId)return {tab,chatId,reason:''};
 if(url.pathname.startsWith('/share/'))return {tab,chatId:null,reason:'Đây là liên kết chia sẻ /share/, không phải chat nguồn /c/. Mở cuộc hội thoại của chính bạn.'};
 if(/(?:^|\/)c\//.test(url.pathname))return {tab,chatId:null,reason:'URL có /c/ nhưng không chứa UUID hợp lệ dạng 8-4-4-4-12. Không thể tự suy đoán ID.'};
 if(url.pathname.startsWith('/g/'))return {tab,chatId:null,reason:'Đang ở trang Project/GPT, chưa ở cuộc hội thoại có /c/<UUID>. Mở một chat cụ thể.'};
 return {tab,chatId:null,reason:'Trang ChatGPT này chưa có /c/<UUID> trong URL. Nếu vừa tạo chat, gửi tin đầu tiên và kiểm tra đường dẫn trước khi gán.'};
}
async function showActiveChatStatus(){
 const el=$('active-chat-status');if(!el)return;
 try{
  const ctx=await activeChatContext();
  if(!ctx.chatId){el.textContent='⚠️ CHƯA NHẬN ID\n'+ctx.reason;return;}
  const state=await chrome.storage.local.get([A,C,'rpgmb-capture-paused-v091','rpgmb-fresh-test-v091']);
  const campId=state[A]?.[ctx.chatId],campName=state[C]?.[campId]?.name;
  const test=state['rpgmb-fresh-test-v091'];
  const paused=state['rpgmb-capture-paused-v091']===true;
  const capture=paused?'⏸️ Capture đang tạm dừng':test?.active?(test.allowedChatId===ctx.chatId?'🧪 Chat được phép trong chế độ test':'⛔ Chế độ test đang khóa chat khác'):(campName?'✅ Đã gán Campaign '+campName:'⚠️ Chưa gán Campaign, RAW tự động chưa chạy');
  el.textContent='✅ ĐÃ NHẬN CONVERSATION ID\n'+ctx.chatId+'\n'+capture;
 }catch(e){el.textContent='⚠️ Không đọc được trạng thái ID: '+String(e.message||e);}
}
// A new chat need not be captured first. The active-tab URL is an explicit
// user action that creates a minimal chat placeholder and a scoped assignment.
$('assign-active').onclick=async()=>{
 try{
  const cid=current();if(!campaigns[cid])return info('Hãy tạo/chọn Campaign trước.');
  const ctx=await activeChatContext();
  const {tab,chatId}=ctx;
  if(!chatId){await showActiveChatStatus();return info(ctx.reason);}
  if(assign[chatId]&&assign[chatId]!==cid&&pendingMove!=='active:'+chatId+'|'+cid){
   pendingMove='active:'+chatId+'|'+cid;
   return info('⚠️ Chat này thuộc Campaign khác. Bấm Gán chat đang mở LẦN NỮA để chuyển (RAW không bị xóa).');
  }
  pendingMove=null;
  const key=P+chatId,old=(await chrome.storage.local.get(key))[key];
  if(!old){
   await chrome.storage.local.set({[key]:{chatId,sourceUrl:'https://chatgpt.com/c/'+chatId,
    title:(tab.title||chatId).slice(0,200),createdAt:stamp(),messages:[],
    integrity:{source:'assignment-placeholder',completeHistoryVerified:false}}});
  }
  assign[chatId]=cid;
  // Preserve insertion order across devices instead of sorting chats by a
  // timestamp that can change after reload or Cloud merge.
  campaigns[cid].chatOrder=Array.isArray(campaigns[cid].chatOrder)?campaigns[cid].chatOrder.filter(x=>x!==chatId):[];
  campaigns[cid].chatOrder.push(chatId);
  await persist();await load();$('campaign').value=cid;render();
  await showActiveChatStatus();
  info('Đã gán chat đang mở. Capture chỉ chạy cho các chat thuộc Campaign; hãy tải lại tab một lần nếu cần quét ngay.');
 }catch(e){info('Không gán được chat đang mở: '+String(e.message||e));}
};
$('save-section').onclick=async()=>{if(!campaigns[current()])return info('Chưa có Campaign. Đừng ghi Save mới trước khi kiểm tra bản cũ.');let sec=$('section').value;if(sec==='RAW_CHAT')return info('RAW_CHAT là dữ liệu tự bắt; không sửa trực tiếp.');let id=current();campaigns[id].sections[sec]=$('section-text').value;campaigns[id].updatedAt=stamp();await persist();info('Đã lưu '+sec+' cục bộ. Metadata có khóa Cloud riêng; kiểm tra ☁️ Cloud để xác minh.');};
async function copy(s){try{await navigator.clipboard.writeText(s);info('Đã sao chép. Bạn có thể dán vào ChatGPT.');}catch(e){info('Không sao chép được: '+e.message);}}
$('copy-section').onclick=()=>copy($('section-text').value);
$('copy-results').onclick=()=>copy(matches.slice(-12).map(({c,m})=>`[CHAT ${c.chatId} | ${m.role} | ${m.kind||'DOM_PROVISIONAL'}]\n${m.text}`).join('\n\n'));
$('recall').onclick=()=>{const c=campaigns[current()];if(!c)return info('Chưa có Campaign. Khôi phục bằng JSON backup hoặc v0.9.2 trước.');const s=c.sections||{};const q=$('query').value.trim();const selected=(q?matches:selectedRaw(current(),$('memory-source')?.value||'candidate')).slice(-10);let pack=`[RPG MEMORY PACK | ${c.name} | ${stamp()}]\nCHÚ Ý: Nguồn DOM có thể không đầy đủ hoặc chưa đúng nhánh hiện hành; nếu không có UUID thì không chứng minh canon. Không suy diễn phần thiếu.\n`;
for(const section of ['GM_RULE','WORLD_BUILDING','CANON_STATE','NPC','char_dev','REVISION_LOG'])if(s[section])pack+=`\n[${section}]\n${s[section].slice(0,8500)}\n`;
pack+='\n[RAW RELEVANT]\n'+selected.map(({c,m})=>`[${c.chatId} #${(m.position??0)+1} ${m.role} ${m.kind||'DOM_PROVISIONAL'}]\n${m.text.slice(0,2500)}`).join('\n\n')+'\n[END MEMORY PACK]';copy(pack);};
$('export').onclick=async()=>{const debug=(await chrome.storage.local.get(['rpgmb-cloud-conflicts-v06','rpgmb-cloud-provenance-alerts-v090','rpgmb-import-quarantine-v090']));
 const backup={format:'rpg-memory-bridge-v090',exportedAt:stamp(),campaigns,assign,proposals,chats,conflicts:debug['rpgmb-cloud-conflicts-v06']||[],provenanceAlerts:debug['rpgmb-cloud-provenance-alerts-v090']||[],importQuarantine:debug['rpgmb-import-quarantine-v090']||[]};const url=URL.createObjectURL(new Blob([JSON.stringify(backup,null,2)],{type:'application/json'}));let a=document.createElement('a');a.href=url;a.download='rpg-memory-bridge-'+stamp().slice(0,10)+'.json';a.click();setTimeout(()=>URL.revokeObjectURL(url),20000);info('Đã yêu cầu tải backup JSON. Giữ file này an toàn.');};

function downloadText(name,content,type){
 const url=URL.createObjectURL(new Blob([content],{type}));
 const a=document.createElement('a');a.href=url;a.download=name;a.click();
 setTimeout(()=>URL.revokeObjectURL(url),20000);
}
function campaignCapture(){
 const cid=current(),campaign=campaigns[cid];
 if(!campaign)throw Error('Hãy chọn Campaign.');
 const assigned=Object.keys(assign).filter(id=>assign[id]===cid);
 const ordered=[...(Array.isArray(campaign.chatOrder)?campaign.chatOrder:[]).filter(id=>assigned.includes(id)),
  ...assigned.filter(id=>!campaign.chatOrder?.includes(id))];
 return {cid,campaign,chatIds:[...new Set(ordered)],chats:ordered.map(id=>chats.find(c=>c.chatId===id)).filter(Boolean)};
}
$('export-campaign-json').onclick=async()=>{
 try{
  const x=campaignCapture();
  const obj={format:'rpg-raw-keeper-campaign-v1',exportedAt:stamp(),campaignId:x.cid,
   campaign:x.campaign,chatOrder:x.chatIds,chats:x.chats,
   warnings:['The JSON includes all historical evidence in each linked chat, including unattributed and other-campaign RAW for forensic preservation. Only the UI statistics/TXT are strictly Campaign scoped.','DOM capture does not prove complete ChatGPT history or current response branch.','Some assigned chats may not yet be available locally on this device.','Keep FULL Backup JSON for all legacy and conflict evidence.']};
  downloadText('campaign-'+x.cid+'-'+stamp().slice(0,10)+'.json',JSON.stringify(obj,null,2),'application/json');
  info('Đã yêu cầu xuất JSON Campaign '+x.chatIds.length+' chat. File giữ nguyên evidence, kể cả revisions đã quan sát.');
 }catch(e){info('Lỗi xuất Campaign JSON: '+e.message);}
};
$('export-campaign-txt').onclick=async()=>{
 try{
  const x=campaignCapture(),parts=[];
  parts.push('CRK CAMPAIGN RAW KEEPER · OBSERVED TIMELINE TXT · v'+EXT_VERSION);
  parts.push('Campaign: '+x.campaign.name+' | '+x.cid);
  parts.push('⚠️ CHƯA XÁC MINH ACTIVE PATH / TOÀN BỘ LỊCH SỬ. DOM và nhánh sau Edit/Thử lại chưa có chứng cứ đầy đủ; KHÔNG tự động xác nhận canon.');
  parts.push('Thứ tự bên dưới suy ra từ các khung DOM chồng lấn, KHÔNG từ thời gian quan sát hoặc thời gian trong RPG.');
  parts.push('CHỈ gồm RAW có Campaign ID trùng ID đang chọn. RAW cũ chưa có nguồn và RAW Campaign khác nằm nguyên trong Backup/Campaign JSON, không xuất thành lượt trong TXT này.');
  for(const id of x.chatIds){
   const chat=x.chats.find(c=>c.chatId===id);
   parts.push('\n========== CHAT '+id+' ==========');
   if(!chat){parts.push('[CHƯA CÓ RAW LOCAL TRÊN THIẾT BỊ NÀY]');continue;}
   const scoped=campaignView(chat,x.cid),native=RPGLedger.ledger(scoped).messages,view=RPGMBTimeline.analyze(scoped);
   const forkView=projected(scoped);if(forkView.retroFork)parts.push('⚠️ PHÁT HIỆN SỬA GIỮA LỊCH SỬ #'+(forkView.retroFork.pivot+1)+'. ĐÂY LÀ BẢN FORENSIC CÓ MỌI NHÁNH, KHÔNG PHẢI TXT SẠCH. DÙNG NÚT XUẤT RAW TXT NGAY Ở TỔNG QUAN ĐỂ XUẤT NHÁNH ĐÃ CHỌN.');
   parts.push('[SOURCE: '+(chat.sourceUrl||'unknown')+' | native '+native.length+
     ' | DOM quan sát '+view.totalObservations+' | timeline có neo '+view.distinctPositions+' | khung USER thiếu GM '+(view.orphanObservations?.length||0)+
     ' | phiên bản trung gian '+view.progressCount+' | nhánh chưa rõ '+view.ambiguousCount+' | cạnh thứ tự mâu thuẫn '+view.orderConflictCount+
     ' | phản hồi trùng dài (chưa xét nguồn) '+view.possibleReplayCount+']');
   if(view.orderConflictCount)parts.push('⛔ PHÁT HIỆN '+view.orderConflictCount+' QUAN HỆ THỨ TỰ MÂU THUẪN SAU RELOAD/EDIT/THỬ LẠI. Đã từ chối các cạnh gây vòng để giữ chuỗi quan sát trước đó. ĐƯỜNG HIỆN HÀNH CHƯA ĐƯỢC XÁC NHẬN; kiểm tra JSON và trang ChatGPT.');
   if(view.ambiguousCount && view.sharedAnchors?.length){
    parts.push('[MỐC CHUNG CÓ CHỨNG CỨ THỨ TỰ · '+view.sharedAnchors.length+' mốc. KHÔNG XÁC NHẬN ACTIVE PATH; các bản nhánh có thể thay đổi đường hiện hành.]');
    const shown=view.sharedAnchors.length<=22?view.sharedAnchors:[...view.sharedAnchors.slice(0,10),...view.sharedAnchors.slice(-10)];
    shown.forEach((a,i)=>parts.push('['+(i+1)+' | '+a.role+' | '+a.observationId+'] '+a.text.replace(/\s+/g,' ').slice(0,135)));
    if(shown.length<view.sharedAnchors.length)parts.push('[... '+(view.sharedAnchors.length-shown.length)+' mốc chung khác không hiển thị trong bản tóm lược. JSON giữ toàn bộ.]');
   }
   if(view.possibleReplayCount){
    parts.push('⚠️ CÓ '+view.possibleReplayCount+' PHẢN HỒI DÀI TRÙNG NỘI DUNG NHƯNG KHÁC OBSERVATION ID. Có thể do Retry/Edit hoặc nhận diện lại lúc cuộn. KHÔNG tự xóa/gộp.');
    for(const p of view.possibleReplays.slice(0,12))parts.push('[REPLAY? '+p.earlierId+' <> '+p.laterId+'] '+p.preview.replace(/\s+/g,' '));
   }
   if(view.likelyIncompleteCount)parts.push('⚠️ '+view.likelyIncompleteCount+' phản hồi rất ngắn mang tiêu đề CHAPTER/DAY có dấu hiệu chưa sinh xong. Chỉ cảnh báo, không xóa khỏi evidence.');
   if(view.ambiguousCount&&view.latestFrame){
    const last=view.latestFrame.turns||[],ids=new Map((scoped.provisionalOccurrences||[]).map(o=>[o.observationId,o]));
    parts.push('[KHUNG DOM ĐƯỢC GHI NHẬN CUỐI · '+last.length+' vị trí. Chỉ là một vùng trang được nhìn thấy, KHÔNG phải active path hoàn chỉnh.]');
    for(const t of last.slice(-10)){
     const o=ids.get(t.observationId);
     if(o)parts.push('[FRAME | '+o.role+' | '+o.observationId+'] '+o.text.replace(/\s+/g,' ').slice(0,180));
    }
   }
   if(view.progressCount)parts.push('[LƯU Ý: '+view.progressCount+
     ' bản phản hồi được quan sát khi còn dang dở/đang mở rộng đã được TÁCH khỏi timeline. Vẫn nằm trong JSON.]');
   if((scoped.identityConflicts||[]).length||native.some(m=>(m.revisions||[]).length))
     parts.push('⚠️ Xung đột hoặc revisions native: cần kiểm chứng trước khi dùng làm canon.');
   if(native.length){parts.push('[NATIVE UUID VERIFIED · chưa gộp với DOM provisional nếu chưa có bằng chứng chung]');
    native.forEach((m,i)=>parts.push('['+(i+1)+' | '+m.role+' | NATIVE '+m.id+']\n'+m.text));}
   if(view.segments.length)parts.push('[DOM OBSERVED · các khung được xếp theo quan hệ trước/sau; chưa xác minh UUID nguồn]');
   let n=0;
   view.segments.forEach((segment,index)=>{
    if(view.componentCount>1)parts.push('⚠️ ĐOẠN '+(index+1)+': KHÔNG ĐỦ BẰNG CHỨNG GHÉP THỨ TỰ VỚI ĐOẠN KHÁC.');
    if(segment.kind==='unresolved'){
     parts.push('⛔ PHIÊN BẢN/NHÁNH CHƯA PHÂN GIẢI. KHÔNG nối các lượt sau thành một timeline canon. Các bản sau CHỈ LÀ CHỨNG CỨ:');
     for(const m of segment.turns)parts.push('[UNRESOLVED | '+m.role+' | '+m.observationId+']\n'+m.text);
    }else for(const m of segment.turns){n++;parts.push('[P'+n+' | '+m.role+' | '+m.observationId+']\n'+m.text);}
   });
   if(view.orphanObservations?.length){
    parts.push('⚠️ KHUNG USER THIẾU GM: '+view.orphanObservations.length+
      ' quan sát được một thiết bị đọc mà không thấy phản hồi GM. KHÔNG tự ghép vào timeline; đây có thể là DOM tải thiếu, Edit/Retry hoặc phiên bản cũ. Tất cả vẫn giữ nguyên trong JSON.');
    for(const o of view.orphanObservations)
     parts.push('[PARTIAL USER-ONLY · CHƯA NỐI · '+o.observationId+']\n'+o.text);
   }
   if(view.orderConflictCount||view.possibleAlternatives.length||view.ambiguousCount||view.componentCount>1||view.orphanObservations?.length)
    parts.push('⚠️ CHAT NÀY CÓ ĐƯỜNG QUAN SÁT CHƯA THỂ NỐI/XÁC ĐỊNH. DÙNG JSON VÀ CHAT GỐC ĐỂ SOÁT NHÁNH.');
  }
  downloadText('campaign-'+x.cid+'-'+stamp().slice(0,10)+'.txt',parts.join('\n\n'),'text/plain;charset=utf-8');
  info('Đã yêu cầu xuất Timeline TXT. Phiên bản đang sinh được tách riêng, nhánh chưa rõ không tự ghép. JSON giữ đầy đủ bằng chứng.');
 }catch(e){info('Lỗi xuất Campaign TXT: '+e.message);}
};
$('import').onchange=async e=>{const file=e.target.files?.[0];if(!file)return;
 try{
  let data=JSON.parse(await file.text());
  // Campaign JSON is a portable subset of FULL Backup, not a different
  // database. Reuse the same quarantine and source-identity import checks.
  if(data?.format==='rpg-raw-keeper-campaign-v1'){
   const cid=data.campaignId;
   if(!RPGMBMeta.safeId(cid)||!data.campaign||typeof data.campaign.name!=='string'||
      !data.campaign.sections||typeof data.campaign.sections!=='object'||
      !Array.isArray(data.chatOrder)||!Array.isArray(data.chats))throw Error('Campaign JSON không hợp lệ');
   const ordered=[...new Set(data.chatOrder)];
   if(ordered.some(id=>!RPGMBSafe.recordKey(id)))
    throw Error('Campaign JSON có Chat ID không hợp lệ');
   data={format:'rpg-memory-bridge-v090',campaigns:{[cid]:{...data.campaign,chatOrder:ordered}},
     assign:Object.fromEntries(ordered.map(id=>[id,cid])),chats:data.chats,proposals:[]};
  }
  if(!['rpg-memory-bridge-v05','rpg-memory-bridge-v04','rpg-memory-bridge-v1','rpg-memory-bridge-v090'].includes(data.format)||!Array.isArray(data.chats))throw Error('Không đúng định dạng backup');
  // Legacy aliases and wrong URL/ID attachments are preserved in quarantine,
  // NEVER imported as another real chat's RAW. Valid records are still restored.
  const imported={},quarantine=(await chrome.storage.local.get('rpgmb-import-quarantine-v090'))['rpgmb-import-quarantine-v090']||[];
  let accepted=0,quarantined=0;
  for(const c of data.chats){
    if(!c||typeof c.chatId!=='string'||!Array.isArray(c.messages))throw Error('Backup chat record không hợp lệ');
    const key=RPGMBSafe.recordKey(c.chatId);
    if(!key||(c.sourceUrl&&RPGMBSafe.chatIdFromUrl(c.sourceUrl)!==c.chatId)){
      // One copy of each imported legacy record by full JSON payload.
      const serialized=JSON.stringify(c);if(!quarantine.some(x=>x.serialized===serialized))quarantine.push({serialized,reason:'legacy alias or sourceUrl/chatId mismatch'});
      quarantined++;continue;
    }
    const old=(await chrome.storage.local.get(key))[key];
    imported[key]=RPGMBSafe.mergeChatBackup(old,c);accepted++;
  }
  imported['rpgmb-import-quarantine-v090']=quarantine;
  const nextCampaigns=structuredClone(campaigns),nextAssign={...assign},nextProposals=[...proposals];
  const deletedAlready=(await chrome.storage.local.get(DELETED_CAMPAIGNS))[DELETED_CAMPAIGNS]||{};
  for(const [id,c] of Object.entries(data.campaigns||{})){
    if(deletedAlready[id])continue;
    if(!c||typeof c.name!=='string'||!c.sections)continue;
    if(!nextCampaigns[id])nextCampaigns[id]=c;
    else {if(c.dayIndex&&RPGMBDay.validIndex(c.dayIndex)&&!nextCampaigns[id].dayIndex)nextCampaigns[id].dayIndex=c.dayIndex;
      if(Array.isArray(c.chatOrder)){
        const kept=Array.isArray(nextCampaigns[id].chatOrder)?nextCampaigns[id].chatOrder:[];
        nextCampaigns[id].chatOrder=[...new Set([...kept,...c.chatOrder.filter(id=>RPGMBSafe.recordKey(id))])];
      }
    }
    for(const sec of SECTIONS)if(sec!=='RAW_CHAT'&&!nextCampaigns[id].sections?.[sec]&&typeof c.sections[sec]==='string'){
      nextCampaigns[id].sections??={};nextCampaigns[id].sections[sec]=c.sections[sec];
    }
  }
  for(const [id,cid] of Object.entries(data.assign||{}))if(!deletedAlready[cid]&&nextCampaigns[cid]&&!nextAssign[id])nextAssign[id]=cid;
  const ids=new Set(nextProposals.map(p=>p.id));for(const p of data.proposals||[])if(p?.id&&!ids.has(p.id)){nextProposals.push(p);ids.add(p.id);}
  // Keep the forensic conflict queue and provenance alerts on restoration, too.
  const preserved=await chrome.storage.local.get(['rpgmb-cloud-conflicts-v06','rpgmb-cloud-provenance-alerts-v090']);
  const ownConflicts=preserved['rpgmb-cloud-conflicts-v06']||[],known=new Set(ownConflicts.map(x=>x.id));
  for(const conflict of data.conflicts||[])if(conflict?.id&&!known.has(conflict.id)){ownConflicts.push(conflict);known.add(conflict.id);}
  const ownAlerts=preserved['rpgmb-cloud-provenance-alerts-v090']||[],alertIDs=new Set(ownAlerts.map(x=>x.signature));
  for(const a of data.provenanceAlerts||[])if(a?.signature&&!alertIDs.has(a.signature)){ownAlerts.push(a);alertIDs.add(a.signature);}
  imported['rpgmb-cloud-conflicts-v06']=ownConflicts;
  imported['rpgmb-cloud-provenance-alerts-v090']=ownAlerts;
  // Save one consistent transaction of the imported snapshots, without touching credentials.
  await chrome.storage.local.set(imported);
  campaigns=nextCampaigns;assign=nextAssign;proposals=nextProposals;
  await persist();
  await load();info(`Đã nhập ${accepted} chat; ${quarantined} bản legacy/sai nguồn nằm trong khu cách ly. Không xóa bản gốc; xung đột chưa tự xử lý.`);
 }catch(err){info('Không nhập dữ liệu: '+err.message)}finally{e.target.value='';}
};

// SAVE PROPOSAL PROTOCOL: proposals are text on the page, NOT instructions to the extension.
// All additions to canon require a click; nothing in captured text is executed.
const TOKEN_START='[RPG_SAVE_PROPOSAL]', TOKEN_END='[/RPG_SAVE_PROPOSAL]';
function parseBlocks(text){
  const out=[];let start=0;
  while(true){const a=text.indexOf(TOKEN_START,start);if(a<0)break;const b=text.indexOf(TOKEN_END,a+TOKEN_START.length);if(b<0)break;
    const inner=text.slice(a+TOKEN_START.length,b).trim();start=b+TOKEN_END.length;
    try{const obj=JSON.parse(inner);if(obj&&typeof obj==='object'&&!Array.isArray(obj)&&['GM_RULE','WORLD_BUILDING','CANON_STATE','NPC','char_dev','REVISION_LOG'].includes(obj.target)&&typeof obj.content==='string'&&obj.content.trim()&&obj.content.length<=75000){out.push({target:obj.target,title:String(obj.title||'Mục mới').slice(0,150),content:obj.content.slice(0,75000)});} }catch(e){}
  }
  return out;
}
async function harvestProposals(){
  const ids=new Set(proposals.map(p=>p.id));let changed=false;
  for(const c of chats){const cid=assign[c.chatId];if(!cid)continue;
    for(const m of c.messages||[]){if(m.role!=='assistant')continue;
      const entries=parseBlocks(m.text);
      for(let i=0;i<entries.length;i++){
        const id=`${c.chatId}:${m.id}:${i}`;if(ids.has(id))continue;
        proposals.push({...entries[i],id,campaignId:cid,sourceChat:c.chatId,sourceMessage:m.id,status:'pending',createdAt:stamp()});ids.add(id);changed=true;
      }
    }
  }
  if(changed)await chrome.storage.local.set({[Q]:proposals});
}
function selectedProposal(){return proposals.find(p=>p.id===$('proposal-list').value)}
function renderProposals(){
  const items=proposals.filter(p=>p.campaignId===current());
  const previous=$('proposal-list').value;
  fillOptions($('proposal-list'),items.map(p=>[p.id,`${p.status==='pending'?'⏳':p.status==='approved'?'✅':'❌'} ${p.target}: ${p.title}`]),previous);
  $('proposal-count').textContent=`${items.filter(p=>p.status==='pending').length} đề xuất chờ duyệt · ${items.length} tổng cộng`;
  showProposal();
}
function showProposal(){const p=selectedProposal();$('proposal-target').value=p?.target||'WORLD_BUILDING';$('proposal-title').value=p?.title||'';$('proposal-content').value=p?.content||'';}
$('proposal-list').onchange=showProposal;
$('parse-proposal').onclick=async()=>{
  if(!campaigns[current()])return info('Chưa có Campaign; chưa thể lưu đề xuất.');
  const items=parseBlocks($('proposal-input').value);if(!items.length)return info('Không đọc được khối JSON hợp lệ. Kiểm tra marker, target và content.');
  for(const item of items)proposals.push({...item,id:'manual-'+crypto.randomUUID(),campaignId:current(),status:'pending',createdAt:stamp(),sourceChat:null,sourceMessage:null});
  await persist();renderProposals();$('proposal-input').value='';info(`Đã thêm ${items.length} đề xuất vào hàng chờ. Chưa ghi canon.`);
};
$('approve-proposal').onclick=async()=>{
  const p=selectedProposal();if(!p)return info('Chưa chọn đề xuất.');if(p.status!=='pending')return info('Đề xuất đã xử lý; không áp dụng lại.');
  const target=$('proposal-target').value,title=$('proposal-title').value.trim(),content=$('proposal-content').value.trim();if(!content)return info('Nội dung trống.');
  const camp=campaigns[p.campaignId];if(!camp)return info('Không tìm được campaign.');
  const at=stamp(), entry=`\n\n### ${title||'Mục cập nhật'} [${at}]\n${content}`;
  // Append rather than overwrite; revision log stores provenance and the approved text.
  camp.sections[target]=(camp.sections[target]||'')+entry;
  if(target!=='REVISION_LOG')camp.sections.REVISION_LOG=(camp.sections.REVISION_LOG||'')+`\n\n[${at}] APPROVED ${target} / ${title||'Mục cập nhật'} / proposal=${p.id} / source=${p.sourceChat||'manual'} / content=${JSON.stringify(content)}`;
  p.status='approved';p.approvedAt=at;p.approvedContent=content;p.approvedTarget=target;p.approvedTitle=title;
  await persist();sectionsRefresh();renderProposals();info(`Đã ghi ${target} và cập nhật revision log. Dùng Đối chiếu Cloud để xác minh.`);
};
$('reject-proposal').onclick=async()=>{const p=selectedProposal();if(!p)return info('Chưa chọn đề xuất');if(p.status!=='pending')return info('Đề xuất đã xử lý');p.status='rejected';p.reviewedAt=stamp();await persist();renderProposals();info('Đã từ chối; không thay đổi canon.');};
$('copy-protocol').onclick=()=>copy(`GM: Khi cần đề xuất lưu thông tin vào một trong các kho GM_RULE, WORLD_BUILDING, CANON_STATE, NPC, char_dev, REVISION_LOG, hãy xuất một khối riêng với đúng marker bên dưới. Không xuất cho RAW_CHAT vì extension tự thu thập. Không tự nhận đã lưu; chỉ PLAYER bấm Duyệt & ghi mới trở thành canon. Không chứa các marker lồng nhau.\n[RPG_SAVE_PROPOSAL]\n{"target":"WORLD_BUILDING","title":"Tên mục","content":"Nội dung chi tiết, chưa tự khẳng định ngoài nguồn scene"}\n[/RPG_SAVE_PROPOSAL]\nNếu một phản hồi cần nhiều mục, xuất nhiều khối riêng. Luôn viết diễn biến RPG bình thường trước; chỉ đề xuất cập nhật khi có thông tin mới thực sự cần ghi.`);

// Tab selection stays local to this popup. Never mutates save data.
const allViews=[...document.querySelectorAll('.view')];
function showView(view){if(view==='day'&&window.onDayViewOpen)window.onDayViewOpen();for(const panel of allViews)panel.classList.toggle('active',panel.dataset.view===view);for(const tab of document.querySelectorAll('.tab'))tab.setAttribute('aria-selected',String(tab.dataset.view===view));}
for(const tab of document.querySelectorAll('.tab'))tab.addEventListener('click',()=>showView(tab.dataset.view));
$('quick-cloud-open')?.addEventListener('click',()=>showView('cloud'));
const advancedToggle=$('advanced-toggle'),advancedNav=$('advanced-nav');
advancedToggle?.addEventListener('click',()=>{advancedNav.hidden=!advancedNav.hidden;advancedToggle.setAttribute('aria-expanded',String(!advancedNav.hidden));});
load();
// Live dashboard while popup remains open. The content script still captures without this listener.
// Ignore unrelated keys to avoid rebuilding a large campaign on every Cloud notification.
let rawRefreshDebounce=null,rawRefreshRunning=false,rawRefreshQueued=false;
async function refreshWorkingRawUI(){
 if(rawRefreshRunning){rawRefreshQueued=true;return;}
 if(document.visibilityState!=='visible')return;
 rawRefreshRunning=true;
 try{await refreshedAutoRawStats();renderAutoRaw();}
 catch(e){const h=$('core-health');if(h){h.dataset.state='warn';h.textContent='⚠️ Không tải lại được RAW: '+e.message;}}
 finally{rawRefreshRunning=false;if(rawRefreshQueued){rawRefreshQueued=false;queueRawRefresh();}}
}
function queueRawRefresh(){
 if(rawRefreshDebounce!==null)clearTimeout(rawRefreshDebounce);
 rawRefreshDebounce=setTimeout(()=>{rawRefreshDebounce=null;refreshWorkingRawUI();},1500);
}
chrome.storage.onChanged.addListener((changes,area)=>{
 if(area!=='local')return;
 const linked=new Set(chats.filter(c=>assign[c.chatId]===current()).map(c=>P+c.chatId));
 if(Object.keys(changes).some(key=>linked.has(key)||key===A||key===C))queueRawRefresh();
});
// Refresh only visible metrics while the popup is open; capture/sync themselves work without it.
setInterval(()=>{if(document.visibilityState==='visible')refreshHealth().catch(()=>{});},12000);

// Cloud sync is optional; RAW capture always runs locally. No password persisted by popup.
async function cloudCall(data){return new Promise((resolve,reject)=>{chrome.runtime.sendMessage(data,r=>{if(chrome.runtime.lastError)return reject(Error(chrome.runtime.lastError.message));if(!r?.ok)return reject(Error(r?.error||'Cloud không phản hồi'));resolve(r.result);});});}
async function cloudInfo(){const x=await chrome.storage.local.get(['rpgmb-cloud-v06','rpgmb-cloud-state-v06','rpgmb-cloud-conflicts-v06','rpgmb-cloud-armed-v0916']);const c=x['rpgmb-cloud-v06'],s=x['rpgmb-cloud-state-v06']||{},conflicts=x['rpgmb-cloud-conflicts-v06']||[];$('cloud-url').value=c?.url||'';$('cloud-key').value=c?.key||'';$('cloud-status').textContent=(x['rpgmb-cloud-armed-v0916']?'🟢 Cloud đã bật | ':'⛔ CLOUD ĐANG KHÓA | ')+(c?.user_id?'Đã đăng nhập ('+c.user_id.slice(0,8)+'…)':'Chưa đăng nhập')+' | '+(s.status||'chưa sync')+' | lần thành công: '+(s.lastSuccess||'chưa có')+' | RAW chờ cloud: '+(s.pendingRawCount??'chưa kiểm tra')+' | Save chờ cloud: '+(s.pendingSaveCount??'chưa kiểm tra')+' | snapshot đã xác minh: '+(s.verifiedCount??'chưa kiểm tra')+(s.lastReceivedAt?' | nhận bản từ cloud: '+s.lastReceivedAt:'')+(s.error?' | Lỗi: '+s.error:'');$('cloud-conflicts').textContent=conflicts.length+' xung đột: '+conflicts.filter(x=>x.kind==='CANON').length+' canon, '+conflicts.filter(x=>x.kind!=='CANON'&&x.kind!=='META').length+' RAW/gán chat, '+conflicts.filter(x=>x.kind==='META').length+' Save. Không ghi đè tự động. Dùng Xuất JSON để sao lưu trước khi xử lý.';renderConflict(conflicts);renderOtherConflicts(conflicts);renderMetaConflicts(conflicts);await deliveryInfo();}
async function deliveryInfo(){
 const x=(await chrome.storage.local.get('rpgmb-cloud-upload-report-v080'))['rpgmb-cloud-upload-report-v080'];
 const out=$('cloud-delivery');if(!out)return;
 if(!x){out.textContent='Chưa có báo cáo đồng bộ từng khóa.';return;}
 const errors=(x.entries||[]).filter(e=>e.status==='failed');
 out.textContent=`Báo cáo gần nhất: ${x.at}\nChế độ: ${x.mode}\nĐã có trên cloud: ${x.existing} · Mới gửi: ${x.uploaded} · Cache còn hạn: ${x.cached}\nLỗi: ${x.failed} · Cách ly sai nguồn: ${x.quarantined||0} · Chỉnh sửa trong lúc sync: ${x.changed} · Đang chờ: ${x.pendingCount}`+
  (x.mergeWarning?'\n⚠️ '+x.mergeWarning:'')+
  (errors.length?'\n\nLỗi từng khóa:\n'+errors.map(e=>`${e.key} [${e.httpStatus||'network'}] ${e.error}`).join('\n'):'');
}
$('cloud-login').onclick=async()=>{try{const origin=new URL($('cloud-url').value.trim()).origin;const granted=await chrome.permissions.request({origins:[origin+'/*']});if(!granted)throw Error('Cần cấp quyền truy cập Supabase');const result=await cloudCall({type:'cloud-login',url:$('cloud-url').value.trim(),key:$('cloud-key').value.trim(),email:$('cloud-email').value.trim(),password:$('cloud-password').value});$('cloud-password').value='';info('Đã xác thực '+result.user+'. Bấm Đồng bộ ngay.');await cloudInfo();}catch(e){info('Đăng nhập lỗi: '+e.message)}};
let pendingCloudEnable=false;
$('cloud-enable-sync').onclick=async()=>{
 if(!pendingCloudEnable){pendingCloudEnable=true;return info('⚠️ Bật lại sẽ tải lên mọi RAW LOCAL thuộc chat đã gán. Hãy tắt tiện ích cũ ở cả Android và PC, kiểm tra dữ liệu local rồi bấm nút NÀY LẦN NỮA.');}
 pendingCloudEnable=false;
 try{await cloudCall({type:'cloud-arm'});info('Đã mở khóa Cloud. Bản ghi local được phép đồng bộ tự động; kiểm tra trạng thái sau khi có mạng.');await cloudInfo();}
 catch(e){info('Không mở Cloud được: '+e.message);}
};
$('cloud-disable-sync').onclick=async()=>{
 pendingCloudEnable=false;
 try{await cloudCall({type:'cloud-disarm'});info('Đã khóa Cloud, dữ liệu local giữ nguyên.');await cloudInfo();}
 catch(e){info('Không khóa Cloud được: '+e.message);}
};
function showPeerReport(x){
 const node=$('cloud-pair-status');if(!node)return;
 if(!x?.devices){node.textContent='Chưa có dữ liệu thiết bị. Vào Cloud và bấm kiểm tra.';return;}
 const lines=[`Đối chiếu lúc: ${x.at||'không rõ'} · ${x.scannedSnapshots||0} snapshot`,
   `Thiết bị này: ${String(x.thisDeviceId||'?').slice(0,8)}…`,
   `Thiết bị khác từng gửi dữ liệu: ${x.otherDeviceCount||0}`];
 for(const d of x.devices)lines.push(`${d.isThisDevice?'Máy này':'Máy khác'} [${String(d.deviceId).slice(0,8)}…]: ${d.rawSnapshots} RAW snapshot, ${d.metaSnapshots} Save snapshot · lần gửi gần nhất ${d.lastSnapshot||'không rõ'}`);
 lines.push('Lưu ý: phải chạy gửi/nhận từ cả hai máy để chắc chắn mỗi bên đã nhận dữ liệu mới.');
 node.textContent=lines.join('\n');
}
$('cloud-peers').onclick=async()=>{
 const n=$('cloud-pair-status');n.textContent='Đang đối chiếu các snapshot thuộc tài khoản của bạn…';
 try{const x=await cloudCall({type:'cloud-peers'});showPeerReport(x)}
 catch(e){n.textContent='Không kiểm tra được: '+e.message+'\nHãy kiểm tra URL, đăng nhập, quyền bảng rpg_sync_records và RLS.';}
};
chrome.storage.local.get('rpgmb-cloud-peer-report-v0924').then(x=>showPeerReport(x['rpgmb-cloud-peer-report-v0924']));
$('cloud-sync').onclick=async()=>{try{info('Đang đối chiếu lại các khóa và đồng bộ…');let x=await cloudCall({type:'cloud-sync'});info(x.skipped||x.busy?x.notice:`Đồng bộ hai chiều: nhận ${x.received||0} thay đổi, gửi mới ${x.sent}, đã có ${x.existing}, lỗi ${x.failed}, còn chờ ${x.pending}.`);await load();await cloudInfo();}catch(e){info('Đồng bộ lỗi: '+e.message);await cloudInfo()}};
$('cloud-retry-missing').onclick=async()=>{try{
 const x=await cloudCall({type:'cloud-retry-missing'});
 if(x.busy)info(x.notice);
 else if(x.nothingToRetry)info('Chưa có khóa thiếu trong kết quả Đối chiếu Cloud. Hãy đối chiếu trước.');
 else info(`Đã thử gửi khóa thiếu: ${x.sent} gửi mới, ${x.existing} đã có, ${x.failed} lỗi. Bấm Đối chiếu Cloud để xác nhận lại.`);
 await cloudInfo();
 }catch(e){info('Gửi khóa thiếu lỗi: '+e.message);await cloudInfo();}};
$('cloud-audit').onclick=async()=>{
 const out=$('cloud-audit-result');out.textContent='Đang kiểm tra từng snapshot đã lưu...';
 try{const x=await cloudCall({type:'cloud-audit'});
  const problems=x.entries.filter(e=>e.state!=='confirmed');
  out.textContent=`Đã đối chiếu ${x.total} khóa cục bộ\n✅ Khớp chính xác: ${x.confirmed}\n⚠️ Chưa có trên Cloud: ${x.missing}\n❌ Không khớp: ${x.mismatched}\n🔒 Cách ly sai nguồn/legacy: ${x.quarantined||0}`+
    (problems.length?'\n\nCần xử lý:\n'+problems.map(e=>`${e.state}: ${e.key}`).join('\n'):'\n\nTất cả snapshot hiện tại đã có bản khớp trên cloud.')+
    '\n\nLưu ý: kiểm tra này không chứng minh lịch sử ChatGPT đầy đủ.';
 }catch(e){out.textContent='Đối chiếu thất bại: '+e.message;}
};
$('cloud-logout').onclick=async()=>{await cloudCall({type:'cloud-logout'});await cloudInfo();info('Đã ngắt kết nối; dữ liệu cục bộ giữ nguyên.');};
cloudInfo();

function renderOtherConflicts(items){
 const list=$('conflict-other-list'),out=$('conflict-other-data');if(!list||!out)return;
 const old=list.value;const other=items.filter(c=>c.kind!=='CANON'&&c.kind!=='META');
 fillOptions(list,other.map(c=>[c.id,`${c.kind} / ${c.id}`]),old);
 const c=other.find(c=>c.id===list.value);
 out.value=c?JSON.stringify(c,null,2):'Không có xung đột RAW/gán chat.';
}
$('conflict-other-list').onchange=async()=>{
 const conflicts=(await chrome.storage.local.get('rpgmb-cloud-conflicts-v06'))['rpgmb-cloud-conflicts-v06']||[];renderOtherConflicts(conflicts);
};
$('copy-other-conflict').onclick=()=>copy($('conflict-other-data').value);
function renderConflict(items){
 const list=$('conflict-list');if(!list)return;const curr=list.value;const matches=items.filter(x=>x.kind==='CANON');
 fillOptions(list,matches.map(x=>[x.id,`${x.campaign} / ${x.section} / ${x.seenAt||''}`]),curr);
 const c=matches.find(x=>x.id===list.value);$('conflict-local').value=c?.localText||'';$('conflict-remote').value=c?.remoteText||'';
 if(list.dataset.selected!==list.value){$('conflict-merged').value=c?.remoteText||'';list.dataset.selected=list.value;}
}
function renderMetaConflicts(conflicts){
 const items=conflicts.filter(x=>x.kind==='META');
 const el=$('conflict-meta-list'),previous=el.value;
 fillOptions(el,items.map(x=>[x.id,x.metaKey+' · '+(x.reason||'conflict')]),previous);
 const selected=items.find(x=>x.id===el.value);
 $('conflict-meta-data').value=selected?JSON.stringify({key:selected.metaKey,reason:selected.reason,local:selected.localValue,cloud:selected.remoteValue},null,2).slice(0,40000):'';
 $('conflict-meta-local').disabled=!selected||!selected.remoteRecord;
 $('conflict-meta-remote').disabled=!selected||!selected.remoteRecord;
}
$('conflict-meta-list').onchange=async()=>{
 const c=(await chrome.storage.local.get('rpgmb-cloud-conflicts-v06'))['rpgmb-cloud-conflicts-v06']||[];renderMetaConflicts(c);
};
async function resolveMeta(which){
 const id=$('conflict-meta-list').value;if(!id)return info('Chưa có xung đột Save được chọn');
 try{const r=await cloudCall({type:'cloud-resolve-meta',id,choice:which});
  if(r.saved){await load();await cloudInfo();info('Đã chọn phiên bản '+(which==='local'?'local':'cloud')+' của '+r.key+'. Bấm Đồng bộ ngay để xác minh.');}
 }catch(e){info('Chưa thể xử lý xung đột Save: '+e.message);}
}
$('conflict-meta-local').onclick=()=>resolveMeta('local');
$('conflict-meta-remote').onclick=()=>resolveMeta('remote');
$('conflict-list').onchange=async()=>{const c=(await chrome.storage.local.get('rpgmb-cloud-conflicts-v06'))['rpgmb-cloud-conflicts-v06']||[];renderConflict(c);};
async function resolveConflict(choice){try{const id=$('conflict-list').value;if(!id)return info('Không có xung đột canon để xử lý');
 const result=await cloudCall({type:'cloud-resolve',id,choice,content:$('conflict-merged').value});
 if(result.saved){await load();await cloudInfo();info('Đã giải quyết xung đột cục bộ. Bấm Đồng bộ ngay để gửi phiên bản lên cloud.');}
 }catch(e){info('Không thể giải quyết: '+e.message);}}
$('conflict-use-local').onclick=()=>resolveConflict('local');
$('conflict-use-remote').onclick=()=>resolveConflict('remote');
$('conflict-use-merge').onclick=()=>resolveConflict('manual');

// Inspector is user-initiated. It needs an open ChatGPT tab and does not save inspection reports.
let lastInspection='';
$('inspect-tab').onclick=async()=>{
 const el=$('inspection-result'); el.value='Đang kiểm tra tab đang mở...';
 try{
  const tabs=await chrome.tabs.query({active:true,currentWindow:true});const tab=tabs[0];
  if(!tab?.id||!/^https:\/\/chatgpt\.com\//.test(tab.url||''))throw Error('Hãy mở popup khi đang ở tab chatgpt.com.');
  const response=await chrome.tabs.sendMessage(tab.id,{type:'rpgmb-inspect'});
  if(!response?.ok)throw Error(response?.error||'Content script chưa phản hồi');
  lastInspection=JSON.stringify(response.report,null,2);el.value=lastInspection;
 }catch(e){lastInspection='';el.value='Không kiểm tra được: '+e.message+'\nHãy tải lại tab ChatGPT một lần sau khi cập nhật extension.';}
};
$('copy-inspection').onclick=async()=>{if(!lastInspection)return info('Chưa có chẩn đoán để sao chép.');await copy(lastInspection);};

// Android bottom sheets may block window.confirm() and scroll away the global
// flash. An inline second tap is mandatory, with feedback adjacent to the button.
const RESET_PAUSED='rpgmb-capture-paused-v091';
const RESET_TEST='rpgmb-fresh-test-v091';
const RESET_RECEIPT='rpgmb-factory-reset-receipt-v092';
const statusReset=(message,state='idle')=>{
 const e=$('factory-reset-feedback');e.textContent=message;e.dataset.state=state;
};
let resetBusy=false;
async function showFreshState(){
 const state=await chrome.storage.local.get([RESET_PAUSED,RESET_TEST,RESET_RECEIPT]);
 const mode=state[RESET_TEST],receipt=state[RESET_RECEIPT];
 $('factory-test-state').textContent=state[RESET_PAUSED]===true?
  'THU THẬP ĐANG TẠM DỪNG. Chỉ bật lại sau khi chọn chat test mới.':
  mode?.active?`Chỉ thu thập chat test ${mode.allowedChatId||'(chưa chọn)'}; các chat khác bị bỏ qua.`:
  'Chế độ bình thường. Dữ liệu local chưa chắc trống nếu chưa reset.';
 if(receipt?.cleared && !resetBusy && $('factory-reset-feedback').dataset.state!=='error'){
  statusReset(`✅ Reset local được xác minh lúc ${receipt.at}. Đã xóa ${receipt.deletedKeys} khóa dữ liệu. Cloud không bị xóa.`, 'success');
 }
}
function resetPanel(show){$('factory-confirm-panel').hidden=!show;}
$('factory-reset-local').onclick=()=>{
 if(resetBusy)return;
 resetPanel(true);
 statusReset('Đang chờ xác nhận lần hai. Chưa có dữ liệu nào bị xóa.', 'idle');
};
$('factory-reset-cancel').onclick=()=>{
 if(resetBusy)return;
 resetPanel(false);statusReset('Đã hủy reset. Không có dữ liệu bị xóa.');
};
$('factory-reset-confirm').onclick=async()=>{
 if(resetBusy)return;
 resetBusy=true;resetPanel(false);
 $('factory-reset-local').disabled=true;
 $('factory-start-test').disabled=true;
 $('factory-reset-confirm').disabled=true;
 statusReset('⏳ Đã xác nhận. Đang chặn thu thập và đồng bộ, chờ tiến trình cũ, rồi xóa local…','working');
 try{
  // Freeze capture immediately, even before a service-worker responds.
  await chrome.storage.local.set({[RESET_PAUSED]:true});
  const x=await Promise.race([
   cloudCall({type:'factory-reset-local'}),
   new Promise((_,reject)=>setTimeout(()=>reject(Error('Service worker không phản hồi trong 18 giây. Thu thập đã tạm dừng; dữ liệu chưa được xác nhận xóa.')),18000))
  ]);
  const after=await chrome.storage.local.get(null);
  const remainder=Object.keys(after).filter(k=>![RESET_PAUSED,RESET_TEST,RESET_RECEIPT].includes(k));
  if(!x?.cleared||after[RESET_PAUSED]!==true||after[RESET_TEST]?.allowedChatId!==null||remainder.length){
   throw Error('Không chứng minh được local đã trống. Khóa còn lại: '+remainder.slice(0,5).join(', '));
  }
  await load();await cloudInfo();
  statusReset(`✅ ĐÃ XÓA THÀNH CÔNG. ${x.deletedKeys??'?'} khóa đã xóa. RAW: 0, chat: 0. Giờ tạo chat MỚI, gửi lượt đầu, rồi bấm Bắt RAW.`, 'success');
 }catch(e){
  statusReset('❌ RESET CHƯA XÁC MINH: '+String(e.message||e)+'. Không đồng bộ Cloud. Có thể bấm thử lại.', 'error');
 }finally{
  resetBusy=false;
  $('factory-reset-local').disabled=false;
  $('factory-start-test').disabled=false;
  $('factory-reset-confirm').disabled=false;
  await showFreshState().catch(()=>{});
 }
};
$('factory-start-test').onclick=async()=>{
 try{
  const ctx=await activeChatContext();
  if(!ctx.chatId)throw Error(ctx.reason);
  const result=await cloudCall({type:'factory-start-test',chatId:ctx.chatId,sourceUrl:ctx.tab.url});
  await showFreshState();
  await showActiveChatStatus();
  statusReset('✅ Chỉ bật capture cho chat '+result.chatId+'. Reload chat test một lần.', 'success');
 }catch(e){statusReset('Không bắt đầu được: '+e.message, 'error');}
};
$('factory-exit-test').onclick=async()=>{
 // Keep Android fully inline, including exit from isolated mode.
 if(resetBusy)return;
 if($('factory-exit-test').dataset.confirm!=='yes'){
   $('factory-exit-test').dataset.confirm='yes';
   $('factory-exit-test').textContent='Bấm lại để THOÁT chế độ một chat';
   statusReset('⚠️ Bấm lại nút THOÁT nếu muốn cho phép bắt cả chat cũ.');return;
 }
 try{await cloudCall({type:'factory-exit-test'});await showFreshState();statusReset('Đã trở về thu thập bình thường.','success');}
 catch(e){statusReset('Thoát chế độ test thất bại: '+e.message,'error');}
 finally{$('factory-exit-test').dataset.confirm='';$('factory-exit-test').textContent='Kết thúc chế độ chỉ một chat';}
};
showFreshState();
showActiveChatStatus();

// BETA isolated export, legacy auto-RAW exporters stay available unchanged.
$('crk-active-export').onclick=async()=>{
 await load();
 const rows=activeItems();if(!rows.length)return info('Nhánh hiện hành chưa có lượt nào.');
 downloadText('CRK_ACTIVE_TIMELINE_'+stamp().slice(0,10)+'.txt',
   CRKActiveTimeline.exportText(rows),'text/plain;charset=utf-8');
 info('Đã xuất nhánh hiện hành. Giữ Backup JSON và đối chiếu điểm sửa với ChatGPT.');
};
$('crk-active-audit').onclick=async()=>{
 await load();
 const rows=activeItems();if(!rows.length)return info('Chưa có dữ liệu nhánh hiện hành.');
 downloadText('CRK_ACTIVE_TIMELINE_AUDIT_'+stamp().slice(0,10)+'.txt',
   CRKActiveTimeline.exportText(rows,{audit:true}),'text/plain;charset=utf-8');
 info('Đã xuất nhánh hiện hành kèm CRK ID và cảnh báo.');
};
