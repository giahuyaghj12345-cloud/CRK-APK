// v0.9.35. Conservative repair for multiple historical PLAYER edits whose
// subsequent DOM snapshots have been re-created with completely new IDs.
// This is a read-only working-path builder. It NEVER changes stored RAW,
// never declares a branch to be ChatGPT-native or canon, and never uses RPG
// clock timestamps or short PLAYER choices as independent anchors.
(function(root){
'use strict';
if(!root.RPGMBTimeline)return;
const API=root.RPGMBTimeline, originalProject=API.project;
const norm=s=>String(s||'').replace(/\s+/g,' ').trim();
const digest=s=>{let n=2166136261;for(const c of s){n^=c.charCodeAt(0);n=Math.imul(n,16777619);}return (n>>>0).toString(36);};
function makeAnalyzer(chat){
 const occ=(chat?.provisionalOccurrences||[]).filter(o=>o?.observationId&&
    o.sourceChatId===chat.chatId&&o.sourceUrl===chat.sourceUrl&&
    o.captureOrigin==='live-conversation-dom-v090'&&['user','assistant'].includes(o.role));
 const byId=new Map(occ.map(o=>[o.observationId,o]));
 const frames=(chat?.viewportEvidence||[]).filter(f=>f?.chatId===chat.chatId&&
    f.sourceUrl===chat.sourceUrl&&Array.isArray(f.turns)&&
    f.turns.every(t=>byId.has(t.observationId)));
 const textCache=new Map(occ.map(o=>[o.observationId,norm(o.text)]));
 const roleCache=new Map(occ.map(o=>[o.observationId,o.role]));
 const text=id=>textCache.get(id)||'',role=id=>roleCache.get(id);
 const equal=(a,b)=>role(a)===role(b)&&text(a)===text(b);
 function weight(id){const t=text(id);return role(id)==='assistant'&&t.length>=300?100:
   role(id)==='user'&&t.length>=20?26: t.length>=35?14: 1;}
 // Weighted LCS: strong, verbatim long GM renderers dominate. A one-character
 // reply such as '1' cannot define the offset; it only follows an established
 // multi-GM alignment. Tie-break by proximity to the end of the path.
 function alignment(frame,path){
  const m=frame.length,n=path.length, dp=Array.from({length:m+1},()=>new Float64Array(n+1));
  for(let i=m-1;i>=0;i--)for(let j=n-1;j>=0;j--){
   const skipA=dp[i+1][j],skipB=dp[i][j+1];
   const pair=equal(frame[i],path[j])?weight(frame[i])+dp[i+1][j+1]:-1;
   dp[i][j]=Math.max(skipA,skipB,pair);
  }
  const matches=[];let i=0,j=0;
  while(i<m&&j<n){
   const pair=equal(frame[i],path[j])?weight(frame[i])+dp[i+1][j+1]:-1;
   if(pair>0&&pair>=dp[i+1][j]-0.001&&pair>=dp[i][j+1]-0.001){
    matches.push({i,j,id:frame[i]});i++;j++;
   }else if(dp[i+1][j]>dp[i][j+1])i++;else j++;
  }
  const long=new Set(matches.filter(x=>role(x.id)==='assistant'&&text(x.id).length>=300).map(x=>text(x.id)));
  const stableUsers=matches.filter(x=>role(x.id)==='user'&&text(x.id).length>=20).length;
  const strong=long.size>=2&&matches.length>=4 || long.size>=1&&stableUsers>=3&&matches.length>=6;
  return {matches,longCount:long.size,strong,score:dp[0][0]};
 }
 function appendChunk(target,chunk){
  for(const id of chunk){if(target.includes(id))continue; const last=target.at(-1);
   const old=byId.get(last),newer=byId.get(id);
   if(!newer)continue;
   if(last&&equal(last,id))continue;
   // A renderer is repeatedly expanded while streaming. It is not a Retry.
   if(old?.role==='assistant'&&newer.role==='assistant'&&text(last).length>=40&&
      text(id).startsWith(text(last))&&text(id).length>text(last).length+20){target[target.length-1]=id;continue;}
   target.push(id);
  }
 }
 const auxiliary=new Set();
 for(const f of frames)for(let k=1;k<f.turns.length;k++){
  const a=byId.get(f.turns[k-1].observationId),b=byId.get(f.turns[k].observationId);
  if(a?.role==='assistant'&&b?.role==='assistant'&&norm(a.text).length<500&&
   /^(?:Mình sẽ|Tôi sẽ|Đã xử lý|Đã xác định|Tôi đang)/i.test(norm(a.text))&&
   norm(b.text).length>550)auxiliary.add(a.observationId);
 }
 return {byId,frames,role,text,equal,alignment,appendChunk,auxiliary};
}
function multiEdit(chat,base,options){
 const a=makeAnalyzer(chat), {byId,frames}=a;
 if(base.turns.length<12||frames.length<10)return null;
 const dis=base.issues.filter(i=>i.reason==='disconnected-frame');
 // The old v0.9.34 guard still owns straightforward in-frame anchored edits.
 // This fallback is specifically for a *run* of fully reminted snapshots.
 if(dis.length<3)return null;
 const start=Math.max(0,Math.min(...dis.map(i=>i.frameIndex))-1);
 let serial=0;
 const baseIds=base.turns.map(t=>t.observationId),rootId='before:'+digest(baseIds.slice(0,12).map(x=>a.text(x)).join('\u001f'));
 const paths=[{id:rootId,seq:baseIds,parents:[],pivot:null,firstFi:-1,kind:'old'}];
 const index=new Map([[rootId,paths[0]]]);
 const events=[];
 for(let fi=start;fi<frames.length;fi++){
  const f=frames[fi],incoming=f.turns.map(t=>t.observationId);
  const work=paths.slice();
  const matched=work.map(path=>({path,m:a.alignment(incoming,path.seq)}))
    .filter(x=>x.m.strong).sort((x,y)=>y.m.score-x.m.score);
  if(!matched.length)continue;
  // If a frame exactly matches one candidate, never use the same frame to
  // manufacture an independent fork against other, older candidates.
  // Distinguish an old frame containing common prefix from a real branch
  // update; at least one substantial same-path anchor after the fork matters.
  for(const {path,m} of matched){
   const anchors=m.matches;
   // A fork only comes from a conflicting PLAYER in the same slot immediately
   // after an exact preceding match with two different substantial GM anchors.
   for(const p of anchors){
    const i=p.i+1,j=p.j+1;
    if(i>=incoming.length||j>=path.seq.length)continue;
    if(a.role(incoming[i])!=='user'||a.role(path.seq[j])!=='user'||a.equal(incoming[i],path.seq[j]))continue;
    const before=anchors.filter(x=>x.i<=p.i&&x.j<=p.j);
    const long=new Set(before.filter(x=>a.role(x.id)==='assistant'&&a.text(x.id).length>=300).map(x=>a.text(x.id)));
    if(long.size<2||before.length<4)continue;
    if(before.at(-1).j!==j-1||before.at(-1).i!==i-1)continue;
    // A partial response or repeated numbered choice cannot masquerade as
    // a new PLAYER edit. The old/new USER must be semantically substantial.
    if(Math.max(a.text(incoming[i]).length,a.text(path.seq[j]).length)<15)continue;
    const version=digest(a.text(incoming[i])),newId='edited:'+j+':'+version;
    let child=index.get(newId);
    if(!child){
     if(paths.length>=16)break;
     const seq=path.seq.slice(0,j);
     // Old ChatGPT GM bubbles may linger briefly after an Edit before the
     // replacement response arrives. Never import that stale old tail.
     const edited=[incoming[i]];
     let oldPos=j+1;
     for(const id of incoming.slice(i+1)){
      if(oldPos<path.seq.length&&a.equal(id,path.seq[oldPos]))break;
      edited.push(id);oldPos++;
     }
     appendEdited(seq,edited,a);
     child={id:newId,seq,parents:path.parents.concat([{pivot:j,preview:a.text(incoming[i]).slice(0,95),fi}]),
       pivot:j,firstFi:fi,kind:'new'};
     paths.push(child);index.set(newId,child);
     events.push({pivot:j,fi,previous:a.text(path.seq[j]).slice(0,90),revised:a.text(incoming[i]).slice(0,90),id:newId});
    }
    break;
   }
  }
  // Only a credible alignment at the candidate tail may extend it. A
  // changed GM response in the same last slot can be refreshed; its earlier
  // renderer stays in JSON, never inserted as a separate RPG turn.
  const valid=paths.map(path=>({path,m:a.alignment(incoming,path.seq)})).filter(x=>x.m.strong);
  for(const {path,m} of valid){
   const last=m.matches.at(-1),lastPath=path.seq.length-1;
   if(!last||last.i>=incoming.length-1)continue;
   const fullOther=valid.some(x=>x.path.id!==path.id&&x.m.score>m.score+125&&
       x.m.matches.some(y=>y.i===incoming.length-1));
   if(fullOther)continue;
   if(last.j===lastPath){a.appendChunk(path.seq,incoming.slice(last.i+1));continue;}
   // Renderer refresh at exactly ONE tail GM position. This must have two
   // distinct long GM anchors and a role-identical last bubble, so an edited
   // PLAYER cannot be silently overwritten.
   if(last.j===lastPath-1){
    const next=incoming[last.i+1],old=path.seq[lastPath],gm=m.longCount>=2&&
      a.role(next)==='assistant'&&a.role(old)==='assistant';
    const newer=gm&&byId.get(next),prior=gm&&byId.get(old);
    if(!gm||!newer||!prior)continue;
    // Interim planning renderer followed by a complete final GM. These are
    // two DOM bubbles for one response, not two RPG turns. Require one
    // validated adjacent PLAYER + at least 2 distinct earlier long GMs.
    const isStatus=t=>t.length<550&&/^(?:Mình sẽ|Tôi sẽ|Đã xử lý|Tôi đang|Đã xác định)/i.test(t);
    if(isStatus(a.text(old))){
     const rest=incoming.slice(last.i+1);
     const completed=rest.find(id=>a.role(id)==='assistant'&&a.text(id).length>=700&&
       /^(?:DAY\s+\d+|CHAPTER\s+\d+|OOC\s*[·:-]|GM\s*\/\s*OOC)/i.test(a.text(id)));
     if(completed){path.seq[lastPath]=completed;
      const at=rest.indexOf(completed);a.appendChunk(path.seq,rest.slice(at+1));
      continue;}
    }
    const h=x=>String(byId.get(x)?.text||'').split('\n')[0].trim();
    const hasNextPlayer=incoming.slice(last.i+2).some(id=>a.role(id)==='user');
    const sameSlot=a.text(next).startsWith(a.text(old))||a.text(old).startsWith(a.text(next))||
      (h(next)===h(old)&&h(next).length>=25&&a.text(next).length>=500&&
       (a.text(next).length>=a.text(old).length*1.2||hasNextPlayer));
    if(!sameSlot)continue;
    path.seq[lastPath]=next;
    a.appendChunk(path.seq,incoming.slice(last.i+2));
   }
  }
 }
 if(!events.length)return null;
 // A duplicate scan of a historical branch is evidence, not automatically
 // 'active'. Expose each leaf for manual local choice.
 // Edit-mode textarea can briefly expose a draft with the popup controls
 // 'Hủy / Gửi'. Keep that verbatim RAW in JSON, but never offer it as a
 // clean playable branch while its sibling's final sent PLAYER exists.
 const hasUiDraft=id=>a.role(id)==='user'&&/\n\s*(?:Hủy|Cancel)\s*\n\s*(?:Gửi|Send)\s*$/i.test(String(byId.get(id)?.text||''));
 // A path may contain an older UI-contaminated observation in the middle.
 // Retain it as an explicitly WARNED historical route; only quarantine a
 // terminal, unsent draft from the clean branch chooser.
 const terminalUiDraft=p=>hasUiDraft(p.seq.at(-1));
 const branches=paths.filter(p=>(p.seq.length>p.pivot||p.kind==='old')&&!terminalUiDraft(p))
   .sort((x,y)=> (y.firstFi-x.firstFi)|| (y.parents.length-x.parents.length));
 if(branches.length<2)return null;
 const prefixLen=Math.min(...events.map(x=>x.pivot));
 // All options should have the exact same text/role before this junction.
 const common=baseIds.slice(0,prefixLen);
 if(!branches.every(p=>p.seq.length>=prefixLen&&
    common.every((id,j)=>a.equal(id,p.seq[j]))))return null;
 const show=ids=>ids.filter(id=>!a.auxiliary.has(id)).map(id=>byId.get(id)).filter(Boolean);
 // The pivot exposed to the popup refers to VISIBLE turns, not unfiltered
 // DOM observations. GM status bubbles are kept only as evidence.
 const prefix=show(common),shared=prefix.length;
 const optionList=branches.map(p=>{
  const turns=show(p.seq),positions=p.parents.map(x=>'#'+(show(p.seq.slice(0,x.pivot)).length+1));
  const desc=p.parents.map(x=>x.preview.replace(/\s+/g,' ').slice(0,62)).join(' / ');
  return {id:p.id,kind:p.kind,turns,hasUiChrome:p.seq.some(hasUiDraft),
   firstText:turns[shared]?.text||'',lastText:turns.at(-1)?.text||'',
   label:p.kind==='old'?'Đường trước khi phát hiện nhánh':`Nhánh sửa ${positions.join(' → ')}: ${desc.slice(0,82)}`,
   count:turns.length,pivot:shared,depth:p.parents.length};
 });
 const selected=optionList.find(b=>b.id===options?.selectedPathId);
 const turns=selected?.turns||prefix;
 const chosen=new Set(turns.map(t=>t.observationId));
 return {...base,turns,unused:(chat.provisionalOccurrences||[]).filter(o=>!chosen.has(o.observationId)),
  connected:false,branchChoice:selected?.id||'auto',
  // Internal, read-only branch path IDs: allow discovering nested GM Retries
  // even when the device-local selection was cleared on upgrade/reload.
  // Only observations already captured are referenced; no RAW or canon is changed.
  branchCandidatePaths:optionList.map(p=>({id:p.id,kind:p.kind,
    ids:p.turns.map(o=>o.observationId)})),
  branchOptions:optionList.map(({turns,...v})=>v),
  retroFork:{pivot:shared,count:optionList.length,requiresChoice:!selected,
   multiEditCount:events.length,
   notice:selected?'Nhánh do người dùng chọn; CHƯA xác minh UUID ChatGPT.':
    'Phát hiện các đường hội thoại sửa PLAYER (có thể lồng nhau); TXT mặc định chỉ xuất phần lịch sử chung.'},
  issues:[...base.issues,{reason:'multi-edit-history-branch-withheld',pivot:shared,events:events.length}],
  multiEditEvidence:{events,framesScanned:frames.length-start,options:optionList.length,
   uiDraftsQuarantined:paths.filter(terminalUiDraft).length}};
}
function appendEdited(target,incoming,a){a.appendChunk(target,incoming);}
API.project=function(chat,options={}){
 const base=originalProject(chat,options);
 // Do not disturb the previously verified N10 Retry and retroactive Edit tests.
 if(base.branchOptions?.length)return base;
 try{return multiEdit(chat,base,options)||base;}
 catch(e){return {...base,issues:base.issues.concat([{reason:'multi-edit-detector-error',detail:String(e?.message||e)}])};}
};
API.multiEditPatchVersion='0.9.36';
})(typeof globalThis!=='undefined'?globalThis:this);
