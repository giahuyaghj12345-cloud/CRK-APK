// Build an observed ordering from overlapping DOM frames, never from capture
// timestamps or fictional RPG clock times. No network, storage, or DOM access.
(function(root){
'use strict';
const norm=s=>String(s||'').replace(/\r\n?/g,'\n').replace(/\u00a0/g,' ').trim();
const looksLikeProgress=(older,newer,role)=>role==='assistant'&&
 typeof older==='string'&&typeof newer==='string'&&older.length>=40&&
 newer.length>older.length+20&&newer.startsWith(older);
// Short pre-answer status / planning text can appear as a distinct GM renderer
// while ChatGPT prepares the long actual answer. It is still preserved in RAW
// evidence, but only a frame showing it directly adjacent to the finished GM
// allows excluding it from the clean working TXT candidate.
function looksLikeAuxiliaryStatus(o){
 const value=norm(o?.text);
 return o?.role==='assistant' && value.length>=45 && value.length<=480 &&
  /^(?:Mình sẽ|Tôi sẽ|Đã xác định và xác nhận lệnh tiếp theo)(?:\s|$)/i.test(value);
}
function confirmedAuxiliaryStatusIds(frames,byId){
 const found=new Set();
 for(const frame of frames)for(let i=1;i<frame.turns.length;i++){
  const previous=byId.get(frame.turns[i-1].observationId);
  const next=byId.get(frame.turns[i].observationId);
  if(looksLikeAuxiliaryStatus(previous)&&next?.role==='assistant'&&
    norm(next.text).length>=1200&&next.observationId!==previous.observationId){
   found.add(previous.observationId);
  }
 }
 return found;
}
// A new device may initially render several PLAYER bubbles without ANY GM
// renderer. When this user-only viewport has no shared observation identity
// with an existing mixed-role viewport, it cannot justify a new timeline
// segment. Preserve it in JSON/audit, but quarantine it from ordered RAW.
// A subsequent mixed-role overlap automatically releases the shared IDs.
function partitionPartialFrames(rawOccurrences,rawFrames){
 const occurrences=Array.isArray(rawOccurrences)?rawOccurrences:[];
 const frames=Array.isArray(rawFrames)?rawFrames:[];
 const mixed=frames.filter(f=>Array.isArray(f.turns)&&
   f.turns.some(t=>t.role==='user')&&f.turns.some(t=>t.role==='assistant'));
 const mixedIds=new Set(mixed.flatMap(f=>f.turns.map(t=>t.observationId).filter(Boolean)));
 const orphanFrames=mixed.length ? frames.filter(f=>
   Array.isArray(f.turns)&&f.turns.length>=2&&
   f.turns.every(t=>t.role==='user')&&
   !f.turns.some(t=>mixedIds.has(t.observationId))) : [];
 const orphanFrameIds=new Set(orphanFrames.map(f=>f.frameId));
 const activeFrames=frames.filter(f=>!orphanFrameIds.has(f.frameId));
 const activeIds=new Set(activeFrames.flatMap(f=>f.turns.map(t=>t.observationId).filter(Boolean)));
 const orphanIds=new Set(orphanFrames.flatMap(f=>f.turns.map(t=>t.observationId).filter(Boolean))
   .filter(id=>!activeIds.has(id)));
 return {activeFrames,orphanFrames,
   orphanObservations:occurrences.filter(o=>orphanIds.has(o.observationId)),
   activeOccurrences:occurrences.filter(o=>!orphanIds.has(o.observationId))};
}
function analyze(chat){
 const chatId=chat?.chatId,sourceUrl=chat?.sourceUrl;
 const valid=o=>o&&o.sourceChatId===chatId&&o.sourceUrl===sourceUrl&&
  o.captureOrigin==='live-conversation-dom-v090'&&['user','assistant'].includes(o.role)&&
  typeof o.text==='string'&&!!norm(o.text)&&typeof o.observationId==='string';
 const rawOccurrences=(chat?.provisionalOccurrences||[]).filter(valid);
 const rawById=new Map(rawOccurrences.map(o=>[o.observationId,o]));
 const rawFrames=(chat?.viewportEvidence||[]).filter(f=>f?.chatId===chatId&&f?.sourceUrl===sourceUrl&&
   Array.isArray(f.turns)&&f.turns.every(t=>!!t.observationId&&rawById.has(t.observationId)));
 const partial=partitionPartialFrames(rawOccurrences,rawFrames);
 const occurrences=partial.activeOccurrences,frames=partial.activeFrames;
 const byId=new Map(occurrences.map(o=>[o.observationId,o]));
 const progress=new Map(),alternatives=new Map();
 // An old exported JSON might predate the fix. Reconstruct progressive revisions
 // only when a matching same-length viewport has exactly one changed assistant
 // and at least TWO other shared position anchors. Never infer by text alone.
 for(let i=1;i<frames.length;i++){
  const later=frames[i];
  for(let j=i-1;j>=Math.max(0,i-15);j--){
   const earlier=frames[j];if(earlier.turns.length!==later.turns.length)continue;
   const diff=[];let equal=0;
   for(let k=0;k<later.turns.length;k++){
    if(earlier.turns[k].observationId===later.turns[k].observationId)equal++;
    else diff.push(k);
   }
   if(diff.length!==1||equal<2)continue;
   const k=diff[0],a=byId.get(earlier.turns[k].observationId),b=byId.get(later.turns[k].observationId);
   if(!a||!b||a.role!==b.role)continue;
   if(looksLikeProgress(a.text,b.text,a.role))progress.set(a.observationId,b.observationId);
   else if(a.text!==b.text){
    // An edit/retry is possible, but not provable from DOM alone.
    const vals=new Set([a.observationId,b.observationId]);
    alternatives.set([a.observationId,b.observationId].sort().join(':'),[...vals]);
   }
   break;
  }
 }
 for(const o of occurrences){if(o.supersededBy&&byId.has(o.supersededBy)&&
  looksLikeProgress(o.text,byId.get(o.supersededBy).text,o.role))progress.set(o.observationId,o.supersededBy);}
 const resolve=id=>{let n=id,seen=new Set();while(progress.has(n)&&!seen.has(n)){seen.add(n);n=progress.get(n);}return n;};
 const nodes=[...new Set(occurrences.map(o=>resolve(o.observationId)))],indegree=new Map(nodes.map(id=>[id,0]));
 const edges=new Map(nodes.map(id=>[id,new Set()])),neighbor=new Map(nodes.map(id=>[id,new Set()]));
 const orderHint=new Map(),firstFrame=new Map(),orderConflicts=[];
 // A new viewport can contradict previously observed precedence after reload,
 // Retry or a DOM matching mistake. Reject only the offending edge; otherwise
 // one cyclic edge can make the entire long transcript yield ZERO ordered turns.
 // Retain the contradiction as explicit forensic evidence, never as proof of a
 // verified active path. Old viewport evidence and occurrences are unchanged.
 function reaches(from,target){
  const stack=[from],visited=new Set();
  while(stack.length){const id=stack.pop();if(id===target)return true;
   if(visited.has(id))continue;visited.add(id);
   for(const next of edges.get(id)||[])if(!visited.has(next))stack.push(next);
  }
  return false;
 }
 frames.forEach((f,fi)=>{
  const ids=f.turns.map(t=>resolve(t.observationId)).filter(id=>byId.has(id));
  ids.forEach((id,k)=>{if(!orderHint.has(id))orderHint.set(id,fi*100+k);if(!firstFrame.has(id))firstFrame.set(id,fi);});
  for(let k=1;k<ids.length;k++){
   const a=ids[k-1],b=ids[k];if(a===b||edges.get(a).has(b))continue;
   if(reaches(b,a)){
    orderConflicts.push({frameId:f.frameId||null,frameIndex:fi,before:a,after:b,
      reason:'contradicts-observed-precedence'});
    continue;
   }
   edges.get(a).add(b);indegree.set(b,indegree.get(b)+1);
   neighbor.get(a).add(b);neighbor.get(b).add(a);
  }
 });
 const unconnected=nodes.filter(id=>!firstFrame.has(id));
 // The undirected components are separate observation islands. Without a
 // shared anchor we refuse to fabricate their relative chronology.
 const seen=new Set(),components=[];
 for(const node of nodes){if(seen.has(node))continue;const q=[node],ids=[];seen.add(node);
  while(q.length){const x=q.pop();ids.push(x);for(const n of neighbor.get(x)){if(!seen.has(n)){seen.add(n);q.push(n);}}}
  components.push(ids);
 }
 components.sort((a,b)=>Math.min(...a.map(x=>firstFrame.get(x)??1e12))-Math.min(...b.map(x=>firstFrame.get(x)??1e12)));
 const segments=[];let ambiguousCount=0;
 // A single fork used to force the ENTIRE remaining component to unresolved.
 // Retain that conservative verdict, but additionally expose its common
 // precedence backbone: positions comparable to every other position in the
 // same connected component. These are ordering anchors, NOT an active path.
 const sharedAnchors=[];
 function commonSpine(component,componentIndex){
  if(component.length>600)return; // bounded forensic helper, no expensive scan on giant chats
  const reachable=new Map();
  for(const start of component){
   const visited=new Set(),stack=[...(edges.get(start)||[])];
   while(stack.length){const n=stack.pop();if(visited.has(n))continue;visited.add(n);
    for(const x of edges.get(n)||[])if(!visited.has(x))stack.push(x);
   }
   reachable.set(start,visited);
  }
  const fixed=component.filter(a=>component.every(b=>a===b||reachable.get(a).has(b)||reachable.get(b).has(a)));
  fixed.sort((a,b)=>reachable.get(a).has(b)?-1:reachable.get(b).has(a)?1:0);
  for(const id of fixed)sharedAnchors.push({componentIndex,observationId:id,role:byId.get(id)?.role||'unknown',
   text:byId.get(id)?.text||''});
 }

 const cmp=(a,b)=>(orderHint.get(a)??1e12)-(orderHint.get(b)??1e12)||String(a).localeCompare(String(b));
 for(const [componentIndex,component] of components.entries()){
  commonSpine(component,componentIndex);
  const inComponent=new Set(component),degrees=new Map(component.map(id=>[id,0]));
  for(const id of component)for(const next of edges.get(id))if(inComponent.has(next))degrees.set(next,degrees.get(next)+1);
  const ready=component.filter(id=>degrees.get(id)===0).sort(cmp),ordered=[];let unresolved=false;
  while(ready.length){
   if(ready.length!==1){unresolved=true;break;}
   const id=ready.shift();ordered.push(id);
   for(const next of edges.get(id)){if(!inComponent.has(next))continue;
    degrees.set(next,degrees.get(next)-1);if(degrees.get(next)===0)ready.push(next);
   }
   ready.sort(cmp);
  }
  if(ordered.length){segments.push({kind:'ordered',turns:ordered.map(id=>byId.get(id))});}
  const remaining=component.filter(id=>!ordered.includes(id));
  if(remaining.length){
   ambiguousCount+=remaining.length;
   segments.push({kind:'unresolved',turns:remaining.sort(cmp).map(id=>byId.get(id)),
    reason:unresolved?'multiple possible paths':'conflicting/cyclic observations'});
  }
 }
 const possibleReplays=[],replayMap=new Map();
 // Exact long repeats with different IDs can be genuine retries OR mistaken
 // context re-captures. Do not silently deduplicate; surface the evidence.
 for(const o of occurrences){
  if(o.role!=='assistant'||norm(o.text).length<300)continue;
  const signature=o.role+'\u001f'+norm(o.text),prior=replayMap.get(signature);
  if(prior&&prior!==o.observationId)possibleReplays.push({earlierId:prior,laterId:o.observationId,
   preview:norm(o.text).slice(0,125)});
  else replayMap.set(signature,o.observationId);
 }
 const likelyIncomplete=occurrences.filter(o=>o.role==='assistant'&&norm(o.text).length<110&&
  /^CHAPTER\s+\d+/i.test(o.text)&&/\bDAY\s+\d+/i.test(o.text)&&
  !/[.!?。…]\s*$/.test(norm(o.text))).map(o=>o.observationId);
 const progressOld=[...progress.keys()].filter(id=>byId.has(id)),ordered=segments.flatMap(s=>s.kind==='ordered'?s.turns:[]);
 return {segments,ordered,progressOld,progressCount:progressOld.length,
  totalObservations:rawOccurrences.length,distinctPositions:nodes.length,
  orphanObservations:partial.orphanObservations,orphanFrameCount:partial.orphanFrames.length,
  sharedAnchors,sharedAnchorCount:sharedAnchors.length,possibleReplays,possibleReplayCount:possibleReplays.length,
  likelyIncomplete,likelyIncompleteCount:likelyIncomplete.length,
  ambiguousCount,componentCount:components.length,unconnectedCount:unconnected.length,
  orderConflictCount:orderConflicts.length,orderConflicts,
  possibleAlternatives:[...alternatives.values()],isLinear:orderConflicts.length===0&&segments.length===1&&segments[0].kind==='ordered',
  latestFrame:frames.at(-1)||null};
}
// Read-only working projection from viewport overlap. This is NEVER a verified
// ChatGPT branch: every retained ID remains DOM provisional, and the underlying
// occurrences/frames are untouched. Useful when one stale/retry viewport makes
// a global topological sort refuse the entire transcript.
function projectBase(chat,internal={}){
 const chatId=chat?.chatId,sourceUrl=chat?.sourceUrl;
 const all=(chat?.provisionalOccurrences||[]).filter(o=>o?.sourceChatId===chatId&&o.sourceUrl===sourceUrl&&
   o.captureOrigin==='live-conversation-dom-v090'&&['user','assistant'].includes(o.role)&&
   typeof o.text==='string'&&norm(o.text)&&typeof o.observationId==='string');
 const byId=new Map(all.map(o=>[o.observationId,o]));
 const rawFrames=(chat?.viewportEvidence||[]).filter(f=>f?.chatId===chatId&&f.sourceUrl===sourceUrl&&
   Array.isArray(f.turns)&&f.turns.length>0&&f.turns.every(t=>byId.has(t.observationId)));
 const partial=partitionPartialFrames(all,rawFrames);
 const frames=partial.activeFrames;
 const issues=[],replaced=[],reobserved=[];
 const auxiliaryStatusIds=confirmedAuxiliaryStatusIds(frames,byId);
 if(!frames.length)return {turns:[],issues:[{reason:'no-usable-frames'}],replaced,reobserved,
   observationCount:all.length,frameCount:0,unused:all,connected:false,
   orphanObservations:partial.orphanObservations,orphanFrameCount:partial.orphanFrames.length};
 // First view is a seed, not an assertion that the user's history begins here.
 const track=frames[0].turns.map(t=>t.observationId);
 const seenFrames=[frames[0].frameId];
 const retiredVersions=new Set();
 // DOM reloads can mint fresh observation IDs for an entire already-seen
 // viewport. Reconnect only with many exact role/text matches in fixed order,
 // including >=2 distinct long GM anchors. Never alias short '1'/'2' alone.
 const recapturedAliases=new Map();
 function reconnectByExactOverlap(frameIds,frameIndex){
  let best=null;
  const minOverlap=6;
  for(let offset=-frameIds.length+minOverlap;offset<=track.length-minOverlap;offset++){
   const from=Math.max(0,-offset),to=Math.min(frameIds.length,track.length-offset);
   const overlap=to-from;
   if(overlap<minOverlap)continue;
   let matched=0,longGM=0,conflicts=0;
   const anchorText=new Set();
   for(let i=from;i<to;i++){
    const a=frameIds[i],b=track[i+offset];
    if(sameTextRole(a,b)){
     matched++;
     const obs=byId.get(a);
     if(obs?.role==='assistant'&&norm(obs.text).length>=300){longGM++;anchorText.add(norm(obs.text));}
    }else conflicts++;
   }
   // Any changed text inside the overlap may be a genuine Edit/Retry branch.
   // Do not declare it a recapture or force an ID alias in that case.
   if(conflicts!==0||matched!==overlap||longGM<2||anchorText.size<2)continue;
   // Prefer the largest exact run; ties closer to the current tail.
   const score=overlap*1000+Math.min(0,offset);
   if(!best||score>best.score)best={offset,from,to,score};
  }
  if(!best)return null;
  for(let i=best.from;i<best.to;i++){
   const incoming=frameIds[i],canonical=track[i+best.offset];
   if(incoming!==canonical){recapturedAliases.set(incoming,canonical);
    reobserved.push({observationId:incoming,correspondsTo:canonical,frameIndex,
      reason:'exact-multi-gm-viewport-overlap'});}
  }
  return best;
 }
 function sameTextRole(a,b){const x=byId.get(a),y=byId.get(b);return x?.role===y?.role&&norm(x?.text)===norm(y?.text);}
 // v0.9.32 could only relink a fully reminted viewport via >=2 long GM
 // anchors. Here an old viewport shares many native DOM observation IDs but
 // the last FULL GM answer alone has been re-observed with a new DOM ID,
 // replacing a short planning renderer at the seam. It must be linked as the
 // same long answer, not interpreted as an unrelated Edit/Retry continuation.
 // Strictly require: unique verbatim long GM, >=2 shared preceding IDs,
 // a <=3-position seam, and ONLY short assistant planning text in that gap.
 function reconnectLongGMAtSeam(rawIds,ids,index,frameIndex){
  for(let i=0;i<ids.length;i++){
   if(index.has(ids[i]))continue;
   const observation=byId.get(rawIds[i]);
   if(observation?.role!=='assistant'||norm(observation.text).length<1200)continue;
   const targets=[];
   for(let j=0;j<track.length;j++)if(sameTextRole(track[j],rawIds[i]))targets.push(j);
   if(targets.length!==1)continue; // never guess between two repeated GM turns
   const target=targets[0];
   if(target!==track.length-1)continue; // this repair is a tail-only bridge
   const prior=ids.slice(0,i).map(id=>index.get(id)).filter(j=>j!==undefined);
   if(prior.length<2||prior.some(j=>j>=target))continue;
   const nearest=Math.max(...prior);
   if(target-nearest>3)continue;
   if(!track.slice(nearest+1,target).every(id=>looksLikeAuxiliaryStatus(byId.get(id))))continue;
   const fresh=rawIds[i],old=track[target];
   if(fresh===old)continue;
   recapturedAliases.set(fresh,old);
   reobserved.push({observationId:fresh,correspondsTo:old,frameIndex,
    reason:'unique-full-gm-tail-reobserved-with-shared-predecessors'});
   ids[i]=old;
  }
 }
 function splice(lo,deleteCount,news,fi,reason){
  const old=track.slice(lo,lo+deleteCount);
  if(!old.length&&!news.length)return;
  for(const x of old){replaced.push({observationId:x,reason,frameIndex:fi});retiredVersions.add(x);}
  if(news.length&&old.length)issues.push({reason:'candidate-replacement-not-verified',frameIndex:fi,
    previous:old,newer:news});
  track.splice(lo,deleteCount,...news);
 }
 for(let fi=1;fi<frames.length;fi++){
  const rawB=frames[fi].turns.map(t=>t.observationId);
  const b=rawB.map(id=>recapturedAliases.get(id)||id);
  const index=new Map(track.map((id,i)=>[id,i]));
  reconnectLongGMAtSeam(rawB,b,index,fi);
  let matches=b.map((id,i)=>index.has(id)?{i,j:index.get(id)}:null).filter(Boolean);
  if(!matches.length){
   if(reconnectByExactOverlap(rawB,fi)){
    for(let k=0;k<b.length;k++)b[k]=recapturedAliases.get(rawB[k])||rawB[k];
    matches=b.map((id,i)=>index.has(id)?{i,j:index.get(id)}:null).filter(Boolean);
   }
  }
  if(typeof internal.onFrame==='function')internal.onFrame({fi,track:track.slice(),rawB,b:b.slice(),matches:matches.slice(),frame:frames[fi],byId});
  if(!matches.length){issues.push({reason:'disconnected-frame',frameIndex:fi,frameId:frames[fi].frameId});continue;}
  if(matches.some((m,i)=>i&&m.j<=matches[i-1].j)){
   issues.push({reason:'reordered-overlap',frameIndex:fi,frameId:frames[fi].frameId});continue;
  }
  seenFrames.push(frames[fi].frameId);
  // An occasional reload captures the old two turns again before ten shared
  // anchors. Check the immediately preceding established turns by full text
  // AND role. Keep the duplicates in JSON as forensic evidence.
  const first=matches[0],prefix=b.slice(0,first.i);
  let prepend=[];
  if(prefix.length){
   if(first.j===0){prepend=prefix;}
   else if(first.j>=prefix.length&&prefix.every((id,k)=>sameTextRole(id,track[first.j-prefix.length+k]))){
    prefix.forEach((id,k)=>reobserved.push({observationId:id,correspondsTo:track[first.j-prefix.length+k],frameIndex:fi}));
   }else issues.push({reason:'unanchored-prefix',frameIndex:fi,observationIds:prefix});
  }
  // Between shared stable observations, the newer viewport is a tentative
  // local branch. Do not delete turns merely because a frame omits them.
  const operations=[];
  for(let k=1;k<matches.length;k++){
   const left=matches[k-1],right=matches[k];
   const oldLen=right.j-left.j-1,newIds=b.slice(left.i+1,right.i);
   if(!newIds.length)continue;
   operations.push({start:left.j+1,count:oldLen,news:newIds,reason:'in-frame-version-change'});
  }
  const last=matches.at(-1),suffix=b.slice(last.i+1),tailLen=track.length-last.j-1;
  if(suffix.length){
   if(!tailLen){
    // Only the end of the known track: an actual append from a shared anchor.
    operations.push({start:last.j+1,count:0,news:suffix,reason:'append-from-overlap'});
   }else{
    // Edit/Retry at the previous end is commonly followed by NEW GM turns.
    // v0.9.28 handled only equal-length substitutions, so it kept the old
    // edited PLAYER as #28 forever and discarded every later visible turn.
    // A candidate revision is possible when the old tail's roles match the
    // beginning of the new suffix and the viewport proves the attachment
    // with multiple shared IDs (or the immediately preceding long GM ID).
    // Never infer chronology from wall-clock times or short text alone.
    const oldTail=track.slice(last.j+1);
    const sameRoles=oldTail.length<=suffix.length&&oldTail.every((id,k)=>
      byId.get(id)?.role===byId.get(suffix[k])?.role);
    const strongShared=matches.length>=2||(
      matches.length===1&&last.j===track.length-tailLen-1&&
      byId.get(track[last.j])?.role==='assistant'&&
      norm(byId.get(track[last.j])?.text).length>=300);
    const samePrefix=sameRoles&&oldTail.every((id,k)=>sameTextRole(id,suffix[k]));
    // A previous GM interruption may have produced TWO assistant bubbles.
    // On Edit/Retry the same current response may render as ONE GM bubble,
    // followed by the corrected USER and subsequent turns. Require ≥3 stable
    // observation anchors, multiple same-content/role matches in order,
    // including a substantial GM, and at most one removed/extra turn.
    // Otherwise preserve the ambiguity rather than force a branch merge.
    let contentMatches=0,hasLongSharedGM=false,priorIndex=-1;
    for(const newer of suffix){
     const k=oldTail.findIndex((older,j)=>j>priorIndex&&sameTextRole(older,newer));
     if(k<0)continue;
     priorIndex=k;contentMatches++;
     if(byId.get(newer)?.role==='assistant'&&norm(byId.get(newer)?.text).length>=300)hasLongSharedGM=true;
    }
    const structuralRevision=!sameRoles&&matches.length>=3&&oldTail.length>=2&&
     suffix.length>=oldTail.length-1&&suffix.length<=oldTail.length+2&&
     byId.get(oldTail[0])?.role===byId.get(suffix[0])?.role&&
     contentMatches>=2&&hasLongSharedGM&&
     suffix.some(id=>!retiredVersions.has(id));
    if((sameRoles&&strongShared)||structuralRevision){
     if(samePrefix){
      // Reload can mint duplicate IDs for the same old tail. Reuse existing
      // observations, append ONLY the genuinely new part of the frame.
      oldTail.forEach((id,k)=>{if(id!==suffix[k])reobserved.push({
       observationId:suffix[k],correspondsTo:id,frameIndex:fi});});
      if(suffix.length>tailLen)operations.push({start:track.length,count:0,
       news:suffix.slice(tailLen),reason:'append-after-reobservation'});
     }else{
      operations.push({start:last.j+1,count:tailLen,news:suffix,
       reason:structuralRevision?'structural-edit-tail-revision':'possible-edited-tail-and-continuation'});
     }
    }else{
     // Older/incomplete viewport: retain the existing candidate. Preserve
     // the new evidence in JSON, never manufacture an active path.
     issues.push({reason:'unanchored-tail-preserved',frameIndex:fi,frameId:frames[fi].frameId,
      observationIds:suffix,existingTail:oldTail});
    }
   }
  }
  operations.sort((x,y)=>y.start-x.start);
  for(const op of operations)splice(op.start,op.count,op.news,fi,op.reason);
  if(prepend.length)track.unshift(...prepend);
 }
 // Exclude only proven pre-answer status renderers from the user-facing TXT.
 // Their ORIGINAL observations and viewport frames remain intact in JSON.
 const visibleTrack=track.filter(id=>!auxiliaryStatusIds.has(id));
 const chosen=new Set(visibleTrack),unused=all.filter(o=>!chosen.has(o.observationId));
 const suspicious=issues.filter(i=>i.reason!=='candidate-replacement-not-verified');
 const idset=new Set(visibleTrack);
 if(idset.size!==visibleTrack.length)issues.push({reason:'repeat-in-projection'});
 const startsWithUser=byId.get(visibleTrack[0])?.role==='user';
 return {turns:visibleTrack.map(id=>byId.get(id)).filter(Boolean),issues,replaced,reobserved,
  auxiliaryStatusObservations:all.filter(o=>auxiliaryStatusIds.has(o.observationId)),
  observationCount:all.length,frameCount:frames.length,connected:!suspicious.length,
  orphanObservations:partial.orphanObservations,orphanFrameCount:partial.orphanFrames.length,
  unused,startsWithUser,disclaimer:'Observed working projection only. NOT a verified active path, canon, or complete ChatGPT history.'};
}

// v0.9.34: when a middle-of-history Edit creates a short new branch while
// a long old tail already exists, no DOM inference may silently choose the
// old tail. Preserve both candidates, withhold divergence until user chooses.
function project(chat,options={}){
 const witnessed=[];
 const base=projectBase(chat,{onFrame:x=>witnessed.push(x)});
 const byId=new Map((chat?.provisionalOccurrences||[]).map(o=>[o.observationId,o]));
 const forks=new Map();
 for(const w of witnessed){
  const {fi,track,b,matches}=w;
  if(matches.length<3||track.length<12)continue;
  if(matches.some((m,i)=>i&&m.j<=matches[i-1].j))continue;
  const last=matches.at(-1),pivot=last.j+1,oldTail=track.slice(pivot),incoming=b.slice(last.i+1);
  if(oldTail.length<4||!incoming.length||incoming.length>=oldTail.length||!byId.has(oldTail[0]))continue;
  // Demand three stable, consecutive anchors just before the divergence,
  // including a substantive GM; short numerical choices cannot authorize it.
  const anchors=matches.slice(-3);
  if(anchors.some((m,k)=>k&&(m.j!==anchors[k-1].j+1||m.i!==anchors[k-1].i+1)))continue;
  if(!anchors.some(m=>byId.get(track[m.j])?.role==='assistant'&&norm(byId.get(track[m.j])?.text).length>=300))continue;
  const oldFirst=byId.get(oldTail[0]),newFirst=byId.get(incoming[0]);
  if(!newFirst||newFirst.role!==oldFirst.role||norm(newFirst.text)===norm(oldFirst.text))continue;
  if(incoming.some(id=>track.includes(id)))continue;
  if(newFirst.role!=='user'&&!incoming.some(id=>byId.get(id)?.role==='assistant'&&norm(byId.get(id)?.text).length>=300))continue; // A lone edited USER is sufficient with 3 strong anchors; a short GM progress bubble is not.
  // Reject a mere re-render of one existing old-tail response.
  if(incoming.some(id=>oldTail.some(old=>byId.get(id)?.role===byId.get(old)?.role&&norm(byId.get(id)?.text)===norm(byId.get(old)?.text))))continue;
  const tag=pivot+'|'+incoming[0];
  if(!forks.has(tag))forks.set(tag,{pivot,fi,oldTrack:track,initial:incoming,tag});
 }
 if(!forks.size)return {...base,branchOptions:[],retroFork:null,branchChoice:'auto'};
 // Focus on the earliest pivot: a choice of branch must precede any nested edits.
 const firstPivot=Math.min(...[...forks.values()].map(f=>f.pivot));
 const atPivot=[...forks.values()].filter(f=>f.pivot===firstPivot);
 const origin=atPivot[0],oldTrack=origin.oldTrack;
 const pickTurns=ids=>ids.map(id=>byId.get(id)).filter(Boolean);
 const branches=[{id:'old:'+firstPivot+':'+oldTrack[firstPivot],label:'Nhánh cũ (đã có trước khi sửa)',turns:pickTurns(oldTrack),kind:'old'}];
 const rawFrames=(chat?.viewportEvidence||[]).filter(f=>f?.chatId===chat?.chatId&&f?.sourceUrl===chat?.sourceUrl&&Array.isArray(f.turns)&&f.turns.every(t=>byId.has(t.observationId)));
 for(const fork of atPivot){
  // Replay only frames that touch the NEW suffix. Frames only showing the
  // shared prefix or the old tail cannot overwrite this alternative.
  const known=new Set(fork.initial),replay=[];
  replay.push({chatId:chat.chatId,sourceUrl:chat.sourceUrl,frameId:'branch-seed-'+fork.tag,
   campaignId:chat.campaignScopeId,turns:fork.oldTrack.slice(0,fork.pivot).concat(fork.initial).map(id=>({observationId:id,role:byId.get(id)?.role}))});
  for(let i=fork.fi+1;i<rawFrames.length;i++){
   const frame=rawFrames[i],ids=frame.turns.map(t=>t.observationId);
   const first=ids.findIndex(id=>known.has(id));
   if(first<0)continue;
   replay.push(frame);
   // Only extend the known branch with text occurring AFTER its last known
   // anchor in a frame. Do not alias same-text numerical selections.
   let last=-1;ids.forEach((id,j)=>{if(known.has(id))last=j;});
   for(const id of ids.slice(last+1))known.add(id);
  }
  const alt=projectBase({...chat,viewportEvidence:replay});
  const ids=alt.turns.map(t=>t.observationId);
  const expected=fork.oldTrack.slice(0,fork.pivot).concat(fork.initial);
  if(ids.length<expected.length||!expected.every((id,j)=>ids[j]===id))continue;
  branches.push({id:'new:'+fork.pivot+':'+fork.initial[0],label:'Nhánh sửa từ lượt #'+(fork.pivot+1),
    turns:alt.turns,kind:'new',frameIndex:fork.fi});
 }
 if(branches.length<2)return {...base,branchOptions:[],retroFork:null,branchChoice:'auto'};
 const selected=branches.find(b=>b.id===options?.selectedPathId);
 const chosen=selected?selected.turns:pickTurns(oldTrack.slice(0,firstPivot));
 const chosenIds=new Set(chosen.map(o=>o.observationId));
 return {...base,turns:chosen,unused:(chat?.provisionalOccurrences||[]).filter(o=>!chosenIds.has(o.observationId)),
   issues:[...base.issues,{reason:'retroactive-fork-requires-choice',pivot:firstPivot,frameIndex:origin.fi}],
   connected:false,branchChoice:selected?.id||'auto',
   branchOptions:branches.map(b=>({id:b.id,label:b.label,kind:b.kind,count:b.turns.length,
    pivot:firstPivot,firstText:byId.get(b.turns[firstPivot]?.observationId)?.text?.slice(0,180)||'',
    lastText:b.turns.at(-1)?.text?.slice(0,180)||''})),
   retroFork:{pivot:firstPivot,count:branches.length,requiresChoice:!selected,
    notice:selected?'Nhánh do người dùng chọn trên thiết bị này; CHƯA xác minh UUID/active path ChatGPT.':
     'Phát hiện sửa giữa lịch sử: TXT chỉ xuất phần chung. Chọn nhánh bằng tay để xem phần sau.'}};
}
root.RPGMBTimeline={analyze,project,looksLikeProgress,partitionPartialFrames};
})(typeof globalThis!=='undefined'?globalThis:this);
