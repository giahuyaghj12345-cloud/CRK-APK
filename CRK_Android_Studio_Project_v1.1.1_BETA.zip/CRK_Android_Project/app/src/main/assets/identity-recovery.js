// Read-only evidence identity recovery for re-rendered DOM and Cloud snapshots.
// Does NOT mutate or delete evidence in chrome.storage or the Cloud.
(function(root){
 'use strict';
 const norm=s=>String(s||'').replace(/\r\n?/g,'\n').replace(/\u00a0/g,' ').trim();
 const key=o=>o.role+'\u001f'+norm(o.text);
 const isPlaceholder=o=>o?.role==='assistant'&&/^(?:Không thể tải phản hồi này|Unable to load (?:this )?response|Something went wrong(?: while generating the response)?\.?|There was an error generating a response\.?)(?:\s|$)/i.test(norm(o.text));
 const trusted=o=>o && (o.role==='user'||o.role==='assistant') && o.observationId && norm(o.text);
 function recover(chat){
  if(!chat||!Array.isArray(chat.provisionalOccurrences)||!Array.isArray(chat.viewportEvidence))return chat;
  const original=chat.provisionalOccurrences, byId=new Map(original.filter(trusted).map(o=>[o.observationId,o]));
  const frames=chat.viewportEvidence.filter(f=>Array.isArray(f.turns)&&f.turns.every(t=>!!t.observationId&&byId.has(t.observationId)));
  if(!frames.length)return chat;
  // Keep established old campaigns 100% on their existing branch engine.
  // Activate repair only when adjacent early viewports demonstrably lost their
  // observation IDs despite retaining the SAME substantial visible message.
  let identitySeamLost=false;
  for(let i=1;i<Math.min(frames.length,16);i++){
   const older=frames[i-1].turns,newer=frames[i].turns;
   const ids=new Set(older.map(t=>t.observationId));
   if(newer.some(t=>ids.has(t.observationId)))continue;
   const priorTexts=new Set(older.map(t=>key(byId.get(t.observationId))));
   if(newer.some(t=>{
    const o=byId.get(t.observationId);
    return norm(o.text).length>=80&&priorTexts.has(key(o));
   })){identitySeamLost=true;break;}
  }
  if(!identitySeamLost){
    // Some reloads preserve one shared GM in the viewport, so the adjacent
    // frames do overlap, but the SAME long PLAYER prompt gets a new ID.
    // This is particularly important for long SOURCE AUDIT/bootstrap prompts.
    const firstSeen=new Map();
    for(const f of frames.slice(0,12))for(const t of f.turns){
      const o=byId.get(t.observationId);
      if(o?.role!=='user'||norm(o.text).length<400)continue;
      const k=key(o),prior=firstSeen.get(k);
      if(prior&&prior!==o.observationId){identitySeamLost=true;break;}
      firstSeen.set(k,o.observationId);
    }
  }
  if(!identitySeamLost)return chat;
  const prohibited=new Set();
  // Never treat duplicate same-content bubbles visible in ONE viewport as one turn.
  for(const f of frames){
   const grouped=new Map();
   for(const t of f.turns){const o=byId.get(t.observationId),k=key(o);if(!grouped.has(k))grouped.set(k,new Set());grouped.get(k).add(o.observationId);}
   for(const [k,ids] of grouped)if(ids.size>1)prohibited.add(k);
  }
  const groups=new Map();
  for(const o of original.filter(trusted)){
   if(isPlaceholder(o))continue;
   const k=key(o);if(!groups.has(k))groups.set(k,[]);groups.get(k).push(o);
  }
  const alias=new Map();
  // GM may stream a partial answer before its complete renderer replaces it.
  // A long exact prefix plus matching preceding PLAYER in observed frames is
  // stronger evidence than timestamps, but still not a native identity proof.
  const priorPlayer=new Map();
  for(const f of frames){let last=null;
   for(const t of f.turns){const o=byId.get(t.observationId);if(o.role==='user')last=key(o);
    else if(last){if(!priorPlayer.has(o.observationId))priorPlayer.set(o.observationId,new Set());
      priorPlayer.get(o.observationId).add(last);}
   }
  }
  const canSharePosition=(a,b)=>{
   const x=priorPlayer.get(a.observationId),y=priorPlayer.get(b.observationId);
   return !!x&&!!y&&[...x].some(t=>y.has(t)) && !frames.some(f=>f.turns.some(t=>t.observationId===a.observationId)&&f.turns.some(t=>t.observationId===b.observationId));
  };
  const superseded=new Set();
  const occs=original.filter(trusted);
  const aux=new Set();
  const possibleStatus=o=>o?.role==='assistant'&&norm(o.text).length<850&&
   /^(?:Tôi sẽ|Mình sẽ|Hoàn tất chuẩn bị|Nguồn.{0,64}xác nhận|Đang hoàn tất đăng ký|Đã xác định và xác nhận lệnh tiếp theo)(?:\s|$)/i.test(norm(o.text));
  for(const f of frames){
   for(let i=0;i<f.turns.length-1;i++){
    const a=byId.get(f.turns[i].observationId),b=byId.get(f.turns[i+1].observationId);
    if(possibleStatus(a)&&b?.role==='assistant'&&norm(b.text).length>=1200)aux.add(a.observationId);
   }
  }
  // Additional streaming status versions can be shown in earlier frames.
  // Only suppress status text if there is a confirmed co-rendered status of
  // the same beginning in this chat; otherwise keep it as unresolved evidence.
  for(const o of occs)if(possibleStatus(o)&&[...aux].some(id=>{
     const other=byId.get(id);const a=norm(o.text),b=norm(other.text);
     return a.slice(0,45)===b.slice(0,45)&&[...priorPlayer.get(o.observationId)||[]].some(k=>priorPlayer.get(id)?.has(k));
   }))aux.add(o.observationId);

  const stable=(o)=>o.role==='assistant'?norm(o.text).length>=200:norm(o.text).length>=35;
  for(const [k,items] of groups){
   if(items.length<2||prohibited.has(k)||!stable(items[0]))continue;
   const first=items.map(x=>x.observationId).sort()[0];
   for(const o of items)if(o.observationId!==first)alias.set(o.observationId,first);
  }
  const canonical=id=>{const seen=new Set();while(alias.has(id)&&!seen.has(id)){seen.add(id);id=alias.get(id);}return id;};
  // Resolve progressive GM versions after exact re-render deduplication.
  for(const a of occs){
   if(a.role!=='assistant'||norm(a.text).length<450)continue;
   const later=new Map();
   for(const b of occs){
    if(b.role!=='assistant'||b.observationId===a.observationId)continue;
    if(norm(b.text).length>norm(a.text).length+20&&norm(b.text).startsWith(norm(a.text))&&canSharePosition(a,b)){
     later.set(canonical(b.observationId),b);
    }
   }
   if(later.size===1){const id=[...later.keys()][0];if(id!==canonical(a.observationId)){
     alias.set(a.observationId,id);superseded.add(a.observationId);
   }}
  }

  // Merge very short same-content turns ONLY if they have identical, strongly
  // established immediate neighbors in observed viewports. '1' and '2'
  // in different locations must remain separate.
  for(let pass=0;pass<2;pass++){
   const neighbors=new Map();
   for(const f of frames){
    for(let i=0;i<f.turns.length;i++){
     const id=f.turns[i].observationId,o=byId.get(id);if(!o||isPlaceholder(o))continue;
     const prev= i ? f.turns[i-1].observationId:null;
     const next= i+1<f.turns.length ? f.turns[i+1].observationId:null;
     const desc={left:prev&&canonical(prev),right:next&&canonical(next)};
     if(!neighbors.has(id))neighbors.set(id,[]);neighbors.get(id).push(desc);
    }
   }
   for(const [k,items] of groups){
    if(items.length<2||prohibited.has(k)||stable(items[0])||isPlaceholder(items[0]))continue;
    const evidence=new Map();
    for(const o of items){
     const signatures=new Set();
     for(const {left,right} of neighbors.get(o.observationId)||[]){
      const a=byId.get(left),b=byId.get(right);
      if(a&&b&&a.role!==o.role&&b.role!==o.role&&norm(a.text).length>=100&&norm(b.text).length>=100){
       signatures.add(left+'|'+right);
      }
     }
     for(const sig of signatures){if(!evidence.has(sig))evidence.set(sig,[]);evidence.get(sig).push(o.observationId);}
    }
    for(const ids of evidence.values())if(ids.length>=2){const first=ids.slice().sort()[0];
     for(const id of ids)if(id!==first)alias.set(id,first);
    }
   }
  }
  const renamedFrames=[];let droppedErrorFrames=0;
  for(const f of frames){
   if(f.turns.some(t=>isPlaceholder(byId.get(t.observationId)))){droppedErrorFrames++;continue;}
   const turns=f.turns.filter(t=>!aux.has(t.observationId)).map(t=>({...t,observationId:canonical(t.observationId)}));
   // Duplicate IDs in a frame signal an ambiguous merge. Retain original frame
   // rather than pretending two separately displayed messages were one.
   if(new Set(turns.map(t=>t.observationId)).size!==turns.length){renamedFrames.push(f);continue;}
   renamedFrames.push({...f,turns});
  }
  const activeIds=new Set(renamedFrames.flatMap(f=>f.turns.map(t=>t.observationId)));
  const occurrences=original.filter(o=>!isPlaceholder(o)&&!aux.has(o.observationId)&&!alias.has(o.observationId)&&activeIds.has(o.observationId));
  const recovery={originalObservationCount:original.length,originalFrameCount:frames.length,
   duplicateIdsReconciled:alias.size,uiPlaceholderObservations:original.filter(isPlaceholder).length,
   uiPlaceholderFrames:droppedErrorFrames,auxiliaryGmStatuses:aux.size,streamingVersions:superseded.size,source:'local-read-only-view',nativeIdentityVerified:false};
  return {...chat,provisionalOccurrences:occurrences,viewportEvidence:renamedFrames,
   identityRecovery:recovery};
 }
 root.RPGMBIdentityRecovery={recover,isPlaceholder};
})(typeof globalThis!=='undefined'?globalThis:this);
