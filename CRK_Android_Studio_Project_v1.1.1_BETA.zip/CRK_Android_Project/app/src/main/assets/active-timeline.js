// CRK Active Timeline v1.1 beta.
// Independent projection. Never alters legacy RAW evidence.
// Fail closed on ambiguous DOM changes; explicit Edit/Retry event + confirmed
// changed message + stable anchors required before truncating a timeline.
(function(root){
'use strict';
const norm=s=>String(s||'').replace(/\r\n?/g,'\n').replace(/\u00a0/g,' ').trim();
const editorDraft=s=>/(?:^|\n)\s*(?:Hủy|Huỷ|Cancel)\s*\n\s*(?:Gửi|Send|Save)\s*$/i.test(norm(s));
const native=id=>/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(String(id||''));
const same=(a,b)=>a?.role===b?.role && norm(a.text)===norm(b.text)&&
  norm(a.text).length>0 &&
  (!(native(a.sourceId)&&native(b.id))||a.sourceId===b.id);
function fresh(){return {schema:1,generation:0,serial:{user:0,assistant:0},turns:[],
  backups:[],issues:[],updatedAt:null,lastOperation:'not-started'};}
function clone(prev){
  if(prev?.schema!==1||!Array.isArray(prev.turns))return fresh();
  return { ...prev,serial:{user:prev.serial?.user||0,assistant:prev.serial?.assistant||0},
    turns:prev.turns.map(t=>({...t})),
    backups:Array.isArray(prev.backups)?prev.backups.slice(-10):[],
    issues:Array.isArray(prev.issues)?prev.issues.slice(-20):[]};
}
function create(s,m,at,parent=null){
 const role=m.role,serial=(s.serial[role]||0)+1;
 s.serial[role]=serial;
 const baseId=(role==='user'?'U':'A')+String(serial).padStart(5,'0');
 return {id:baseId,baseId,revision:0,role,text:norm(m.text),
   sourceId:native(m.id)?m.id:null,provisional:!native(m.id),
   createdAt:at,updatedAt:at,...(parent?{parentId:parent}:{})};
}
function latestIssue(s,reason,at){
 if(s.issues.at(-1)?.reason===reason)return;
 s.issues.push({reason,at});s.issues=s.issues.slice(-20);
}
function fingerprint(m){return m.role+'\u001f'+norm(m.text);}
function aligned(old,visible){
 const oldCnt=new Map(),visCnt=new Map();
 for(const m of old){const k=fingerprint(m);oldCnt.set(k,(oldCnt.get(k)||0)+1);}
 for(const m of visible){const k=fingerprint(m);visCnt.set(k,(visCnt.get(k)||0)+1);}
 const offsets=new Map();
 for(let i=0;i<old.length;i++)for(let j=0;j<visible.length;j++){
  const a=old[i],b=visible[j];if(a.role!==b.role)continue;
  const idMatch=native(a.sourceId)&&native(b.id)&&a.sourceId===b.id;
  const textMatch=!(native(a.sourceId)&&native(b.id)&&a.sourceId!==b.id)&&
    norm(a.text)===norm(b.text)&&oldCnt.get(fingerprint(a))===1&&visCnt.get(fingerprint(b))===1;
  if(!idMatch&&!textMatch)continue;
  const offset=i-j,entry=offsets.get(offset)||{offset,score:0,count:0,native:0,anchors:[]};
  entry.score+=idMatch?9:3;entry.count++;if(idMatch)entry.native++;
  entry.anchors.push([i,j]);offsets.set(offset,entry);
 }
 const sorted=[...offsets.values()].sort((a,b)=>b.score-a.score||b.count-a.count);
 if(!sorted.length)return null;
 const top=sorted[0];
 // A single text occurrence does not prove a stable position across reloads.
 if(!(top.native>=1||top.count>=2))return null;
 if(sorted[1]&&sorted[1].score===top.score)return null;
 return top;
}
function locateTarget(s,hint){
 if(!hint)return -1;
 if(hint.crkId){const n=s.turns.findIndex(x=>x.id===hint.crkId);if(n>=0)return n;}
 if(native(hint.sourceId)){const n=s.turns.findIndex(x=>x.sourceId===hint.sourceId);if(n>=0)return n;}
 const matches=s.turns.map((t,i)=>({t,i})).filter(({t})=>t.role===hint.role&&norm(t.text)===norm(hint.text));
 return matches.length===1?matches[0].i:-1;
}
function acceptsPair(a,b){return a.role===b.role;}
function apply(previous,rawVisible,{now=new Date().toISOString(),hint=null}={}){
 const s=clone(previous),before=JSON.stringify(s.turns);
 const visible=(Array.isArray(rawVisible)?rawVisible:[]).filter(x=>
  (x?.role==='user'||x?.role==='assistant')&&norm(x.text)).map(x=>({...x,text:norm(x.text)}));
 if(!visible.length)return {state:s,changed:false,status:'empty-viewport'};
 if(!s.turns.length){
  for(const m of visible)s.turns.push(create(s,m,now,s.turns.at(-1)?.id||null));
  s.updatedAt=now;s.lastOperation='initial-visible-viewport';
  return {state:s,changed:true,status:'seed-viewport',count:s.turns.length};
 }
 const match=aligned(s.turns,visible);
 if(!match){latestIssue(s,'unconnected-viewport; retained, no deletion',now);
  return {state:s,changed:false,status:'unconnected'};}
 const offset=match.offset;
 // Conflicting aligned anchors must never be used to delete by themselves.
 if(match.anchors.some(([i,j])=>i-j!==offset))return {state:s,changed:false,status:'ambiguous-offset'};
 // Repair ONLY a known v1.1.0 bug: ChatGPT's inline Edit toolbar was
 // captured inside a PLAYER revision as literal "Hủy / Gửi". Wait until the
 // editor is closed (capture.js enforces that) and require TWO stable anchors
 // preceding this turn. Keep the corrupted segment in a rollback backup.
 const corrupt=s.turns.findIndex(x=>x.role==='user'&&editorDraft(x.text));
 if(corrupt>=0){
   const slot=corrupt-offset,old=s.turns[corrupt],replacement=visible[slot];
   const preceding=match.anchors.filter(([i,j])=>i<corrupt&&j<slot).length;
   if(preceding>=2 && replacement?.role==='user' && !editorDraft(replacement.text) &&
      norm(replacement.text)!==norm(old.text)){
     const dropped=s.turns.slice(corrupt);
     s.backups.push({backupId:crypto.randomUUID(),at:now,action:'repair-editor-contamination',
       pivot:corrupt,headId:old.id,removed:dropped.map(x=>({...x})),generation:s.generation});
     s.backups=s.backups.slice(-10);
     const corrected={...old,text:norm(replacement.text),
       sourceId:native(replacement.id)?replacement.id:null,
       provisional:!native(replacement.id),updatedAt:now};
     s.turns=s.turns.slice(0,corrupt).concat(corrected);
     for(let j=slot+1;j<visible.length;j++)
       s.turns.push(create(s,visible[j],now,s.turns.at(-1)?.id));
     s.generation+=1;
     s.lastOperation='repair-editor-contamination-at-'+(corrupt+1);
     s.updatedAt=now;
     return {state:s,changed:true,status:'repair',pivot:corrupt,removed:dropped.length};
   }
   latestIssue(s,'editor-contamination-unconfirmed; no deletion',now);
   return {state:s,changed:false,status:'editor-contamination-unconfirmed'};
 }
 const target=locateTarget(s,hint);
 if(hint&&target>=0&&['edit','retry','switch'].includes(hint.kind)){
  const slot=target-offset,old=s.turns[target],replacement=visible[slot];
  const changedReplacement=replacement&&acceptsPair(old,replacement)&&
    (norm(old.text)!==norm(replacement.text)||
      (native(replacement.id)&&native(old.sourceId)&&replacement.id!==old.sourceId));
  // A retained predecessor is strong evidence that this observation is a
  // descendant of the intended turn, not an unrelated viewport/old branch.
  const anchoredBefore=match.anchors.some(([i,j])=>i<target&&j<slot);
  const headException=target===0 && match.anchors.some(([i,j])=>i>target&&j>slot);
  if(replacement&&changedReplacement&&(anchoredBefore||headException)){
    const tail=s.turns.slice(target);
    const newRevision=(old.revision||0)+1;
    const updated={...old,id:old.baseId+'-R'+newRevision,revision:newRevision,
      text:norm(replacement.text),sourceId:native(replacement.id)?replacement.id:null,
      provisional:!native(replacement.id),updatedAt:now};
    s.backups.push({backupId:crypto.randomUUID(),at:now,action:hint.kind,
      pivot:target,headId:old.id,removed:tail.map(t=>({...t})),generation:s.generation});
    s.backups=s.backups.slice(-10);
    s.turns=s.turns.slice(0,target).concat([updated]);
    s.generation+=1;
    s.lastOperation=hint.kind+'-fork-at-'+(target+1);
    // Do not inherit any visible suffix in the instant of a fork: ChatGPT
    // sometimes keeps the old GM reply on-screen while replacing the branch.
    // A later stable capture may append new replies normally.
    s.updatedAt=now;
    return {state:s,changed:true,status:'fork',pivot:target,removed:tail.length,revision:updated.id};
  }
  latestIssue(s,'pending-'+hint.kind+'-unconfirmed; no deletion',now);
  // Do not block legitimate appends if an Edit was opened but cancelled.
 }
 // A different message in a pre-existing aligned slot might mean branch
 // navigation/edit. Never silently replace or truncate without a UI event.
 const begin=Math.max(0,-offset),end=Math.min(visible.length,s.turns.length-offset);
 for(let j=begin;j<end;j++){
   const i=j+offset,a=s.turns[i],b=visible[j];
   if(a.role!==b.role){latestIssue(s,'aligned-role-conflict; no deletion',now);
     return {state:s,changed:false,status:'role-conflict'};}
   if(!same(a,b)){
     // Server-native same UUID can expand after a stable reading. Treat only
     // strictly growing prefix as continuation, not Edit/Retry.
     if(native(a.sourceId)&&a.sourceId===b.id&&b.text.length>a.text.length&&b.text.startsWith(a.text)){
       s.turns[i]={...a,text:b.text,updatedAt:now};
       continue;
     }
     latestIssue(s,'aligned-content-conflict; no deletion',now);
     return {state:s,changed:false,status:'content-conflict'};
   }
   if(!a.sourceId&&native(b.id))s.turns[i]={...a,sourceId:b.id,provisional:false,updatedAt:now};
 }
 // Append only where an observed frame overlaps the actual tail; prepend only
 // where it overlaps the actual head. Never invent missing middle turns.
 if(offset<0){
   const prefix=visible.slice(0,-offset);
   if(prefix.length){
     const newTurns=prefix.map(m=>create(s,m,now));
     s.turns=[...newTurns,...s.turns];s.lastOperation='prepend-observed';
   }
 }
 const coveredEnd=offset+visible.length;
 if(coveredEnd>s.turns.length){
   const from=Math.max(0,s.turns.length-offset),suffix=visible.slice(from);
   for(const m of suffix)s.turns.push(create(s,m,now,s.turns.at(-1)?.id));
   if(suffix.length)s.lastOperation='append-observed';
 }
 const changed=JSON.stringify(s.turns)!==before;
 if(changed){s.updatedAt=now;if(s.lastOperation==='not-started')s.lastOperation='reconciled';}
 return {state:s,changed,status:changed?s.lastOperation:'same-viewport'};
}
function combine(winner,loser){
 const backups=[...new Map([...(loser.backups||[]),...(winner.backups||[])]
   .map(x=>[x.backupId,x])).values()].slice(-10);
 const issues=[...new Map([...(loser.issues||[]),...(winner.issues||[])]
   .map(x=>[x.reason+'|'+x.at,x])).values()].slice(-20);
 return {...winner,serial:{user:Math.max(winner.serial?.user||0,loser.serial?.user||0),
    assistant:Math.max(winner.serial?.assistant||0,loser.serial?.assistant||0)},
   backups,issues};
}
function merge(local,remote){
 if(local?.schema!==1)return {state:remote?.schema===1?remote:local,changed:remote?.schema===1,conflict:false};
 if(remote?.schema!==1)return {state:local,changed:false,conflict:false};
 if(local.campaignId&&remote.campaignId&&local.campaignId!==remote.campaignId)
   return {state:local,changed:false,conflict:true,reason:'campaign-owner-conflict'};
 if(remote.generation!==local.generation){
   return remote.generation>local.generation?
     {state:combine(remote,local),changed:true,conflict:false}:
     {state:local,changed:false,conflict:false};
 }
 const a=local.turns||[],b=remote.turns||[],n=Math.min(a.length,b.length);
 for(let i=0;i<n;i++)if(a[i].id!==b[i].id||a[i].role!==b[i].role||norm(a[i].text)!==norm(b[i].text)){
   return {state:local,changed:false,conflict:true,reason:'same-generation-diverged'};
 }
 if(b.length>a.length)return {state:combine(remote,local),changed:true,conflict:false};
 // Two devices can learn the same native source ID at different times.
 const promoted=a.map((t,i)=>!t.sourceId&&b[i]?.sourceId?{...t,sourceId:b[i].sourceId,provisional:false}:t);
 if(promoted.some((t,i)=>t!==a[i]))return {state:{...combine(local,remote),turns:promoted},changed:true,conflict:false};
 return {state:local,changed:false,conflict:false};
}
function exportText(items,{audit=false}={}){
 const out=['CRK CAMPAIGN RAW KEEPER · SINGLE ACTIVE TIMELINE (BETA)',
 'Chỉ xuất lịch sử đang được CRK theo dõi. Chưa chứng minh đầy đủ các lượt chưa hiện trên DOM.',
 'Edit/Retry chỉ cắt khi có sự kiện thao tác và neo xác nhận; backup trước khi cắt nằm trong JSON.'];
 for(const item of items){
   const state=item?.c?.activeTimeline;
   if(!state?.turns?.length)continue;
   out.push('===== '+(item.c.title||item.c.chatId)+' · '+state.turns.length+' LƯỢT · GEN '+state.generation+' =====');
   for(const [i,t] of state.turns.entries())
    out.push('['+(i+1)+' · '+(t.role==='user'?'PLAYER':'GM')+' · '+t.id+
      (audit?' · '+(t.sourceId||'NO_NATIVE_UUID'):'')+']\n'+t.text);
   if(audit&&state.issues?.length)out.push('CẢNH BÁO: '+state.issues.map(x=>x.reason).join('; '));
 }
 return out.join('\n\n');
}
root.CRKActiveTimeline={fresh,apply,merge,exportText,aligned,locateTarget};
})(typeof globalThis!=='undefined'?globalThis:this);
