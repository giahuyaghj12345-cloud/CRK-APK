// Non-destructive, PLAYER-reported source status. DOM disappearance is NOT a delete.
// All events are annotations, not verified assertions about ChatGPT internal history.
(function(root){
'use strict';
const uuid=s=>/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(String(s||''));
const kinds=['REPORTED_DELETED','REPORTED_SUPERSEDED','REPORTED_REGENERATED','RESTORED'];
const newId=()=>{if(typeof crypto.randomUUID==='function')return crypto.randomUUID();const b=crypto.getRandomValues(new Uint8Array(16));b[6]=(b[6]&15)|64;b[8]=(b[8]&63)|128;const x=[...b].map(v=>v.toString(16).padStart(2,'0')).join('');return [x.slice(0,8),x.slice(8,12),x.slice(12,16),x.slice(16,20),x.slice(20)].join('-');};
function valid(x){return !!x&&typeof x==='object'&&!Array.isArray(x)&&Array.isArray(x.entries)&&x.entries.length<=10000&&JSON.stringify(x).length<=600000&&x.entries.every(e=>uuid(e.id)&&uuid(e.chatId)&&uuid(e.messageId)&&kinds.includes(e.kind)&&typeof e.reason==='string'&&e.reason.length<=500&&typeof e.at==='string'&&e.at.length<=60&&e.reporter==='PLAYER');}
function record(index,chatId,messageId,kind,reason,at=new Date().toISOString(),id=null){
 if(!uuid(chatId)||!uuid(messageId)||!kinds.includes(kind)||!String(reason||'').trim()||String(reason).length>500)throw Error('Event nguồn cần UUID, loại và lý do hợp lệ.');
 const prev=index?.entries||[],entry={id:id||newId(),chatId,messageId,kind,reason:String(reason).trim(),at,reporter:'PLAYER'};
 const next={entries:[...prev,entry]};if(!valid(next))throw Error('Source event không hợp lệ hoặc đã vượt giới hạn.');return next;
}
function current(index,chatId,messageId){return (index?.entries||[]).filter(e=>e.chatId===chatId&&e.messageId===messageId).at(-1)||null;}
function excludedFromRecall(index,chatId,messageId){const e=current(index,chatId,messageId);return !!e&&['REPORTED_DELETED','REPORTED_SUPERSEDED','REPORTED_REGENERATED'].includes(e.kind);}
root.RPGMBSourceEvents={kinds,valid,record,current,excludedFromRecall};
})(typeof globalThis==='undefined'?self:globalThis);
