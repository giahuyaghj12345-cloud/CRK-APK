// Non-destructive DOM evidence. Messages without native UUID remain provisional.
// Cross-viewport matching is contextual, never proof of source identity/canon.
(function(root){
 'use strict';
 const norm=s=>String(s||'').replace(/\r\n?/g,'\n').replace(/\u00a0/g,' ').trim();
 const hex=a=>[...new Uint8Array(a)].map(x=>x.toString(16).padStart(2,'0')).join('');
 const digest=async s=>hex(await crypto.subtle.digest('SHA-256',new TextEncoder().encode(s)));
 const nativeId=id=>/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(String(id||''));
 function longestOverlap(oldTokens,tokens){
   let best=null,tie=false;
   for(let i=0;i<oldTokens.length;i++)for(let j=0;j<tokens.length;j++){
     if(oldTokens[i]!==tokens[j])continue;
     let len=0;
     while(i+len<oldTokens.length&&j+len<tokens.length&&oldTokens[i+len]===tokens[j+len])len++;
     const minLen=(oldTokens.length===1||tokens.length===1)&&i===0&&j===0?1:2;
     if(len<minLen)continue;
     const signature=oldTokens.slice(i,i+len).join('|');
     const count=(ary)=>{let n=0;for(let k=0;k+len<=ary.length;k++)if(ary.slice(k,k+len).join('|')===signature)n++;return n;};
     if(count(oldTokens)!==1||count(tokens)!==1)continue;
     if(!best||len>best.len){best={i,j,len,score:len};tie=false;}
     else if(len===best.len&&(best.i!==i||best.j!==j))tie=true;
   }
   return tie?null:best;
 }
 // Observations of old pages may be revisited hundreds of frames after first
 // capture. A fixed "last 30" window gave them NEW IDs on reload and scrollback.
 // Use all trusted frames, prefiltered by exact adjacent contextual anchors.
 function selectContext(scoped,tokens,visible=[],byId=new Map()){
   const pairs=new Set();
   for(let i=1;i<tokens.length;i++)pairs.add(tokens[i-1]+'|'+tokens[i]);
   const candidates=[];
   for(let fi=0;fi<scoped.length;fi++){
     const frame=scoped[fi],turns=Array.isArray(frame.turns)?frame.turns:[];
     const oldTokens=turns.map(t=>t.token);
     if(!oldTokens.length)continue;
     // One edited/Regenerated slot may split the viewport into two equally
     // long overlaps. Match both flanks by INDEX, not just the longest flank.
     if(oldTokens.length===tokens.length&&tokens.length>=3){
       const different=[];let exact=0;
       for(let k=0;k<tokens.length;k++)if(oldTokens[k]===tokens[k])exact++;else different.push(k);
       if(different.length===1&&exact>=2){
         candidates.push({frame,fi,score:100000+exact,kind:'aligned',slot:different[0],
           matched:tokens.map((t,k)=>oldTokens[k]===t?k:null).filter(k=>k!==null)});
         continue;
       }
     }
     // Match a streamed assistant message that expanded in its original slot.
     // Requires an exact unchanged anchor, same slot ordering, and a long
     // assistant prefix. Mere same-text USER choices cannot trigger this.
     if(oldTokens.length>=2&&oldTokens.length<=tokens.length&&visible.length>=oldTokens.length){
       let exact=0,growing=0,valid=true;
       for(let k=0;k<oldTokens.length;k++){
         if(oldTokens[k]===tokens[k]){exact++;continue;}
         const previous=byId.get(turns[k]?.observationId),newer=visible[k];
         const oldText=norm(previous?.text),newText=norm(newer?.text);
         if(previous?.role==='assistant'&&newer?.role==='assistant'&&oldText.length>=100&&
           newText.length>=oldText.length+20&&newText.startsWith(oldText)){growing++;continue;}
         valid=false;break;
       }
       if(valid&&exact>=1&&growing>=1&&exact+growing===oldTokens.length){
         candidates.push({frame,fi,score:200000+exact*10+growing,kind:'progressive',
           matched:oldTokens.map((t,k)=>t===tokens[k]?k:null).filter(k=>k!==null)});
         continue;
       }
     }
     if(!pairs.size)continue;
     let hasPair=false;
     for(let k=1;k<oldTokens.length;k++)if(pairs.has(oldTokens[k-1]+'|'+oldTokens[k])){hasPair=true;break;}
     if(!hasPair)continue;
     const overlap=longestOverlap(oldTokens,tokens);
     if(overlap)candidates.push({frame,fi,score:overlap.len,kind:'overlap',overlap,
       matched:Array.from({length:overlap.len},(_,k)=>overlap.j+k)});
   }
   if(!candidates.length)return null;
   candidates.sort((a,b)=>b.score-a.score||b.fi-a.fi);
   const max=candidates[0].score,leaders=candidates.filter(x=>x.score===max);
   const identityAt=(entry,index)=>{
     const source=(entry.kind==='aligned'||entry.kind==='progressive')?index:entry.overlap.i+index-entry.overlap.j;
     return entry.frame.turns[source]?.observationId||entry.frame.turns[source]?.nativeId||null;
   };
   // Equal-quality frames with DISAGREEING evidence IDs are not safe to merge.
   // Prefer preserving an extra observation over silently splicing two branches.
   for(let i=1;i<leaders.length;i++){
     const a=leaders[0],b=leaders[i];
     for(const pos of a.matched)if(b.matched.includes(pos)&&identityAt(a,pos)!==identityAt(b,pos))return null;
   }
   return leaders[0];
 }
 async function reconcile(oldOccurrences,oldFrames,visible,now,chatId=null,sourceUrl=null,campaignId=null){
   const occurrences=Array.isArray(oldOccurrences)?[...oldOccurrences]:[];
   const frames=Array.isArray(oldFrames)?[...oldFrames]:[];
   const byId=new Map(occurrences.map(x=>[x.observationId,x]));
   const scoped=frames.filter(f=>f?.chatId===chatId&&f.sourceUrl===sourceUrl&&f.campaignId===campaignId&&!!chatId&&Array.isArray(f.turns));
   const tokens=await Promise.all(visible.map(m=>digest(m.role+'\u001f'+norm(m.text))));
   const signature=await digest(JSON.stringify(tokens));
   if(scoped.some(f=>f.signature===signature))return {occurrences,frames,newFrame:false};
   const context=selectContext(scoped,tokens,visible,byId);
   const old=context?.frame||null;
   const variantSlot=context?.kind==='aligned'?context.slot:-1;
   const turns=visible.map((m,slot)=>{
     let prev=null;
     if(context?.kind==='aligned'&&slot!==variantSlot)prev=old.turns[slot];
     else if(context?.kind==='progressive'&&slot<old.turns.length)prev=old.turns[slot];
     else if(context?.kind==='overlap'){
       const {i,j,len}=context.overlap;
       if(slot>=j&&slot<j+len)prev=old.turns[i+slot-j];
     }
     if(nativeId(m.id))return {token:tokens[slot],nativeId:m.id,role:m.role};
     const previous=prev?.observationId&&byId.get(prev.observationId);
     let entry=previous&&norm(previous.text)===norm(m.text)?previous:null;
     if(!entry){entry={observationId:crypto.randomUUID(),sourceChatId:chatId,sourceUrl,
       captureOrigin:'live-conversation-dom-v090',role:m.role,text:norm(m.text),
       firstSeen:now,lastSeen:now,campaignId,verified:false,source:'dom-viewport-evidence',contextOnly:false,
       captureStatus:m.captureStatus||'visible-dom',method:m.method||'unknown'};
       occurrences.push(entry);byId.set(entry.observationId,entry);
     }else entry.lastSeen=now;
     if(context?.kind==='progressive'&&previous&&previous.observationId!==entry.observationId){
       const a=norm(previous.text),b=norm(entry.text);
       if(previous.role==='assistant'&&a.length>=100&&b.length>a.length+20&&b.startsWith(a)){
         previous.supersededBy=entry.observationId;
         previous.supersessionReason='same-slot-prefix-expansion';
         entry.continuationOf=previous.observationId;
         entry.observationStatus='expanded-answer';
       }
     }
     if(context?.kind==='aligned'&&slot===variantSlot){
       const previous=old.turns[slot]?.observationId&&byId.get(old.turns[slot].observationId);
       if(previous&&previous.observationId!==entry.observationId&&previous.role===m.role){
         const earlier=norm(previous.text),later=norm(entry.text);
         const growing=m.role==='assistant'&&earlier.length>=40&&later.length>earlier.length+20&&later.startsWith(earlier);
         if(growing){previous.supersededBy=entry.observationId;previous.supersessionReason='same-slot-prefix-expansion';
           entry.continuationOf=previous.observationId;entry.observationStatus='expanded-answer';}
         else if(earlier!==later){
           const a=new Set(previous.alternativeCandidates||[]),b=new Set(entry.alternativeCandidates||[]);
           a.add(entry.observationId);b.add(previous.observationId);
           previous.alternativeCandidates=[...a];entry.alternativeCandidates=[...b];
           previous.branchUncertain=true;entry.branchUncertain=true;
         }
       }
     }
     return {token:tokens[slot],observationId:entry.observationId,role:m.role};
   });
   frames.push({frameId:crypto.randomUUID(),chatId,sourceUrl,campaignId,signature,at:now,turns});
   return {occurrences,frames,newFrame:true};
 }
 root.RPGMBIdentity={reconcile,longestOverlap,nativeId,selectContext};
})(typeof globalThis!=='undefined'?globalThis:this);
