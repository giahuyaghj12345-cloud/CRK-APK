// RPGMB immutable archive codec v2. Source UUID and DOM observation identity remain separate.
// No Chrome, network, or Google Drive dependency. This module never mutates input storage.
(function(root){
'use strict';
const UUID=/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
const proof='same-turn-native-id-role-v081';
const encoder=new TextEncoder();
// Bound untrusted archive inputs before JSON parsing. These are per-file limits;
// large campaigns should export multiple chunks rather than one unbounded blob.
const MAX_GZIP_BYTES=48*1024*1024,MAX_JSON_BYTES=192*1024*1024;
const safeCampaignId=id=>typeof id==='string'&&/^[a-zA-Z0-9_-]{1,180}$/.test(id)&&!['__proto__','constructor','prototype'].includes(id);
const safeSectionKey=k=>/^[a-zA-Z_]{2,40}$/.test(k)&&!['__proto__','constructor','prototype'].includes(k);
function validateCampaignMeta(id,camp){
 if(!safeCampaignId(id)||!camp||typeof camp!=='object'||Array.isArray(camp)||
  typeof camp.name!=='string'||!camp.name.trim()||camp.name.length>256||
  !camp.sections||typeof camp.sections!=='object'||Array.isArray(camp.sections)||
  Object.entries(camp.sections).some(([k,v])=>!safeSectionKey(k)||typeof v!=='string'||v.length>500000))
  throw Error('Metadata Campaign/sections không hợp lệ');
 if(camp.dayIndex&&!root.RPGMBDay?.validIndex(camp.dayIndex))throw Error('Day index trong archive không hợp lệ.');
 if(camp.branchIndex&&!root.RPGMBBranch?.validateIndex(camp.branchIndex))throw Error('Archive có branchIndex không hợp lệ hoặc có vòng lặp; từ chối khôi phục.');
 if(camp.sourceEvents&&!root.RPGMBSourceEvents?.valid(camp.sourceEvents))throw Error('Source events trong archive không hợp lệ.');
}

const chatUrl=id=>'https://chatgpt.com/c/'+id;
function stable(v){if(Array.isArray(v))return v.map(stable);if(v&&typeof v==='object')return Object.fromEntries(Object.keys(v).sort().map(k=>[k,stable(v[k])]));return v;}
const canonical=x=>JSON.stringify(stable(x));
async function sha(bytes){return [...new Uint8Array(await crypto.subtle.digest('SHA-256',bytes))].map(b=>b.toString(16).padStart(2,'0')).join('');}
async function gzip(bytes){if(typeof CompressionStream==='undefined')throw Error('Trình duyệt chưa hỗ trợ gzip CompressionStream');return new Uint8Array(await new Response(new Blob([bytes]).stream().pipeThrough(new CompressionStream('gzip'))).arrayBuffer());}
async function gunzip(bytes,limit=MAX_JSON_BYTES){
 if(typeof DecompressionStream==='undefined')throw Error('Trình duyệt chưa hỗ trợ giải nén');
 if(!bytes||bytes.byteLength>MAX_GZIP_BYTES)throw Error('Archive vượt giới hạn kích thước gzip.');
 if(!Number.isSafeInteger(limit)||limit<=0||limit>MAX_JSON_BYTES)throw Error('Giới hạn giải nén không hợp lệ.');
 const reader=new Blob([bytes]).stream().pipeThrough(new DecompressionStream('gzip')).getReader();
 let size=0;const chunks=[];
 try{
  for(;;){const {done,value}=await reader.read();if(done)break;
   size+=value.byteLength;
   if(size>limit){await reader.cancel().catch(()=>{});throw Error('Archive vượt giới hạn kích thước giải nén.');}
   chunks.push(value);
  }
 }finally{reader.releaseLock();}
 const out=new Uint8Array(size);let offset=0;
 for(const b of chunks){out.set(b,offset);offset+=b.length;}
 return out;
}
function trustedChat(c,id){return !!c&&c.chatId===id&&(!c.sourceUrl||c.sourceUrl===chatUrl(id));}
function trustedProvisional(o,id){return !!o&&UUID.test(o.observationId)&&o.sourceChatId===id&&o.sourceUrl===chatUrl(id)&&o.captureOrigin==='live-conversation-dom-v090'&&['user','assistant'].includes(o.role)&&typeof o.text==='string'&&!!o.text.trim()&&o.verified!==true;}
function trustedFrame(f,id){return !!f&&UUID.test(f.frameId)&&f.chatId===id&&f.sourceUrl===chatUrl(id)&&Array.isArray(f.turns)&&typeof f.signature==='string';}
function collect(store,campaignId){
 const camp=(store['rpgmb-campaigns-v04']||{})[campaignId];if(!camp)throw Error('Campaign không tồn tại');
 validateCampaignMeta(campaignId,camp);
 const assign=store['rpgmb-assign-v04']||{};const records=[],warnings=[],chatTitles={},verifiedOrderByChat={};
 const counts={verified:0,provisional:0,frames:0};
 for(const [chatId,owner] of Object.entries(assign).sort()){
  if(owner!==campaignId)continue;
  if(!UUID.test(chatId)){warnings.push('Bad chat UUID: '+chatId);continue;}
  const c=store['rpgmb:'+chatId];if(!trustedChat(c,chatId)){warnings.push('Missing/mismatched chat: '+chatId);continue;}
  chatTitles[chatId]=typeof c.title==='string'?c.title:'';
  // Sequence evidence is kept separately from deterministic hash/UUID record ordering.
  // Legacy v0.9.9 imports may already have UUID-sorted arrays; unique native capture
  // positions take precedence over array order when they can establish a full order.
  const verifiedRows=(c.messages||[]).filter(m=>m?.identityVerified===true&&m?.identityProof===proof&&UUID.test(m?.id)&&['user','assistant'].includes(m?.role)&&typeof m?.text==='string');
  const indices=verifiedRows.map(m=>Number.isSafeInteger(m.canonicalIndex)&&m.canonicalIndex>0?m.canonicalIndex:m.position);
  const positionProven=indices.every(n=>Number.isSafeInteger(n)&&n>0)&&new Set(indices).size===indices.length;
  const orderedSource=positionProven?verifiedRows.map((m,i)=>({m,n:indices[i]})).sort((a,b)=>a.n-b.n).map(x=>x.m):verifiedRows;
  verifiedOrderByChat[chatId]=[...new Set(orderedSource.map(m=>m.id))];
  for(const m of c.messages||[]){
   if(!m||m.identityVerified!==true||m.identityProof!==proof||!UUID.test(m.id)||!['user','assistant'].includes(m.role)||typeof m.text!=='string')continue;
   records.push({format:'rpgmb-raw-record-v1',campaignId,chatId,messageId:m.id,role:m.role,text:m.text,
    revisions:Array.isArray(m.revisions)?m.revisions.filter(x=>typeof x?.text==='string').map(stable):[],
    firstSeen:m.firstSeen||null,lastSeen:m.lastSeen||null,sourceUrl:chatUrl(chatId),
    identityProof:proof,position:m.position??null,canonicalIndex:m.canonicalIndex??null});counts.verified++;
  }
  for(const o of c.provisionalOccurrences||[]){
   if(!trustedProvisional(o,chatId)){warnings.push('Untrusted DOM occurrence quarantined from portable archive: '+chatId);continue;}
   records.push({format:'rpgmb-dom-provisional-record-v2',campaignId,chatId,observationId:o.observationId,observation:stable({...o,verified:false})});counts.provisional++;
  }
  for(const frame of c.viewportEvidence||[]){
   if(!trustedFrame(frame,chatId)){warnings.push('Untrusted DOM frame excluded: '+chatId);continue;}
   records.push({format:'rpgmb-dom-frame-v2',campaignId,chatId,frameId:frame.frameId,frame:stable(frame)});counts.frames++;
  }
  if((c.legacyMessages||[]).length||(c.provisionalObservations||[]).length||(c.remoteEvidenceArchive||[]).length)
   warnings.push('Legacy/unscoped forensic evidence requires full JSON backup: '+chatId);
 }
 for(const range of camp.dayIndex?.ranges||[]){
  if(assign[range.chatId]!==campaignId)warnings.push('Day '+range.dayId+' tham chiếu chat chưa gán đúng Campaign: '+range.chatId);
  else if(!range.startId||!range.endId)warnings.push('Day '+range.dayId+' thiếu UUID mốc nguồn; cần backup JSON đầy đủ: '+range.chatId);
  else if(!verifiedOrderByChat[range.chatId]?.includes(range.startId)||!verifiedOrderByChat[range.chatId]?.includes(range.endId))
   warnings.push('Day '+range.dayId+' có mốc UUID chưa có trong RAW export: '+range.chatId);
 }
 const order={'rpgmb-raw-record-v1':0,'rpgmb-dom-provisional-record-v2':1,'rpgmb-dom-frame-v2':2};
 records.sort((a,b)=>a.chatId.localeCompare(b.chatId)||order[a.format]-order[b.format]||String(a.messageId||a.observationId||a.frameId).localeCompare(String(b.messageId||b.observationId||b.frameId)));
 return {records,warnings,counts,campaignId,metadata:{format:'rpgmb-campaign-archive-meta-v2',campaignId,campaign:stable(camp),assignment:Object.fromEntries(Object.entries(assign).filter(([,v])=>v===campaignId).sort()),chatTitles,verifiedOrderByChat,source:'local-extension',notice:'Verified UUID and DOM-only evidence are distinct. Not a complete ChatGPT export; keep full JSON backup.'}};
}
function chunk(records,maxRecords=80,maxChars=170000){const out=[];let batch=[],n=0;
 for(const rec of records){const length=canonical(rec).length;if(batch.length&&(batch.length>=maxRecords||n+length>maxChars)){out.push(batch);batch=[];n=0;}batch.push(rec);n+=length;}
 if(batch.length)out.push(batch);return out;}
async function encode(obj){const bytes=encoder.encode(canonical(obj));
 if(bytes.byteLength>MAX_JSON_BYTES)throw Error('Archive vượt giới hạn JSON; hãy chia thành các chunk nhỏ.');
 const hash=await sha(bytes),packed=await gzip(bytes);
 if(packed.byteLength>MAX_GZIP_BYTES)throw Error('Archive vượt giới hạn gzip; hãy chia thành các chunk nhỏ.');
 return {hash,packed,uncompressedBytes:bytes.byteLength,compressedBytes:packed.byteLength};}
async function decode(packed,expectedHash){if(!/^[0-9a-f]{64}$/i.test(String(expectedHash||'')))throw Error('Thiếu SHA-256 hợp lệ');
 const bytes=await gunzip(packed);const actual=await sha(bytes);if(actual!==expectedHash.toLowerCase())throw Error('SHA-256 mismatch: file archive không toàn vẹn');
 const doc=JSON.parse(new TextDecoder('utf-8',{fatal:true}).decode(bytes));if(!doc||!['rpgmb-archive-chunk-v1','rpgmb-archive-chunk-v2','rpgmb-campaign-archive-meta-v1','rpgmb-campaign-archive-meta-v2','rpgmb-portable-campaign-archive-v1','rpgmb-portable-campaign-archive-v2'].includes(doc.format))throw Error('Archive format không hợp lệ');return doc;}
async function plan(store,campaignId,seenRecordHashes=[]){const {records,warnings,metadata,counts}=collect(store,campaignId);const seen=new Set(seenRecordHashes);
 const unique=new Map();for(const r of records){const hash=await sha(encoder.encode(canonical(r)));if(!unique.has(hash))unique.set(hash,r);}
 const unsent=[...unique.entries()].filter(([h])=>!seen.has(h));const pendingChunks=[];
 for(const batch of chunk(unsent.map(([,r])=>r))){const doc={format:'rpgmb-archive-chunk-v2',records:batch};const encoded=await encode(doc);pendingChunks.push({...encoded,doc,recordHashes:await Promise.all(batch.map(r=>sha(encoder.encode(canonical(r)))))});}
 const meta=await encode(metadata);
 return {campaignId,sourceCount:records.length,counts,uniqueCount:unique.size,alreadyArchived:unique.size-unsent.length,newRecords:unsent.length,pendingChunks,metadata:{...meta,doc:metadata},warnings};
}
// Portable records are sorted by UUID for reproducible hashing, NOT conversational order.
// v0.9.9 portable exports did not carry explicit order but did retain `position`.
// We accept the legacy fallback only when every position is a unique positive integer.
// Otherwise fail closed: guessing an order can silently truncate source-UUID Day spans.
function verifiedSequence(part,meta,chatId){
 const rows=part.messages||[],ids=rows.map(m=>m.id),idSet=new Set(ids);
 if(idSet.size!==ids.length)throw Error('Trùng UUID trong archive: '+chatId);
 const order=meta.verifiedOrderByChat?.[chatId];
 if(order!==undefined){
  if(!Array.isArray(order)||order.length!==ids.length||new Set(order).size!==ids.length||!order.every(id=>idSet.has(id)))
   throw Error('Bằng chứng thứ tự RAW không khớp archive: '+chatId);
  return order;
 }
 if(rows.length<=1)return ids;
 const ranks=rows.map(m=>Number.isSafeInteger(m.canonicalIndex)&&m.canonicalIndex>0?m.canonicalIndex:m.position);
 if(ranks.every(n=>Number.isSafeInteger(n)&&n>0)&&new Set(ranks).size===ranks.length)
  return rows.map((m,i)=>({id:m.id,rank:ranks[i]})).sort((a,b)=>a.rank-b.rank).map(x=>x.id);
 throw Error('Không có bằng chứng thứ tự RAW đủ tin cậy cho chat '+chatId+'. Cần backup JSON đầy đủ hoặc xuất lại bằng phiên bản mới.');
}
function preserveVerifiedOrder(merged,order,chatId){
 const raw=merged.messages||[],map=new Map(raw.map(m=>[m.id,m]));
 // Rebuild the archived portion. Local-only new turns may safely follow it if
 // they were an unambiguous suffix; never silently move interleaved turns.
 if(map.size!==raw.length||order.some(id=>!map.has(id)))
  throw Error('Chat '+chatId+' có UUID thiếu/trùng sau merge; giữ local nguyên vẹn.');
 const archived=new Set(order),extra=raw.filter(m=>!archived.has(m.id));
 if(extra.length){
  const expectedPrefix=raw.slice(0,order.length);
  if(expectedPrefix.length!==order.length||expectedPrefix.some(m=>!archived.has(m.id)))
   throw Error('Chat '+chatId+' có RAW local xen giữa archive, chưa đủ bằng chứng thứ tự để hợp nhất.');
 }
 merged.messages=[...order.map(id=>map.get(id)),...extra];
 return merged;
}
// Validate everything before storage writes. Reject any contradictory ID or campaign metadata.
// Restore merges ONLY matching chat-ID records; no DOM provisional can turn into a native UUID.
function restorePlan(doc,store,safe){
 if(!doc||doc.format!=='rpgmb-portable-campaign-archive-v2'||!Array.isArray(doc.records)||doc.records.length>120000||!doc.metadata||doc.metadata.format!=='rpgmb-campaign-archive-meta-v2')throw Error('Chỉ hỗ trợ import archive portable v2');
 if(!safe?.mergeChatBackup||!safe?.trustedOccurrence)throw Error('Chưa có bộ kiểm tra provenance');
 const meta=doc.metadata,campaignId=meta.campaignId;
 validateCampaignMeta(campaignId,meta.campaign);
 if(!meta.assignment||typeof meta.assignment!=='object'||Array.isArray(meta.assignment)||
  Object.keys(meta.assignment).some(id=>!UUID.test(id)||meta.assignment[id]!==campaignId))
  throw Error('Metadata Assignment không hợp lệ');
 const own=(store['rpgmb-campaigns-v04']||{}),assign=(store['rpgmb-assign-v04']||{});
 if(own[campaignId]?.branchIndex&&!root.RPGMBBranch?.validateIndex(own[campaignId].branchIndex))
  throw Error('Branch index local hiện tại không hợp lệ; giữ nguyên và yêu cầu kiểm tra backup JSON.');
 if(own[campaignId]&&own[campaignId].name!==meta.campaign.name)throw Error('Campaign ID trùng nhưng tên khác; từ chối ghi');
 const perChat=new Map(),unique=new Map(),counts={verified:0,provisional:0,frames:0};
 for(const r of doc.records){
  if(!r||r.campaignId!==campaignId||!UUID.test(r.chatId)||meta.assignment[r.chatId]!==campaignId)throw Error('Record không thuộc Campaign/Chat đã xác nhận');
  if(assign[r.chatId]&&assign[r.chatId]!==campaignId)throw Error('Chat đang được gán Campaign khác: '+r.chatId);
  const id=r.format==='rpgmb-raw-record-v1'?r.messageId:r.format==='rpgmb-dom-provisional-record-v2'?r.observationId:r.format==='rpgmb-dom-frame-v2'?r.frameId:null;
  if(!id||!UUID.test(id))throw Error('ID bản ghi archive không hợp lệ');
  const key=r.chatId+'|'+r.format+'|'+id;
  if(unique.has(key)){if(canonical(unique.get(key))!==canonical(r))throw Error('ID archive bị trùng nhưng nội dung khác');continue;}unique.set(key,r);
  const part=perChat.get(r.chatId)||{chatId:r.chatId,sourceUrl:chatUrl(r.chatId),title:meta.chatTitles?.[r.chatId]||'Restored RAW '+r.chatId.slice(0,8),messages:[],provisionalOccurrences:[],viewportEvidence:[]};
  if(r.format==='rpgmb-raw-record-v1'){
   if(!['user','assistant'].includes(r.role)||typeof r.text!=='string'||r.identityProof!==proof||r.sourceUrl!==chatUrl(r.chatId))throw Error('RAW nguồn UUID không có chứng cứ hợp lệ');
   part.messages.push({id:r.messageId,role:r.role,text:r.text,identityVerified:true,verified:true,identityProof:proof,position:r.position??null,canonicalIndex:r.canonicalIndex??null,revisions:Array.isArray(r.revisions)?r.revisions:[],firstSeen:r.firstSeen||null,lastSeen:r.lastSeen||null});counts.verified++;
  }else if(r.format==='rpgmb-dom-provisional-record-v2'){
   if(r.observation?.observationId!==r.observationId||!safe.trustedOccurrence(r.observation,r.chatId)||r.observation.verified===true)throw Error('DOM evidence không đúng nguồn, từ chối');
   part.provisionalOccurrences.push({...r.observation,verified:false});counts.provisional++;
  }else if(r.format==='rpgmb-dom-frame-v2'){
   if(r.frame?.frameId!==r.frameId||!trustedFrame(r.frame,r.chatId))throw Error('Viewport frame không đúng nguồn');
   part.viewportEvidence.push(r.frame);counts.frames++;
  }else throw Error('Loại bản ghi archive chưa hỗ trợ');
  perChat.set(r.chatId,part);
 }
 // Restore native UUID sequence before any Day UUID boundary is evaluated.
 for(const [chatId,part] of perChat)part.__verifiedSequence=verifiedSequence(part,meta,chatId);
 for(const [chatId,value] of Object.entries(meta.assignment)){
  if(!UUID.test(chatId)||value!==campaignId)throw Error('Assignment archive không hợp lệ');
  if(assign[chatId]&&assign[chatId]!==campaignId)throw Error('Chat đang được gán Campaign khác: '+chatId);
  // Preserve assignment of chats with zero archived turns without manufacturing RAW.
  if(!perChat.has(chatId))perChat.set(chatId,{chatId,sourceUrl:chatUrl(chatId),title:meta.chatTitles?.[chatId]||'Restored empty chat '+chatId.slice(0,8),messages:[],provisionalOccurrences:[],viewportEvidence:[],__verifiedSequence:[]});
 }
 const updates={},newCampaigns={...own},newAssign={...assign},warnings=[];
 // Archive metadata is not always newer than local metadata. Restore only
 // missing fields. Any divergent field remains LOCAL and surfaces a warning;
 // silently dropping Day/Branch is unacceptable for forensic backup.
 const current=own[campaignId];
 if(!current){newCampaigns[campaignId]=stable(meta.campaign);}
 else{
  if(!current.sections||typeof current.sections!=='object'||Array.isArray(current.sections))
   throw Error('Campaign local có sections không hợp lệ; giữ nguyên dữ liệu.');
  const combined={...current,sections:{...current.sections}};
  for(const [section,value] of Object.entries(meta.campaign.sections)){
   if(!Object.hasOwn(combined.sections,section))combined.sections[section]=value;
   else if(canonical(combined.sections[section])!==canonical(value))warnings.push('Metadata khác local: sections.'+section+'; giữ local, không ghi đè.');
  }
  for(const field of ['dayIndex','branchIndex','sourceEvents']){
   if(meta.campaign[field]===undefined)continue;
   if(combined[field]===undefined||combined[field]===null)combined[field]=stable(meta.campaign[field]);
   else if(canonical(combined[field])!==canonical(meta.campaign[field]))
    warnings.push('Metadata khác local: '+field+'; giữ local, cần đối chiếu riêng.');
  }
  newCampaigns[campaignId]=combined;
 }
 // Verify the combined metadata before any storage update is returned.
 if(newCampaigns[campaignId].dayIndex&&(!root.RPGMBDay?.validIndex(newCampaigns[campaignId].dayIndex)))
  throw Error('Day index local sau khôi phục không hợp lệ.');
 if(newCampaigns[campaignId].branchIndex&&(!root.RPGMBBranch?.validateIndex(newCampaigns[campaignId].branchIndex)))
  throw Error('Branch index local sau khôi phục không hợp lệ.');
 if(newCampaigns[campaignId].sourceEvents&&(!root.RPGMBSourceEvents?.valid(newCampaigns[campaignId].sourceEvents)))
  throw Error('Source events local sau khôi phục không hợp lệ.');
 for(const [chatId,part] of perChat){const key='rpgmb:'+chatId,old=store[key];if(old&&!safe.matchesChat(old,key))throw Error('Chat local có nguồn không hợp lệ: '+chatId);
  const {__verifiedSequence:sequence,...cleanPart}=part;
  const merged=safe.mergeChatBackup(old,cleanPart);
  updates[key]=preserveVerifiedOrder(merged,sequence,chatId);
  const pastEvidence=Array.isArray(old?.importConflictEvidence)?old.importConflictEvidence:[];
  const currentEvidence=Array.isArray(updates[key].importConflictEvidence)?updates[key].importConflictEvidence:[];
  if(currentEvidence.length>pastEvidence.length)
   warnings.push('⚠️ Chat '+chatId+' có '+(currentEvidence.length-pastEvidence.length)+' bằng chứng xung đột RAW/DOM khi nhập; giữ bản local, cần đối chiếu.');
  newAssign[chatId]=campaignId;}
 // Do not silently remap existing chat assignments or overwrite existing campaign content.
 // Day boundaries are UUID anchors. A successful import must not leave
 // an inverted/missing anchor after reconstruction. Abort before writing anything.
 for(const range of newCampaigns[campaignId]?.dayIndex?.ranges||[]){
  if(newAssign[range.chatId]!==campaignId)throw Error('Day tham chiếu chat không thuộc Campaign: '+range.chatId);
  if(!range.startId||!range.endId){warnings.push('Day '+range.dayId+' chỉ có ordinal, không có UUID mốc; chưa xác minh đầy đủ.');continue;}
  const c=updates['rpgmb:'+range.chatId]||store['rpgmb:'+range.chatId];
  if(!c)throw Error('Archive thiếu chat chứa mốc Day: '+range.chatId);
  const messages=root.RPGLedger?.ledger?root.RPGLedger.ledger(c).messages:c.messages||[];
  const a=messages.findIndex(m=>m.id===range.startId),b=messages.findIndex(m=>m.id===range.endId);
  if(a<0||b<a)throw Error('Mốc UUID của Day bị thiếu/đảo thứ tự sau khôi phục: '+range.chatId);
 }
 updates['rpgmb-campaigns-v04']=newCampaigns;updates['rpgmb-assign-v04']=newAssign;
 return {updates,counts,campaignId,chatCount:perChat.size,warnings};
}
root.RPGMBArchive={stable,canonical,sha,gzip,gunzip,encode,decode,collect,chunk,plan,restorePlan,limits:{maxCompressedBytes:MAX_GZIP_BYTES,maxDecodedBytes:MAX_JSON_BYTES,maxRecords:120000}};
})(typeof globalThis==='undefined'?self:globalThis);
