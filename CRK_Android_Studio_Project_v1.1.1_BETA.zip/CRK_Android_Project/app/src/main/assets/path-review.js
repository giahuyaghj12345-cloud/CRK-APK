// User-chosen DOM path. A local review is NOT source-native verification, and
// never silently upgrades an observation to official ChatGPT/canon identity.
(function(root){
'use strict';
const norm=s=>String(s||'').replace(/\r\n?/g,'\n').replace(/\u00a0/g,' ').trim();
const valid=o=>o&&typeof o.observationId==='string'&&['user','assistant'].includes(o.role)&&typeof o.text==='string'&&!!norm(o.text);
function observationMap(chat){
 const ids=new Map();
 for(const o of chat?.provisionalOccurrences||[])if(valid(o)&&o.sourceChatId===chat.chatId&&o.sourceUrl===chat.sourceUrl&&o.captureOrigin==='live-conversation-dom-v090')ids.set(o.observationId,o);
 return ids;
}
function pathStatus(chat,projection){
 const chosen=chat?.reviewedPath,live=(projection?.turns||[]).filter(valid);
 if(!chosen)return {kind:'not-reviewed',reviewed:0,candidate:live.length,additional:0,firstChange:null};
 const ids=chosen.ids||[],sourceOk=chosen.chatId===chat.chatId&&chosen.sourceUrl===chat.sourceUrl;
 const map=observationMap(chat),missing=ids.filter(id=>!map.has(id));
 if(!sourceOk||missing.length)return {kind:'broken',reviewed:ids.length,candidate:live.length,missing,additional:0,firstChange:null};
 let firstChange=0;
 while(firstChange<ids.length&&firstChange<live.length&&ids[firstChange]===live[firstChange].observationId)firstChange++;
 if(firstChange<ids.length)return {kind:'changed',reviewed:ids.length,candidate:live.length,additional:0,firstChange};
 if(live.length<ids.length)return {kind:'changed',reviewed:ids.length,candidate:live.length,additional:0,firstChange:live.length};
 if(live.length===ids.length)return {kind:'current',reviewed:ids.length,candidate:live.length,additional:0,firstChange:null};
 const newIssues=(projection.issues||[]).length>(chosen.issueCount||0)||
   (projection.replaced||[]).length>(chosen.replacedCount||0)||
   (projection.reobserved||[]).length>(chosen.reobservedCount||0);
 return {kind:!projection.connected||newIssues?'changed':'appended',reviewed:ids.length,
  candidate:live.length,additional:live.length-ids.length,firstChange:ids.length};
}
function candidateList(projection){return (projection?.turns||[]).filter(valid).map(o=>o.observationId);}
async function sha256(str){
 const bytes=new TextEncoder().encode(str),sum=await crypto.subtle.digest('SHA-256',bytes);
 return [...new Uint8Array(sum)].map(n=>n.toString(16).padStart(2,'0')).join('');
}
async function seal(chat,ids){
 const byId=observationMap(chat);
 if(!ids?.length||new Set(ids).size!==ids.length||ids.some(id=>!byId.has(id)))throw Error('Một số lượt không còn chứng cứ DOM hợp lệ');
 const selected=ids.map(id=>{const x=byId.get(id);return [id,x.role,norm(x.text)];});
 return sha256(JSON.stringify([chat.chatId,chat.sourceUrl,selected]));
}
async function approve(chat,projection,at){
 if(!chat?.chatId||!chat?.sourceUrl)throw Error('Chat chưa có nguồn rõ ràng');
 if(!projection?.turns?.length)throw Error('Không có lượt để duyệt');
 const ids=candidateList(projection),checksum=await seal(chat,ids),previous=chat.reviewedPath;
 if(previous?.digest===checksum)return {chat,changed:false};
 const approved={schema:1,reviewId:crypto.randomUUID(),reviewedAt:at||new Date().toISOString(),
  chatId:chat.chatId,sourceUrl:chat.sourceUrl,kind:'USER_SELECTED_DOM_PATH_NOT_SOURCE_VERIFIED',
  ids,digest:checksum,issueCount:projection.issues?.length||0,
  replacedCount:projection.replaced?.length||0,reobservedCount:projection.reobserved?.length||0,
  connected:!!projection.connected,frameCount:projection.frameCount};
 const history=[...(chat.reviewedPathHistory||[])];
 if(previous)history.push(previous);
 return {chat:{...chat,reviewedPath:approved,reviewedPathHistory:history},changed:true};
}
async function reviewedTurns(chat){
 const path=chat?.reviewedPath;
 if(!path||path.chatId!==chat.chatId||path.sourceUrl!==chat.sourceUrl)return {turns:[],error:'Không có đường DOM đã duyệt hợp lệ'};
 const byId=observationMap(chat),turns=(path.ids||[]).map(id=>byId.get(id));
 if(turns.some(x=>!x))return {turns:[],error:'Bản đã duyệt thiếu observation trong JSON; không được âm thầm xuất thiếu'};
 const check=await seal(chat,path.ids);
 if(check!==path.digest)return {turns:[],error:'Nội dung chứng cứ khác bản đã duyệt (checksum không khớp); giữ JSON để kiểm tra'};
 return {turns,error:null};
}
function reviewedTurnsSync(chat){
 const path=chat?.reviewedPath;
 if(!path||path.chatId!==chat.chatId||path.sourceUrl!==chat.sourceUrl)return [];
 const byId=observationMap(chat),turns=(path.ids||[]).map(id=>byId.get(id));
 return turns.every(Boolean)?turns:[];
}
root.RPGMBPathReview={observationMap,pathStatus,candidateList,seal,approve,reviewedTurns,reviewedTurnsSync};
})(typeof globalThis!=='undefined'?globalThis:this);
