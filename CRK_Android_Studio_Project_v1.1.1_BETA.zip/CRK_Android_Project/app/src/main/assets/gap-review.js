// v1.0.2. Read-only review export for a known break in DOM capture.
// NEVER pass these synthetic separators to the selected canon/TXT projection.
(function(root){
'use strict';
const norm=s=>String(s||'').replace(/\r\n?/g,'\n').trim();
const role=o=>o.role==='user'?'PLAYER':'GM';
function generate(items,version='1.0.2'){
 const filtered=(items||[]).filter(x=>x?.projection?.detachedTail?.count);
 if(!filtered.length)return null;
 const out=[
  'CRK CAMPAIGN RAW KEEPER v'+version+' · BẢN ĐỐI CHIẾU HAI ĐOẠN CÓ KHOẢNG TRỐNG',
  '⚠️ KHÔNG PHẢI CANON. Không có UUID ChatGPT xác minh, không chứng minh được nhánh hiện hành.',
  '⚠️ DỮ LIỆU GIỮA HAI ĐOẠN CÓ THỂ CHƯA ĐƯỢC CAPTURE. KHÔNG SUY ĐOÁN, KHÔNG ĐÁNH SỐ LIÊN TỤC CHO PHẦN RỜI.',
  'Chỉ dùng để GM/PLAYER đọc, đánh dấu khoảng trống và tự đối chiếu với lịch sử ChatGPT.',
  'Bản này được tạo từ bộ chiếu TXT đang chọn và cụm RAW rời; không sửa Campaign JSON, local hoặc Cloud.'
 ];
 for(const {c,projection:p} of filtered){
  const r=p.detachedTail,path=p.turns||[];
  out.push('===== CHAT '+(c.title||c.chatId)+' | '+c.chatId+' =====');
  out.push('ĐOẠN A: '+path.length+' lượt ứng viên đang được chọn. '+path.filter(x=>x.role==='user').length+' PLAYER + '+path.filter(x=>x.role==='assistant').length+' GM.');
  out.push('ĐOẠN B: '+r.count+' lượt rời chưa nối. '+r.userCount+' PLAYER + '+r.gmCount+' GM.');
  out.push('Lựa chọn nhánh máy này: '+(p.branchChoice||'Chưa có')+'. Không chứng nhận đây là nhánh hoạt động trên máy chủ.');
  if(p.retroFork?.requiresChoice)out.push('⚠️ Chưa chọn nhánh Edit trước khoảng trống: phần A chỉ là lịch sử chung.');
  out.push('---------- ĐOẠN A · TXT ĐÃ CHỌN · BẮT ĐẦU ----------');
  path.forEach((o,i)=>out.push('[A #'+(i+1)+' · '+role(o)+' · '+(o.observationId||'NO_DOM_ID')+' · CHƯA XÁC MINH UUID]\n'+norm(o.text)));
  out.push('---------- ĐOẠN A · KẾT THÚC ----------');
  out.push('============================================================');
  out.push('⚠️ KHOẢNG TRỐNG CAPTURE / NHÁNH CHƯA XÁC MINH');
  out.push('Lượt cuối đoạn A: '+(path.length?role(path.at(-1)):'không có')+' · '+norm(path.at(-1)?.text||'').slice(0,280));
  out.push('Lượt đầu đoạn B: '+role(r.turns[0])+' · '+norm(r.turns[0]?.text||'').slice(0,280));
  out.push('Không biết chính xác bao nhiêu lượt không được lưu giữa hai đoạn. KHÔNG dùng đoạn này để suy ra kết quả chiến đấu hoặc trạng thái NPC.');
  out.push('Không tự động nối vào canon. Nếu muốn tiếp tục RPG, cần lấy bổ sung lịch sử ChatGPT hoặc PLAYER xác nhận checkpoint thay thế.');
  out.push('============================================================');
  out.push('---------- ĐOẠN B · RAW RỜI · KHÔNG TÍNH TIẾP SỐ A ----------');
  if(r.pendingEdit)out.push('⚠️ Có sửa PLAYER được quan sát. Đối chiếu phiên bản đã gửi với ChatGPT. Các bản nháp không nằm trong đoạn này.');
  r.turns.forEach((o,i)=>out.push('[B #'+(i+1)+' · '+role(o)+' · '+(o.observationId||'NO_DOM_ID')+' · RỜI / CHƯA NỐI]\n'+norm(o.text)));
  out.push('---------- ĐOẠN B · KẾT THÚC ----------');
  if(r.turns.at(-1)?.role==='user')out.push('⚠️ Đoạn B kết thúc bằng PLAYER, KHÔNG có GM trả lời tương ứng trong phần này.');
  out.push('KẾT LUẬN: Đây là tập bằng chứng để đối chiếu, KHÔNG được xem là TXT canon liền mạch. Giữ Backup JSON chứa toàn bộ Edit/Retry và quan sát khác.');
 }
 return out.join('\n\n');
}
root.RPGMBGapReview={generate,version:'1.0.2'};
})(typeof globalThis!=='undefined'?globalThis:this);
