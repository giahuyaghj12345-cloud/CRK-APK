// RPG RAW Keeper v1.0.0 | Evidence Reconstruction Core.
// Read-only projection. A DOM observation is evidence, NOT an authoritative
// ChatGPT message ID, and a viewport order is NOT the active branch oracle.
// Compatibility: the prior projector supplies conservative, user-selected
// branch roots and alternatives. THIS core independently handles renderer
// states, revisions, ordered continuation, integrity and diagnostic reporting.
(function(root){
'use strict';
const API=root.RPGMBTimeline;if(!API)return;
const legacyProject=API.project;
const clean=s=>String(s||'').replace(/\r\n?/g,'\n').replace(/\u00a0/g,' ').replace(/\s+/g,' ').trim();
const isDraft=o=>o?.role==='user'&&/(?:^|\n)\s*(?:Hủy|Huỷ)\s*\n\s*Gửi\s*$/i.test(String(o.text||'').slice(-180));
const isAssistant=o=>o?.role==='assistant';
const isNarrative=t=>t.length>=650 && !isProgress(t);
function isProgress(s){
 const t=clean(s);
 if(t.length<25||t.length>1100)return false;
 // Only a status cue, not a blanket rule that a short RPG scene is invalid.
 return /^(?:Mình sẽ|Tôi sẽ|Tôi đang|Đã xử lý|Đã xác định|Đã kiểm tra|Đang kiểm tra|Đúng[,!.]?\s.{0,500}(?:mình sẽ|tôi sẽ|tôi đang)|Rõ[,!.]?\s.{0,400}(?:mình sẽ|tôi sẽ)|Được[,!.]?\s.{0,400}(?:mình sẽ|tôi sẽ))/i.test(t);
}
function stateOf(o){
 if(!o)return 'missing';
 if(isDraft(o))return 'editor-draft';
 if(o.role!=='assistant')return 'player';
 if(isProgress(o.text))return 'progress-status';
 if(o.supersededBy||o.observationStatus==='expanded-answer')return 'streaming-evidence';
 return 'observed-GM-unknown-completion';
}
function evidence(chat){
 const occurrences=(chat?.provisionalOccurrences||[]).filter(o=>o?.observationId&&
   o.sourceChatId===chat.chatId&&o.sourceUrl===chat.sourceUrl&&
   o.captureOrigin==='live-conversation-dom-v090'&&
   (o.role==='user'||o.role==='assistant')&&typeof o.text==='string'&&clean(o.text));
 const byId=new Map(occurrences.map(o=>[o.observationId,o]));
 const views=(chat?.viewportEvidence||[]).filter(f=>f?.chatId===chat.chatId&&
   f?.sourceUrl===chat.sourceUrl&&Array.isArray(f.turns)&&f.turns.length&&
   f.turns.every(t=>byId.has(t.observationId)));
 const textCache=new Map(occurrences.map(o=>[o.observationId,clean(o.text)]));
 const role=id=>byId.get(id)?.role,txt=id=>textCache.get(id)||'';
 const equal=(a,b)=>!!a&&!!b&&role(a)===role(b)&&txt(a)===txt(b);
 // A frame can display a progress bubble, then its full GM answer. Or it may
 // display progressively expanding renderers. These are ONE position only
 // when there is proof of status-then-answer or exact prefix expansion.
 // Different substantial GM outputs remain conflicts and are never collapsed.
 const frames=views.map((f,fi)=>{
  const ids=f.turns.map(t=>t.observationId), turns=[],skipped=[];
  for(let i=0;i<ids.length;i++){
   const id=ids[i],o=byId.get(id);
   if(isDraft(o)){skipped.push({id,why:'editor-draft'});continue;}
   let chosen=id,j=i;
   if(role(id)==='assistant'){
    while(j+1<ids.length&&role(ids[j+1])==='assistant'){
     const x=txt(chosen),y=txt(ids[j+1]);
     const prefix=x.length>=40&&y.length>x.length+20&&y.startsWith(x);
     const status=isProgress(x)&&isNarrative(y);
     const auxiliary=x.length<500&&isNarrative(y)&&!isNarrative(x)&&
       // A short progress bubble can have a different opener than the final.
       (isProgress(x)||/^(?:Đã|Tóm tắt|Đang|Kiểm tra|Xác nhận)/i.test(x));
     if(prefix||status||auxiliary){skipped.push({id:chosen,why:prefix?'stream-prefix':'progress-auxiliary'});chosen=ids[++j];}
     else break;
    }
   }
   turns.push(chosen);i=j;
  }
  return {f,fi,ids:turns,skipped};
 });
 return {occurrences,byId,frames,role,txt,equal};
}
function selectMatches(frame,path,E){
 // Bounded weighted LCS. The last ~30 turns of an EXPLICIT chosen branch
 // carry positional context. Distinct long GM renderers are the primary anchors.
 const start=Math.max(0,path.length-32),a=frame,b=path.slice(start),m=a.length,n=b.length;
 const dp=Array.from({length:m+1},()=>new Float64Array(n+1));
 const weight=id=>E.role(id)==='assistant'&&E.txt(id).length>=300?100:
   E.role(id)==='user'&&E.txt(id).length>=24?28:3;
 for(let i=m-1;i>=0;i--)for(let j=n-1;j>=0;j--){
  const paired=E.equal(a[i],b[j])?weight(a[i])+dp[i+1][j+1]:-1;
  dp[i][j]=Math.max(paired,dp[i+1][j],dp[i][j+1]);
 }
 const matches=[];let i=0,j=0;
 while(i<m&&j<n){const paired=E.equal(a[i],b[j])?weight(a[i])+dp[i+1][j+1]:-1;
  if(paired>0&&paired>=dp[i+1][j]-0.001&&paired>=dp[i][j+1]-0.001){
   matches.push({i,j:j+start,id:a[i]});i++;j++;
  }else if(dp[i+1][j]>dp[i][j+1])i++;else j++;
 }
 const long=new Set(matches.filter(x=>E.role(x.id)==='assistant'&&E.txt(x.id).length>=300).map(x=>E.txt(x.id)));
 const userLong=matches.filter(x=>E.role(x.id)==='user'&&E.txt(x.id).length>=24).length;
 const last=matches.at(-1);
 const stable=!!last&&matches.length>=3&&(long.size>=2||long.size>=1&&userLong>=2);
 return {matches,last,strong:stable,long:long.size};
}
function isGrowth(oldId,newId,E){
 if(E.role(oldId)!=='assistant'||E.role(newId)!=='assistant')return false;
 const old=E.txt(oldId),next=E.txt(newId);
 return old.length>=40&&next.length>old.length+20&&next.startsWith(old);
}
function replaceable(oldId,newId,E){
 if(!oldId||!newId||E.role(oldId)!=='assistant'||E.role(newId)!=='assistant')return false;
 if(isGrowth(oldId,newId,E))return true;
 const old=E.txt(oldId),next=E.txt(newId);
 // Never replace two unrelated complete GM answers; they are possible Retry.
 return isProgress(old)&&isNarrative(next);
}
function rebuild(chat,legacy,options){
 const E=evidence(chat);
 const selected=!!(options?.selectedPathId&&legacy.branchChoice===options.selectedPathId);
 const safePrefix=!!legacy.retroFork?.requiresChoice;
 const rawIds=(legacy.turns||[]).map(o=>o.observationId).filter(id=>E.byId.has(id));
 const firstDraft=rawIds.findIndex(id=>isDraft(E.byId.get(id)));
 const ids=firstDraft<0?rawIds.slice():rawIds.slice(0,firstDraft),integrity={
  engine:'1.0.0',verified:false,selected,branchUnresolved:safePrefix,
  rawObservations:E.occurrences.length,usableFrames:E.frames.length,
  stagedStatus:0,prefixPromotions:0,replacedProgress:0,
  appended:0,duplicatesIgnored:0,retryConflicts:0,
  ambiguousFrames:0,unlinkedRecentFrames:0,draftExcluded:0,partialTail:false,
  lastEvidencePreview:'',unlinkedPreview:'',warnings:[]
 };
 integrity.draftExcluded=E.occurrences.filter(isDraft).length;
 if(firstDraft>=0)integrity.warnings.push('SELECTED_PATH_TRUNCATED_AT_EDITOR_DRAFT');
 // Don't extrapolate past the shared prefix before the user chooses a branch.
 if(!safePrefix && (!legacy.retroFork || selected || legacy.branchChoice==='auto')){
  // We do not alter any previous turn of the chosen branch except its actual
  // GM renderer at the tail, which can be promoted using context evidence.
  // Frames may arrive out of scroll order, so repeatedly match until stable.
  const touched=new Set();
  for(let pass=0;pass<4;pass++){
   let changed=false;
   for(const {ids:frame,skipped,fi} of E.frames){
    if(frame.length<2||ids.length<6)continue;
    const m=selectMatches(frame,ids,E);
    if(!m.strong)continue;
    const {last}=m;
    const nearTail=last.j>=ids.length-2;
    if(!nearTail||last.i>=frame.length-1)continue;
    let offset=last.i+1;
    if(last.j===ids.length-2 && E.role(ids.at(-1))==='assistant' && E.role(last.id)==='user'){
     // Position-specific renderer promotion requires a matched PLAYER and a
     // match spanning at least one earlier substantial GM anchor.
     const option=frame[offset],old=ids.at(-1);
     if(E.role(option)==='assistant'&&replaceable(old,option,E)){
       ids[ids.length-1]=option;changed=true;offset++;
       if(isGrowth(old,option,E))integrity.prefixPromotions++;
       else integrity.replacedProgress++;
     }else{
       if(E.role(option)==='assistant'&&!E.equal(old,option))integrity.retryConflicts++;
       continue;
     }
    }else if(last.j!==ids.length-1)continue;
    for(let k=offset;k<frame.length;k++){
      const id=frame[k],before=ids.at(-1);
      if(touched.has(id)||ids.includes(id)){integrity.duplicatesIgnored++;continue;}
      if(E.equal(before,id)){integrity.duplicatesIgnored++;continue;}
      if(E.role(before)==='assistant'&&E.role(id)==='assistant'){
        if(replaceable(before,id,E)){
         ids[ids.length-1]=id;changed=true;
         if(isGrowth(before,id,E))integrity.prefixPromotions++;
         else integrity.replacedProgress++;
        }else integrity.retryConflicts++;
        continue;
      }
      // A fresh USER without a preceding chosen GM cannot be attached using
      // only a number or timestamp. Demand the whole contextual frame match.
      if(E.role(id)==='user'&&E.txt(id).length<=3&&m.long<2){integrity.ambiguousFrames++;break;}
      if(E.role(id)===E.role(before)){integrity.ambiguousFrames++;break;}
      ids.push(id);touched.add(id);changed=true;integrity.appended++;
     }
     integrity.stagedStatus+=skipped.filter(x=>x.why==='progress-auxiliary').length;
    }
    if(!changed)break;
   }
 }
 // Integrity detection is read-only, based on the latest observed viewports.
 // More recent DOM capture is not proof of the active ChatGPT branch, so a
 // warning means 'needs comparison' rather than an automatic branch switch.
 const tail=ids.at(-1),tailText=E.txt(tail),last=ids.map(id=>E.byId.get(id)).at(-1);
 if(E.role(tail)==='assistant'&&
   (isProgress(tailText)||E.byId.get(tail)?.supersededBy))integrity.partialTail=true;
 // Length cannot prove completion. Record a cautious pending state only.
 integrity.tailCompletion=E.role(tail)==='assistant'?(
   integrity.partialTail?'plausibly-streaming':
   E.txt(tail).length<1300?'not-confirmed':'observed-text-not-native-confirmed'):'awaiting-GM';
 const projectedSet=new Set(ids);
 // A rescan of old history must NOT be called a missing fresh turn. Flag only
 // a connected viewport which anchors to the last 4 chosen positions AND
 // contains a genuinely new contextual USER after that anchor.
 const recent=E.frames.slice(-Math.min(E.frames.length,18));
 for(const f of recent){
  const match=selectMatches(f.ids,ids,E);
  if(!match.strong||!match.last||match.last.j<ids.length-5)continue;
  const remainder=f.ids.slice(match.last.i+1);
  const nextNew=remainder.find(id=>E.role(id)==='user'&&E.txt(id).length>=12&&
     !projectedSet.has(id)&&!ids.some(x=>E.equal(x,id)));
  if(nextNew){integrity.unlinkedRecentFrames++;
   integrity.unlinkedPreview=E.txt(nextNew).slice(0,120);
  }
 }
 const lastEvidence=E.frames.at(-1)?.ids.at(-1);
 integrity.lastEvidencePreview=E.txt(lastEvidence).slice(0,120);
 if(safePrefix)integrity.warnings.push('BRANCH_UNSELECTED');
 if(integrity.partialTail)integrity.warnings.push('GM_COMPLETION_UNCONFIRMED');
 if(integrity.unlinkedRecentFrames)integrity.warnings.push('RECENT_RAW_NOT_ON_SELECTED_PATH');
 if(integrity.retryConflicts)integrity.warnings.push('POSSIBLE_GM_RETRY_DIFFERENCE');
 if(integrity.draftExcluded)integrity.warnings.push('EDITOR_DRAFT_QUARANTINED');
 // A final line can't be declared complete solely from its length. The
 // isPartial field means 'plausibly interim', NOT an assertion of missing text.
 const turns=ids.map(id=>E.byId.get(id)).filter(Boolean);
 const chosen=new Set(ids);
 const unused=E.occurrences.filter(o=>!chosen.has(o.observationId));
 const branchOptions=(legacy.branchOptions||[]).map(option=>option.id===legacy.branchChoice?
   {...option,count:turns.length,lastText:turns.at(-1)?.text?.slice(0,180)||''}:option);
 return {...legacy,turns,unused,branchOptions,coreIntegrity:integrity,
  issues:[...(legacy.issues||[]),...(integrity.unlinkedRecentFrames?
   [{reason:'core-v1-recent-raw-not-in-selected-txt',frames:integrity.unlinkedRecentFrames}]:[])],
  disclaimer:'DOM candidate with a locally chosen branch; not native ChatGPT verified.'};
}
API.project=function(chat,options={}){
 const prior=legacyProject(chat,options);
 try{return rebuild(chat,prior,options);}catch(e){
  return {...prior,coreIntegrity:{engine:'1.0.0',verified:false,
   warnings:['CORE_RECOVERY_FALLBACK'],detail:String(e?.message||e)},
   issues:[...(prior.issues||[]),{reason:'core-v1-fallback',detail:String(e?.message||e)}]};
 }
};
API.coreVersion='1.0.0';
API.coreDiagnostics=function(chat,options={}){return API.project(chat,options).coreIntegrity;};
})(typeof globalThis!=='undefined'?globalThis:this);
