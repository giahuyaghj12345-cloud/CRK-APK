// v1.0.1. NON-AUTHORITATIVE recovery of disjoint recent viewport islands.
// Never append recovered observations to TXT or the selected branch automatically.
(function(root){
'use strict';
const API=root.RPGMBTimeline;if(!API)return;
const base=API.project;
const norm=s=>String(s||'').replace(/\r\n?/g,'\n').replace(/\u00a0/g,' ').replace(/\s+/g,' ').trim();
const draft=o=>o?.role==='user'&&/(?:^|\n)\s*(?:Hủy|Huỷ)\s*\n\s*Gửi\s*$/i.test(String(o.text||'').slice(-180));
const status=o=>o?.role==='assistant'&&/^(?:Tôi sẽ|Mình sẽ|Đang|Đã xử lý|Đã xác định)/i.test(norm(o.text).slice(0,80))&&norm(o.text).length<1800;
function detect(chat,p){
 const occ=(chat?.provisionalOccurrences||[]).filter(o=>o?.observationId&&o.sourceChatId===chat.chatId&&o.sourceUrl===chat.sourceUrl&&o.captureOrigin==='live-conversation-dom-v090');
 const byId=new Map(occ.map(o=>[o.observationId,o]));
 const frames=(chat?.viewportEvidence||[]).filter(f=>f.chatId===chat.chatId&&f.sourceUrl===chat.sourceUrl&&Array.isArray(f.turns));
 const path=p.turns||[],tail=path.at(-1);if(!tail||path.length<6||p.retroFork?.requiresChoice)return null;
 // The tail may have been re-observed with a distinct DOM ID: require matching
 // substantial text and role, not observation ID alone.
 const matchesTail=id=>{const o=byId.get(id);return o&&o.role===tail.role&&norm(o.text)===norm(tail.text)};
 let lastConnected=-1;
 for(let i=0;i<frames.length;i++)if(frames[i].turns.some(t=>matchesTail(t.observationId)))lastConnected=i;
 if(lastConnected<0||lastConnected>=frames.length-1)return null;
 // A detached island cannot establish what occurred in the invisible gap.
 const eligible=frames.slice(lastConnected+1).map((f,j)=>({index:lastConnected+1+j,at:f.at,
  ids:f.turns.map(t=>t.observationId).filter(id=>byId.has(id)&&!draft(byId.get(id)))}));
 const isQuality=f=>f.ids.length>=6&&f.ids.filter(id=>byId.get(id).role==='assistant'&&norm(byId.get(id).text).length>=900).length>=2&&
  f.ids.filter(id=>byId.get(id).role==='user').length>=2;
 const first=eligible.findIndex(isQuality);if(first<0)return null;
 let ids=[...eligible[first].ids],joined=1,pendingEdit=false,switchedStatus=0,conflicts=0;
 const equal=(x,y)=>byId.get(x)?.role===byId.get(y)?.role&&norm(byId.get(x)?.text)===norm(byId.get(y)?.text);
 for(const f of eligible.slice(first+1)){
  const a=ids,b=f.ids;let best=null;
  for(let i=0;i<a.length;i++)for(let j=0;j<b.length;j++){
   let len=0;while(i+len<a.length&&j+len<b.length&&equal(a[i+len],b[j+len]))len++;
   const longAnchors=a.slice(i,i+len).filter(id=>byId.get(id).role==='assistant'&&norm(byId.get(id).text).length>=900).length;
   if(len>=3&&longAnchors>=1&&(!best||len>best.len||len===best.len&&i+len>best.i+best.len))best={i,j,len};
  }
  if(!best)continue;
  const endA=best.i+best.len,endB=best.j+best.len;
  if(endB>=b.length)continue; // viewport may simply show an earlier slice
  if(endA===a.length){ids.push(...b.slice(endB));joined++;continue;}
  const old=byId.get(a[endA]),fresh=byId.get(b[endB]);
  if(old?.role==='assistant'&&fresh?.role==='assistant'&&
    (status(old)||norm(fresh.text).length>norm(old.text).length+20&&norm(fresh.text).startsWith(norm(old.text)))){
   ids.splice(endA,ids.length-endA,...b.slice(endB));joined++;switchedStatus++;continue;
  }
  // User-edited earlier turn: the latest viewport removes the GM from that
  // branch. Do not treat an editor draft as a sent PLAYER. The new PLAYER-only
  // viewport may represent a submitted edit, but it remains unverified.
  if(old?.role==='user'&&fresh?.role==='user'&&endB===b.length-1&&endA<=a.length-2&&
    byId.get(a[endA+1])?.role==='assistant'){
   ids.splice(endA,ids.length-endA,b[endB]);joined++;pendingEdit=true;continue;
  }
  // Two complete GM or unrelated USER variants are possible Edit/Retry.
  conflicts++;
 }
 const result=ids.map(id=>byId.get(id)).filter(Boolean);
 const longGM=result.filter(o=>o.role==='assistant'&&norm(o.text).length>=900).length;
 const user=result.filter(o=>o.role==='user').length;
 // An unlinked rescan is only a candidate, never proof of being the latest
 // active path. Demand strong internal continuity and a substantial amount.
 if(joined<2||result.length<6||longGM<2||user<2)return null;
 const selectedText=new Set(path.map(o=>o.role+'\x1f'+norm(o.text)));
 const novel=result.filter(o=>!selectedText.has(o.role+'\x1f'+norm(o.text)));
 if(novel.length<4)return null;
 return {kind:'UNVERIFIED_DISCONNECTED_VIEWPORT_ISLAND',turns:result,count:result.length,
  userCount:result.filter(o=>o.role==='user').length,gmCount:result.filter(o=>o.role==='assistant').length,
  firstFrameIndex:eligible[first].index,lastFrameIndex:eligible.at(-1).index,
  sourceFrames:joined,pendingEdit,conflicts,switchedStatus,missingBridge:true,
  firstPreview:norm(result[0]?.text).slice(0,150),lastPreview:norm(result.at(-1)?.text).slice(0,150),
  important:'Không thể xác minh đoạn từ lượt cuối TXT đến khung đầu của cụm này. Không tự ghép vào canon.'};
}
API.project=function(chat,options={}){
 const p=base(chat,options);try{
  const recovered=detect(chat,p);
  if(!recovered)return p;
  const coreIntegrity={...(p.coreIntegrity||{}),detachedCandidateCount:recovered.count,
   unlinkedRecentFrames:Math.max(p.coreIntegrity?.unlinkedRecentFrames||0,recovered.sourceFrames),
   warnings:[...new Set([...(p.coreIntegrity?.warnings||[]),'DISCONNECTED_RECENT_CLUSTER_REQUIRES_REVIEW'])]};
  return {...p,detachedTail:recovered,coreIntegrity};
 }catch(err){return {...p,detachedTailError:String(err?.message||err)};}
};
API.detachedTailVersion='1.0.1';
})(typeof globalThis!=='undefined'?globalThis:this);
