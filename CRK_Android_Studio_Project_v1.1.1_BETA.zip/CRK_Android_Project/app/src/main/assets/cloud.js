importScripts('active-timeline.js','safe.js','ledger.js','meta.js','day.js','auto-day.js','branch.js','source-events.js','evidence-audit.js');
// Optional cloud bridge. Never send data to anything but the user-configured Supabase host.
const CFG='rpgmb-cloud-v06', S='rpgmb-cloud-state-v06', PREFIX='rpgmb:';
const PAUSED='rpgmb-capture-paused-v091',TEST='rpgmb-fresh-test-v091',CLOUD_ARMED='rpgmb-cloud-armed-v0916';
let resetRequested=false;
const isPaused=async()=>resetRequested || (await get(PAUSED))===true;
const META=['rpgmb-campaigns-v04','rpgmb-assign-v04','rpgmb-proposals-v05']; // legacy LOCAL views, not cloud records
const SENT='rpgmb-cloud-sent-hashes-v06';
const RESOLVED='rpgmb-cloud-resolved-v061';
const VERIFIED='rpgmb-cloud-verified-hashes-v073';
const CONFIRM='rpgmb-cloud-confirmed-v080', UPLOAD_REPORT='rpgmb-cloud-upload-report-v080';
const RECHECK_MS=10*60*1000;
const LEDGER_PREFIX='rpgmb-ledger-v075:';
const DELETE_PREFIX='rpgmb-deleted-campaign-v095:',DELETED='rpgmb-deleted-campaigns-v095';
const deletionRecord=(k,p)=>k.startsWith(DELETE_PREFIX)&&RPGMBMeta.safeId(k.slice(DELETE_PREFIX.length))&&p?.format==='rpgmb-campaign-tombstone-v095'&&p.campaignId===k.slice(DELETE_PREFIX.length)&&typeof p.deletedAt==='string'&&Number.isFinite(Date.parse(p.deletedAt));
const enc = new TextEncoder();
const hex = a => [...new Uint8Array(a)].map(x=>x.toString(16).padStart(2,'0')).join('');
const digest = async x => hex(await crypto.subtle.digest('SHA-256',enc.encode(JSON.stringify(x))));
const stable=x=>Array.isArray(x)?x.map(stable):x&&typeof x==='object'?Object.fromEntries(Object.keys(x).sort().map(k=>[k,stable(x[k])])):x;
const equalJSON=(a,b)=>JSON.stringify(stable(a))===JSON.stringify(stable(b));
function acceptClientKey(key){
 if(!key||/^sb_secret_/i.test(key))throw Error('Không sử dụng secret/service_role key trong tiện ích. Chỉ dùng publishable hoặc anon.');
 const parts=String(key).split('.');
 if(parts.length===3){try{const json=JSON.parse(atob(parts[1].replace(/-/g,'+').replace(/_/g,'/')));
  if(json?.role==='service_role'||json?.role==='supabase_admin')throw Error('Cấm service_role/admin key trong trình duyệt.');
 }catch(e){if(/service_role|admin key/i.test(String(e?.message)))throw e;}}
 return key;
}
function endpoint(url){try{const u=new URL(url);if(u.protocol!=='https:'||!/^[a-z0-9-]+\.supabase\.co$/i.test(u.hostname)||u.username||u.password||u.search||u.hash)throw Error();return u.origin;}catch{throw Error('URL phải là https://<project>.supabase.co');}}
const get = async k => (await chrome.storage.local.get(k))[k];
async function putState(change){await chrome.storage.local.set({[S]:{...(await get(S)||{}),...change,lastAttempt:new Date().toISOString()}})}
async function request(url,opts,auth,body){
 const controller=new AbortController();
 const timeout=setTimeout(()=>controller.abort(),15000);
 try{
   const res=await fetch(url,{...opts,signal:controller.signal,
     headers:{'apikey':auth.key,'Content-Type':'application/json',
       ...(auth.token?{'Authorization':'Bearer '+auth.token}:{}),...(opts?.headers||{})},
     ...(body===undefined?{}:{body:JSON.stringify(body)})});
   const txt=await res.text();let data;
   try{data=txt?JSON.parse(txt):null;}catch{data=txt;}
   if(!res.ok){
     const e=Error(`HTTP ${res.status}: ${String(data?.message||data?.msg||data?.error_description||data?.error||txt).slice(0,250)}`);
     e.httpStatus=res.status;throw e;
   }
   return data;
 }finally{clearTimeout(timeout);}
}
async function authFetch(){let cfg=await get(CFG);if(!cfg?.url||!cfg?.key||!cfg?.refresh_token)throw Error('Chưa đăng nhập cloud');cfg={...cfg,url:endpoint(cfg.url)};acceptClientKey(cfg.key);
  if(!cfg.access_token||Date.now()>(cfg.expires_at||0)-60000){const t=await request(cfg.url+'/auth/v1/token?grant_type=refresh_token',{method:'POST'},{key:cfg.key}, {refresh_token:cfg.refresh_token});cfg={...cfg,access_token:t.access_token,refresh_token:t.refresh_token,expires_at:Date.now()+t.expires_in*1000,user_id:t.user?.id||cfg.user_id};await chrome.storage.local.set({[CFG]:cfg});}return {cfg,auth:{key:cfg.key,token:cfg.access_token}};}
const TRACKED=k=>k.startsWith(PREFIX)||k.startsWith(LEDGER_PREFIX)||Boolean(RPGMBMeta.classify(k))||k.startsWith(DELETE_PREFIX);
// One-way, non-destructive migration of v0.9.2 local Save maps.
// Never materialize the unscoped legacy global maps as cloud rows.
async function ensureScopedMeta(){
 if(await isPaused())return;
 const stored=await chrome.storage.local.get(null),updates={};
 const deleted=stored[DELETED]||{};
 for(const [id,value] of Object.entries(stored['rpgmb-campaigns-v04']||{})){
  if(deleted[id])continue;
  const k=RPGMBMeta.campaignKey(id);
  if(stored[k]===undefined&&RPGMBMeta.validValue('campaign',id,value))updates[k]=await RPGMBMeta.prepare('campaign',id,value,null);
 }
 for(const [id,value] of Object.entries(stored['rpgmb-assign-v04']||{})){
  if(deleted[value])continue;
  const k=RPGMBMeta.assignKey(id);
  if(stored[k]===undefined&&RPGMBMeta.validValue('assign',id,value))updates[k]=await RPGMBMeta.prepare('assign',id,value,null);
 }
 const groups={};for(const proposal of stored['rpgmb-proposals-v05']||[]){
  if(typeof proposal?.campaignId==='string')(groups[proposal.campaignId]??=[]).push(proposal);
 }
 for(const [id,value] of Object.entries(groups)){
  if(deleted[id])continue;
  const k=RPGMBMeta.proposalKey(id);
  if(stored[k]===undefined&&RPGMBMeta.validValue('proposals',id,value))updates[k]=await RPGMBMeta.prepare('proposals',id,value,null);
 }
 if(Object.keys(updates).length)await chrome.storage.local.set(updates);
}
// Factory-test mode is a strict cloud boundary too. Never restore unrelated
// historical conversations when someone logs in to an uncleared Supabase.
async function freshScope(){
 const test=await get(TEST);
 if(!test?.active)return null;
 const id=String(test.allowedChatId||'');
 if(!RPGMBSafe.recordKey(id))return new Set();
 const keys=new Set([PREFIX+id, LEDGER_PREFIX+id,RPGMBMeta.assignKey(id)]);
 const a=await get('rpgmb-assign-v04')||{};
 const assignment=await get(RPGMBMeta.assignKey(id));
 const campaignId=a[id]||assignment?.value;
 if(campaignId&&RPGMBMeta.safeId(campaignId)){
   keys.add(RPGMBMeta.campaignKey(campaignId));
   keys.add(RPGMBMeta.proposalKey(campaignId));
 }
 return keys;
}
// Production scope: unlike the old Bridge, a chat is never transmitted just
// because a local legacy snapshot exists. Only explicit Campaign assignments
// grant sync authority. Metadata is restored in a separate pass first so a
// second device can recover the list of assigned chats without prior RAW.
async function assignedScope(){
 const test=await get(TEST);
 if(test?.active)return freshScope();
 const stored=await chrome.storage.local.get(['rpgmb-campaigns-v04','rpgmb-assign-v04',DELETED]);
 const campaigns=stored['rpgmb-campaigns-v04']||{},assignments=stored['rpgmb-assign-v04']||{},deleted=stored[DELETED]||{};
 const allowed=new Set(Object.keys(deleted).filter(id=>RPGMBMeta.safeId(id)).map(id=>DELETE_PREFIX+id));
 for(const id of Object.keys(campaigns))if(RPGMBMeta.safeId(id)&&!deleted[id]){
  allowed.add(RPGMBMeta.campaignKey(id));
  allowed.add(RPGMBMeta.proposalKey(id));
 }
 for(const [chatId,cid] of Object.entries(assignments)){
  if(!RPGMBSafe.recordKey(chatId)||!Object.hasOwn(campaigns,cid)||!RPGMBMeta.safeId(cid)||deleted[cid])continue;
  allowed.add(PREFIX+chatId);allowed.add(LEDGER_PREFIX+chatId);
  allowed.add(RPGMBMeta.assignKey(chatId));
 }
 return allowed;
}
const normalized=RPGMBSafe.norm;
const isPrefix=(a,b)=>normalized(b).startsWith(normalized(a)) && normalized(a).length>0;
function preserveRevision(winner,loser,reason){
 const revisions=[...(winner.revisions||[])];
 if(normalized(winner.text)!==normalized(loser.text) && !revisions.some(r=>normalized(r.text)===normalized(loser.text)))
   revisions.push({at:new Date().toISOString(),text:loser.text,reason});
 return {...winner,revisions};
}
function mergeMessage(old, incoming){
 // Same native UUID with divergent Campaign provenance must NOT be relabeled by another device.
 if((old.campaignId??null)!==(incoming.campaignId??null))return {message:old,changed:false,conflict:true};
 if(old.role!==incoming.role)return {message:old,changed:false,conflict:true};
 if(normalized(old.text)===normalized(incoming.text)){
   const merged=[...(old.revisions||[])];
   for(const rev of incoming.revisions||[])if(!merged.some(r=>normalized(r.text)===normalized(rev.text)))merged.push(rev);
   return {message:{...old,revisions:merged},changed:merged.length!==(old.revisions||[]).length,conflict:false};
 }
 const references=(x,other)=>(x.revisions||[]).some(r=>normalized(r.text)===normalized(other.text));
 // A proven same-UUID revision chain is stronger than textual prefix heuristics:
 // edits may replace the ENTIRE message. Unlinked divergent text stays a conflict.
 if(references(incoming,old))return {message:preserveRevision(incoming,old,'Older observed UUID version'),changed:true,conflict:false};
 if(references(old,incoming))return {message:preserveRevision(old,incoming,'Older observed UUID version'),changed:false,conflict:false};
 if(isPrefix(old.text,incoming.text))return {message:preserveRevision(incoming,old,'Earlier partial content'),changed:true,conflict:false};
 if(isPrefix(incoming.text,old.text))return {message:preserveRevision(old,incoming,'Earlier partial content'),changed:false,conflict:false};
 return {message:old,changed:false,conflict:true};
}

async function mergeRemote(remote){if(await isPaused())throw Error('Đang tạm dừng sau factory reset');const local=await chrome.storage.local.get(null);let conflicts=local['rpgmb-cloud-conflicts-v06']||[];const resolved=local[RESOLVED]||{};let modifications={};let received=0;
 for(const record of remote){const key=record.record_key,p=record.payload;if(!TRACKED(key)||!p||typeof p!=='object'||key.startsWith(LEDGER_PREFIX))continue;const old=modifications[key]??local[key];
  if(key.startsWith(DELETE_PREFIX)){
    if(!deletionRecord(key,p))continue;
    const id=p.campaignId;
    const deleted={...(modifications[DELETED]||local[DELETED]||{})};
    if(!deleted[id]){
      deleted[id]={deletedAt:p.deletedAt,reason:'explicit-user-cleanup'};
      modifications[DELETED]=deleted;
      const camps={...(modifications['rpgmb-campaigns-v04']||local['rpgmb-campaigns-v04']||{})};
      delete camps[id];modifications['rpgmb-campaigns-v04']=camps;
      const assigned={...(modifications['rpgmb-assign-v04']||local['rpgmb-assign-v04']||{})};
      for(const [chat,cid] of Object.entries(assigned))if(cid===id)delete assigned[chat];
      modifications['rpgmb-assign-v04']=assigned;
      const proposals=[...(modifications['rpgmb-proposals-v05']||local['rpgmb-proposals-v05']||[])];
      modifications['rpgmb-proposals-v05']=proposals.filter(x=>x?.campaignId!==id);
      received++;
    }
    modifications[key]=p;continue;
  }
  if(key.startsWith(PREFIX)){
    // A record key and its internal source identity MUST agree. A title or
    // quoted text from a different chat is not a legitimate source identity.
    if(!RPGMBSafe.matchesChat(p,key) || (old && !RPGMBSafe.matchesChat(old,key))){
      const alerts=[...(modifications['rpgmb-cloud-provenance-alerts-v090']||local['rpgmb-cloud-provenance-alerts-v090']||[])];
      const signature=key+'|'+String(p.chatId||'')+'|'+String(p.sourceUrl||'');
      if(!alerts.some(x=>x.signature===signature))alerts.push({signature,key,reason:'source chat ID/URL mismatch, remote left unchanged',seenAt:new Date().toISOString()});
      modifications['rpgmb-cloud-provenance-alerts-v090']=alerts;continue;
    }
    if(typeof p.chatId!=='string'||!Array.isArray(p.messages))continue;
    if(!old){
      // Preserve historical evidence in local archive, but only live-origin
      // scoped occurrences become the synchronized provisional view.
      const id=key.slice(PREFIX.length);
      const good=(p.provisionalOccurrences||[]).filter(o=>RPGMBSafe.trustedOccurrence(o,id));
      modifications[key]={...p,provisionalOccurrences:good,viewportEvidence:(p.viewportEvidence||[]).filter(f=>f.chatId===id&&RPGMBSafe.chatIdFromUrl(f.sourceUrl)===id),
        remoteEvidenceArchive:[...(p.remoteEvidenceArchive||[]),...((p.provisionalOccurrences||[]).filter(o=>!RPGMBSafe.trustedOccurrence(o,id)).map(o=>({archiveId:o?.observationId||crypto.randomUUID(),kind:'unscoped-legacy-remote-occurrence',evidence:o})))],updatedAt:new Date().toISOString()};
      received++;continue;
    }
    const m=new Map((old.messages||[]).filter(x=>typeof x.id==='string').map(x=>[x.id,x]));let changed=false;
    const norm=t=>String(t||'').replace(/\r\n?/g,'\n').replace(/\u00a0/g,' ').trim();
    for(const x of p.messages){if(typeof x?.id!=='string'||typeof x.text!=='string')continue;
      // Equal text is NOT identity. Two turns may intentionally repeat the same
      // sentence. Import only proven native IDs; archive older claims separately.
      if(!RPGLedger.nativeId(x.id))continue;
      if(x.identityVerified!==true||x.identityProof!=='same-turn-native-id-role-v081'){
        const audit=[...(modifications[key]?.remoteLegacyClaims||old.remoteLegacyClaims||[])];
        const fp=x.id+'|'+x.role+'|'+x.text;
        if(!audit.some(y=>y.fingerprint===fp)){
          audit.push({fingerprint:fp,id:x.id,role:x.role,text:x.text,source:'unverified-cloud-legacy'});
          modifications[key]={...(modifications[key]||old),remoteLegacyClaims:audit};received++;
        }
        continue;
      }
      const o=m.get(x.id);
      if(!o){if(!RPGLedger.nativeId(x.id))continue;m.set(x.id,x);changed=true;}
      else {const result=mergeMessage(o,x);
        if(result.changed){m.set(x.id,result.message);changed=true;}
        if(result.conflict){const id=key+'#'+x.id;
          if(!conflicts.some(c=>c.id===id&&c.remoteText===x.text&&c.remoteRole===x.role))conflicts.push({id,kind:'RAW',remoteText:x.text,localText:o.text,remoteRole:x.role,localRole:o.role,seenAt:new Date().toISOString()});
        }
      }}
    // Cross-device provisional synchronization requires explicit URL/chat
    // provenance. Never import old context-only fragments as RAW.
    // Merge cross-device DOM snapshots using corroborated SAME FULL viewport
    // only, not global text equality or capture timestamps. Preserve forks.
    const cid=key.slice(PREFIX.length);
    const trusted=(p.provisionalOccurrences||[]).filter(o=>RPGMBSafe.trustedOccurrence(o,cid));
    const incomingArchived=(p.provisionalOccurrences||[]).filter(o=>!RPGMBSafe.trustedOccurrence(o,cid));
    const combined=RPGMBEvidenceAudit.merge(modifications[key]||old,
      {...p,provisionalOccurrences:trusted},cid,(modifications[key]||old).sourceUrl||p.sourceUrl);
    const evidence=combined.occurrences,frames=combined.frames;
    if(combined.addedOccurrences||combined.addedFrames)changed=true;
    for(const item of combined.conflicts){
      const id=key+'#occ:'+item.id;
      if(!conflicts.some(x=>x.id===id))conflicts.push({id,kind:'EVIDENCE',...item,seenAt:new Date().toISOString()});
    }
    const timelineMerge=CRKActiveTimeline.merge((modifications[key]||old).activeTimeline,p.activeTimeline);
    if(timelineMerge.changed)changed=true;
    if(timelineMerge.conflict){
      const id=key+'#active-generation-'+String(p.activeTimeline?.generation??'?');
      if(!conflicts.some(c=>c.id===id))
        conflicts.push({id,kind:'ACTIVE_TIMELINE',reason:timelineMerge.reason||'divergent-active-lines',
          localGeneration:(modifications[key]||old).activeTimeline?.generation??null,
          remoteGeneration:p.activeTimeline?.generation??null,seenAt:new Date().toISOString()});
    }
    const archived=[...((modifications[key]||old).remoteEvidenceArchive||[])];
    const oldArchive=new Set(archived.map(x=>x.archiveId));
    // Archival evidence already quarantined by another device must survive a
    // later restore. A live-origin RAW copy is never synthesized from it.
    for(const item of p.remoteEvidenceArchive||[]){
      if(!item||typeof item.archiveId!=='string'||!item.archiveId||oldArchive.has(item.archiveId))continue;
      archived.push(item);oldArchive.add(item.archiveId);changed=true;
    }
    for(const o of incomingArchived){
      const archiveId=o?.observationId||null;
      if(archiveId&&!oldArchive.has(archiveId)){
        archived.push({archiveId,kind:'unscoped-legacy-remote-occurrence',evidence:o});oldArchive.add(archiveId);changed=true;
      }
    }
    // Cross-device reviews are still DOM-only, never source-native proof. On
    // disagreement keep this device's choice, archive the other choice without
    // flattening branches. Review IDs are stable across repeated syncs.
    const validReview=r=>r?.schema===1&&r.chatId===cid&&r.sourceUrl===old.sourceUrl&&
      Array.isArray(r.ids)&&r.ids.length>0&&r.ids.every(id=>typeof id==='string'&&id.length===36)&&
      typeof r.digest==='string';
    let chosenReview=validReview(old.reviewedPath)?old.reviewedPath:null;
    const remoteReview=validReview(p.reviewedPath)?p.reviewedPath:null;
    const history=[...(old.reviewedPathHistory||[])],historyIds=new Set(history.map(r=>r.reviewId));
    for(const entry of [...(p.reviewedPathHistory||[]),...(chosenReview&&remoteReview&&chosenReview.reviewId!==remoteReview.reviewId?[remoteReview]:[])]){
      if(!validReview(entry)||historyIds.has(entry.reviewId)||entry.reviewId===chosenReview?.reviewId)continue;
      history.push(entry);historyIds.add(entry.reviewId);changed=true;
    }
    if(!chosenReview&&remoteReview){chosenReview=remoteReview;changed=true;}
    if(changed){modifications[key]={...(modifications[key]||old),
      ...(timelineMerge.state?.schema===1?{activeTimeline:timelineMerge.state}:{}),
      messages:[...m.values()].sort((a,b)=>(a.position??0)-(b.position??0)),provisionalOccurrences:evidence,viewportEvidence:frames,remoteEvidenceArchive:archived,
      ...(chosenReview?{reviewedPath:chosenReview}:{}),...(history.length?{reviewedPathHistory:history}:{})};received++;}
  }else if(RPGMBMeta.classify(key)){
    const parsedEarly=RPGMBMeta.classify(key);
    const deleted=modifications[DELETED]||local[DELETED]||{};
    if(parsedEarly.kind==='campaign'&&deleted[parsedEarly.id])continue;
    if(parsedEarly.kind==='proposals'&&deleted[parsedEarly.id])continue;
    if(parsedEarly.kind==='assign'&&deleted[p.value])continue;
    // Exact key/type/source correspondence, including a valid payload digest.
    if(!RPGMBMeta.validRecord(key,p)||await RPGMBMeta.hash(p.value)!==p.head){
      const alerts=[...(modifications['rpgmb-cloud-provenance-alerts-v090']||local['rpgmb-cloud-provenance-alerts-v090']||[])];
      if(!alerts.some(a=>a.signature===key+'|invalid-meta'))alerts.push({signature:key+'|invalid-meta',key,reason:'Invalid scoped metadata identity/hash; rejected',seenAt:new Date().toISOString()});
      modifications['rpgmb-cloud-provenance-alerts-v090']=alerts;continue;
    }
    let chosen=p,action='take-remote';
    if(old){
      if(!RPGMBMeta.validRecord(key,old)||await RPGMBMeta.hash(old.value)!==old.head){
        const id='meta:'+key+':invalid-local';
        if(!conflicts.some(c=>c.id===id))conflicts.push({id,kind:'META',metaKey:key,reason:'Local meta invalid; remote retained for review',localValue:old,remoteValue:p.value,remoteRecord:p});
        continue;
      }
      action=RPGMBMeta.lineage(old,p);
      if(action==='equal'||action==='keep-local')continue;
      if(action==='conflict'){
        const id='meta:'+key+':'+p.head;
        if(!conflicts.some(c=>c.id===id))conflicts.push({id,kind:'META',metaKey:key,reason:'Concurrent Save metadata edits',localValue:old.value,remoteValue:p.value,remoteRecord:p,seenAt:new Date().toISOString()});
        continue;
      }
    }
    const parsed=RPGMBMeta.classify(key);
    // An existing local legacy view is never silently overwritten by a foreign
    // save or assignment. Migration should normally create matching scoped keys.
    const campView=modifications['rpgmb-campaigns-v04']||local['rpgmb-campaigns-v04']||{};
    const assignView=modifications['rpgmb-assign-v04']||local['rpgmb-assign-v04']||{};
    const propView=modifications['rpgmb-proposals-v05']||local['rpgmb-proposals-v05']||[];
    if(!old){
      const present=parsed.kind==='campaign'?campView[parsed.id]:parsed.kind==='assign'?assignView[parsed.id]:undefined;
      if(present!==undefined&&!equalJSON(present,p.value)){
        const id='meta:'+key+':local-view-diff';
        if(!conflicts.some(c=>c.id===id))conflicts.push({id,kind:'META',metaKey:key,reason:'Existing local Save disagrees with remote',localValue:present,remoteValue:p.value,remoteRecord:p,seenAt:new Date().toISOString()});
        continue;
      }
    }
    modifications[key]=chosen;
    if(parsed.kind==='campaign')modifications['rpgmb-campaigns-v04']={...campView,[parsed.id]:chosen.value};
    else if(parsed.kind==='assign')modifications['rpgmb-assign-v04']={...assignView,[parsed.id]:chosen.value};
    else{
      const rest=propView.filter(x=>x?.campaignId!==parsed.id);
      // Ensure each proposal ID only appears once after repeated Cloud merges.
      modifications['rpgmb-proposals-v05']=[...rest,...chosen.value];
    }
    received++;
  }else if(key==='rpgmb-assign-v04'){
    const next={...(old||{})};let changed=false;for(const [chat,camp] of Object.entries(p)){if(!next[chat]){next[chat]=camp;changed=true;}else if(next[chat]!==camp){const id='assign:'+chat;if(!conflicts.some(c=>c.id===id))conflicts.push({id,kind:'ASSIGN',localValue:next[chat],remoteValue:camp});}}
    if(changed){modifications[key]=next;received++;}
  }else if(key==='rpgmb-proposals-v05'){
    if(!Array.isArray(p))continue;const next=[...(old||[])],ids=new Set(next.map(x=>x.id));for(const item of p)if(item?.id&&!ids.has(item.id)){next.push(item);ids.add(item.id);}if(next.length!==(old||[]).length){modifications[key]=next;received++;}
  }else if(key==='rpgmb-campaigns-v04'){
    const next=structuredClone(old||{});let changed=false;
    for(const [id,c] of Object.entries(p)){if(!c||typeof c.name!=='string'||!c.sections)continue;if(!next[id]){next[id]=c;changed=true;continue;}
      for(const [sec,content] of Object.entries(c.sections||{})){if(typeof content!=='string'||!content)continue;const current=next[id].sections?.[sec]||'';if(!current){next[id].sections??={};next[id].sections[sec]=content;changed=true;}
      else if(current===content){}
      else if(content.startsWith(current)){next[id].sections[sec]=content;changed=true;}
      else if(current.startsWith(content)){}
      else {const conflictId=`canon:${id}:${sec}:${await digest(content)}`;if(!resolved[conflictId]&&!conflicts.some(x=>x.id===conflictId))conflicts.push({id:conflictId,kind:'CANON',campaign:id,section:sec,localText:current,remoteText:content,seenAt:new Date().toISOString()});}}
    }if(changed){modifications[key]=next;received++;}
  }
 }
 if(await isPaused())throw Error('Đang tạm dừng sau factory reset');
 if(Object.keys(modifications).length)await chrome.storage.local.set(modifications);
 // Remove old false positives after a straightforward append-only merge.
 const finalCampaigns=modifications['rpgmb-campaigns-v04']||local['rpgmb-campaigns-v04']||{};
 conflicts=conflicts.filter(c=>{
  if(c.kind==='RAW'){
    const split=c.id.lastIndexOf('#');const key=c.id.slice(0,split),id=c.id.slice(split+1);
    const record=(modifications[key]||local[key]);const current=record?.messages?.find(m=>m.id===id);
    // Do not discard a genuine concurrent conflict just because the local
    // message stayed unchanged. The prior `isPrefix(c.localText,current.text)`
    // was true even for an EXACT local match, silently erasing conflict evidence.
    // Clear only when the remote version is now the current text or is retained
    // in an explicit observed revision chain of this exact source UUID.
    const remoteInRevisions=(current?.revisions||[]).some(r=>normalized(r.text)===normalized(c.remoteText));
    if(current&&c.remoteRole&&c.localRole&&c.remoteRole===c.localRole&&current.role===c.remoteRole&&
       (normalized(current.text)===normalized(c.remoteText)||remoteInRevisions))return false;
    return true;
  }
  if(c.kind!=='CANON')return true;
  const current=finalCampaigns[c.campaign]?.sections?.[c.section];return typeof current!=='string'||(current!==c.remoteText&&!current.startsWith(c.remoteText)&&!c.remoteText.startsWith(current));
 });
 await chrome.storage.local.set({'rpgmb-cloud-conflicts-v06':conflicts.slice(-200)});
 return {received,conflicts:conflicts.length};
}
// Per-key delivery: a cached local hash is NOT proof that a row still exists in
// Supabase (e.g. after a user resets the cloud database). Manual sync always
// rechecks the remote row. Background sync periodically rechecks old proofs.
const pause=ms=>new Promise(resolve=>setTimeout(resolve,ms));
function retryable(e){return !Number.isInteger(e?.httpStatus)||[408,425,429,500,502,503,504].includes(e.httpStatus);}
async function retryIO(action,label){
 let last;
 for(let attempt=1;attempt<=3;attempt++){
   try{return await action();}catch(e){last=e;
     if(!retryable(e)||attempt===3)break;
     await pause(400*attempt);
   }
 }
 const out=Error(label+': '+String(last?.message||last).slice(0,240));
 out.httpStatus=last?.httpStatus;
 throw out;
}
async function readExact(base,auth,id){
 const url=base+'?select=id,record_key,content_hash,payload&id=eq.'+encodeURIComponent(id)+'&limit=1';
 const rows=await retryIO(()=>request(url,{method:'GET'},auth),'READBACK');
 if(!Array.isArray(rows))throw Error('READBACK: Supabase không trả về danh sách bản ghi');
 return rows[0]||null;
}
function checkExact(row,key,hash,payload){
 return !!row&&row.record_key===key&&row.content_hash===hash&&equalJSON(row.payload,payload);
}
async function deliverKeys({cfg,auth,onlyKeys=null,force=false,received=0,conflicts=0,mergeWarning=null}){
 const base=cfg.url+'/rest/v1/rpg_sync_records';
 const verified=await get(VERIFIED)||{},already=await get(SENT)||{};
 const confirmations=await get(CONFIRM)||{};
 const initial=await chrome.storage.local.get(null);
 const scope=await assignedScope();
 const relevant=Object.entries(initial).filter(([k,v])=>TRACKED(k)&&v!==undefined&&(!onlyKeys||onlyKeys.has(k))&&(!scope||scope.has(k)));
 const result={at:new Date().toISOString(),mode:onlyKeys?'missing-only':force?'manual-full':'background',total:relevant.length,
   uploaded:0,existing:0,cached:0,failed:0,changed:0,quarantined:0,entries:[],mergeWarning};
 // Bound diagnostics, never store complete RAW or credentials in upload report.
 for(const [key] of relevant){
   if(await isPaused())throw Error('Đã dừng sync để reset');
   const rowResult={key,status:'unknown'};
   try{
     const payload=await get(key);
     if(RPGMBMeta.classify(key)&&(!RPGMBMeta.validRecord(key,payload)||await RPGMBMeta.hash(payload.value)!==payload.head)){
       rowResult.status='quarantined-invalid-meta';rowResult.error='Save key/type/value/digest mismatch';result.quarantined++;continue;
     }
     if(key.startsWith(DELETE_PREFIX)&&!deletionRecord(key,payload)){rowResult.status='quarantined-invalid-tombstone';result.quarantined++;continue;}
     if(key.startsWith(PREFIX)&&!RPGMBSafe.matchesChat(payload,key)){
       rowResult.status='quarantined-source-identity';rowResult.error='Local record chatId/URL differs from record key; retained locally, NOT uploaded';
       result.quarantined++;continue;
     }
     if(payload===undefined){rowResult.status='removed';result.changed++;continue;}
     const hash=await digest(payload);
     const id=await digest({key,hash,user:cfg.user_id});
     const proof=confirmations[key];
     const fresh=proof?.hash===hash && proof.user===cfg.user_id && proof.url===cfg.url &&
       Number.isFinite(proof.at) && (Date.now()-proof.at)<RECHECK_MS;
     if(!force&&fresh){rowResult.status='cached';result.cached++;continue;}
     // READ BEFORE WRITE. This repairs missing rows even if older builds marked
     // them as successfully synced before the cloud was cleared.
     let existing=await readExact(base,auth,id);
     if(existing&&!checkExact(existing,key,hash,payload)){
       const error=Error('ID đã tồn tại nhưng nội dung không khớp; không ghi đè');
       error.httpStatus=409;throw error;
     }
     if(!existing){
       if(await isPaused())throw Error('Đã dừng sync để reset');
       const record={id,user_id:cfg.user_id,record_key:key,device_id:cfg.device_id,payload,content_hash:hash};
       await retryIO(()=>request(base+'?on_conflict=id',
         {method:'POST',headers:{Prefer:'resolution=ignore-duplicates,return=minimal'}},auth,record),'INSERT');
       existing=await readExact(base,auth,id);
       if(!checkExact(existing,key,hash,payload))throw Error('INSERT xong nhưng READBACK không khớp');
       rowResult.status='uploaded';result.uploaded++;
     }else{rowResult.status='already-on-cloud';result.existing++;}
     // Persist proof for the snapshot actually confirmed, not a new live edit.
     const current=await get(key);
     if(current===undefined||await digest(current)!==hash){
       rowResult.status='changed-during-sync';result.changed++;
     }else{
       confirmations[key]={hash,at:Date.now(),user:cfg.user_id,url:cfg.url};
       verified[key]=hash;already[key]=hash;
       await chrome.storage.local.set({[CONFIRM]:confirmations,[VERIFIED]:verified,[SENT]:already});
     }
   }catch(e){
     // Invalidate ONLY a stale verification cache, never the RAW itself.
     delete confirmations[key];delete verified[key];delete already[key];
     await chrome.storage.local.set({[CONFIRM]:confirmations,[VERIFIED]:verified,[SENT]:already});
     result.failed++;
     rowResult.status='failed';
     rowResult.error=String(e?.message||e).slice(0,350);
     if(e?.httpStatus)rowResult.httpStatus=e.httpStatus;
   }finally{result.entries.push(rowResult);}
 }
 // Count pending on CURRENT local values, not an earlier snapshot.
 const end=await chrome.storage.local.get(null),pending=[];
 for(const [key,value] of Object.entries(end))if(TRACKED(key)&&value!==undefined&&(!scope||scope.has(key))){
   if(key.startsWith(PREFIX)&&!RPGMBSafe.matchesChat(value,key))continue; // reported separately as quarantined
   if(RPGMBMeta.classify(key)&&(!RPGMBMeta.validRecord(key,value)||await RPGMBMeta.hash(value.value)!==value.head))continue;
   const hash=await digest(value);
   const c=confirmations[key];
   if(c?.hash!==hash||c.user!==cfg.user_id||c.url!==cfg.url)pending.push(key);
 }
 result.pendingCount=pending.length;
 result.pendingRawCount=pending.filter(k=>k.startsWith(PREFIX)).length;
 result.pendingSaveCount=pending.filter(k=>Boolean(RPGMBMeta.classify(k))).length;
 result.received=received;result.conflicts=conflicts;
 // A read-back success for other keys must not hide individual failures.
 const status=result.failed||mergeWarning||result.quarantined?'partial':pending.length?'pending':'ok';
 await chrome.storage.local.set({[UPLOAD_REPORT]:result});
 await putState({status,
   error:result.failed?`${result.failed} khóa lỗi. Xem báo cáo Cloud từng khóa.`:(result.quarantined?`${result.quarantined} khóa RAW sai nguồn, được cách ly, không upload.`:(mergeWarning||null)),
   lastAttempt:new Date().toISOString(),
   ...(status==='ok'?{lastSuccess:new Date().toISOString(),lastVerifiedAt:new Date().toISOString()}:{}),
   sent:result.uploaded,verifiedCount:result.uploaded+result.existing,
   pendingCount:pending.length,pendingRawCount:result.pendingRawCount,pendingSaveCount:result.pendingSaveCount,
   received,conflicts,failedCount:result.failed,uploadReportAt:result.at,
   lastReceivedAt:received>0?result.at:((await get(S))?.lastReceivedAt||null)});
 if(pending.length||result.failed||mergeWarning)chrome.alarms.create('rpgmb-cloud-after-write',{delayInMinutes:result.failed?5:1});
 return {sent:result.uploaded,existing:result.existing,failed:result.failed,
   pending:pending.length,received,conflicts,mergeWarning,quarantined:result.quarantined};
}
async function doSync({force=false,onlyKeys=null}={}){
 if(await isPaused())return {skipped:true,notice:'Đã tạm dừng do factory reset'};
 await ensureScopedMeta();
 const testScope=await freshScope();
 if(testScope?.size===0)return {skipped:true,notice:'Chưa chọn chat test hợp lệ: Cloud không được đồng bộ'};
 const {cfg,auth}=await authFetch();
 if(onlyKeys)return deliverKeys({cfg,auth,onlyKeys:new Set(onlyKeys.filter(TRACKED)),force:true});
 const base=cfg.url+'/rest/v1/rpg_sync_records';
 let all=[],from=0,mergeWarning=null,merged={received:0,conflicts:0};
 try{
   while(true){
     const page=await retryIO(()=>request(base+'?select=record_key,device_id,payload,created_at&order=created_at.asc&limit=500&offset='+from,
       {method:'GET'},auth),'DOWNLOAD');
     if(!Array.isArray(page))throw Error('DOWNLOAD: Supabase không trả về danh sách');
     all.push(...page);
     if(page.length<500)break;
     from+=500;
     if(from>10000)throw Error('Quá 10000 bản ghi, không dùng lịch sử thiếu');
   }
   const fetched=all;
   // Restore authoritative user-owned Campaign and assignment metadata first.
   // RAW is never admitted until the refreshed Campaign scope says so.
   if(!testScope){
     const metadata=fetched.filter(row=>row.record_key?.startsWith(DELETE_PREFIX)||Boolean(RPGMBMeta.classify(row.record_key)))
       .sort((a,b)=>{
         const priority={campaign:1,assign:2,proposals:3};
         const rank=x=>x.record_key.startsWith(DELETE_PREFIX)?0:priority[RPGMBMeta.classify(x.record_key).kind];
         return rank(a)-rank(b);
       });
     const latestMeta=new Map();for(const row of metadata)latestMeta.set(row.record_key+'|'+row.device_id,row);
     const metaResult=await mergeRemote([...latestMeta.values()]);
     merged.received+=metaResult.received;merged.conflicts=metaResult.conflicts;
   }
   let scope=await assignedScope();
   all=fetched.filter(row=>scope.has(row.record_key));
   const latest=new Map();for(const row of all)latest.set(row.record_key+'|'+row.device_id,row);
   const rawResult=await mergeRemote([...latest.values()]);
   merged.received+=rawResult.received;merged.conflicts=rawResult.conflicts;
   // Fresh multi-device restore: importing the selected chat's assignment can
   // reveal the campaign scope in this very sync. Reuse the SAME downloaded
   // rows, never admit any unrelated campaign keys.
   if(scope){
     const expanded=await assignedScope();
     const extra=[...expanded].filter(k=>!scope.has(k));
     if(extra.length){
       const additional=fetched.filter(row=>extra.includes(row.record_key));
       const newer=new Map();for(const row of additional)newer.set(row.record_key+'|'+row.device_id,row);
       const result=await mergeRemote([...newer.values()]);
       merged.received+=result.received;merged.conflicts=result.conflicts;
       all.push(...additional);
     }
   }
   // Canonical ledger is generated only from fully downloaded snapshot evidence.
   const localBefore=await chrome.storage.local.get(null),grouped=new Map();
   for(const row of all){
     if(!row.record_key?.startsWith(PREFIX)||!Array.isArray(row.payload?.messages)||!RPGMBSafe.matchesChat(row.payload,row.record_key))continue;
     const chatId=row.record_key.slice(PREFIX.length);
     if(!grouped.has(chatId))grouped.set(chatId,[]);
     grouped.get(chatId).push(row.payload);
   }
   for(const [key,payload] of Object.entries(localBefore)){
     if(!key.startsWith(PREFIX)||!scope.has(key)||!Array.isArray(payload?.messages)||!RPGMBSafe.matchesChat(payload,key))continue;
     const chatId=key.slice(PREFIX.length);
     if(!grouped.has(chatId))grouped.set(chatId,[]);
     grouped.get(chatId).push(payload);
   }
   const ledgerChanges={};
   for(const [chatId,snapshots] of grouped){
     // A byte-equivalent RAW snapshot may exist in local storage AND in a
     // cloud archive. Count it as one piece of evidence, not two revisions.
     const seen=new Set(),unique=[];
     for(const snapshot of snapshots){
       const signature=JSON.stringify(stable(snapshot));
       if(!seen.has(signature)){seen.add(signature);unique.push(snapshot);}
     }
     const result=RPGLedger.build(unique);
     const payload={format:'rpgmb-canonical-ledger-v075',chatId,version:1,
       messages:result.messages.map(m=>({id:m.id,role:m.role,text:m.text,
         canonicalIndex:m.canonicalIndex,sourceTurn:m.sourceTurn??null,firstSeen:m.firstSeen??null})),
       integrity:result.integrity,legacyCount:result.legacyCount,suspect:result.suspect,
       orderingConflicts:result.orderingConflicts};
     const key=LEDGER_PREFIX+chatId;
     if(!equalJSON(localBefore[key],payload))ledgerChanges[key]=payload;
   }
   if(Object.keys(ledgerChanges).length)await chrome.storage.local.set(ledgerChanges);
 }catch(e){
   // Incomplete Cloud metadata may contain a deletion tombstone; do NOT
   // upload stale local Campaigns before learning which were deleted.
   // Fail closed. The user can retry after restoring network access.
   mergeWarning='Không đọc/gộp đủ cloud, đã chặn gửi để tránh hồi sinh dữ liệu cũ: '+String(e.message||e).slice(0,180);
   await putState({status:'sync-blocked',error:mergeWarning});
   return {skipped:true,notice:mergeWarning,received:merged.received,sent:0,existing:0,failed:0,pending:null};
 }
 return deliverKeys({cfg,auth,force,received:merged.received,conflicts:merged.conflicts,mergeWarning});
}
// Read-only audit: compare each currently stored local payload to its EXACT
// immutable cloud snapshot. A successful sync time alone is not evidence that
// every visible turn, legacy message, or provisional observation is backed up.
// Read-only pairing diagnostic. A device appearing here means it has written at
// least one immutable snapshot. It does NOT establish that another device is
// online, that all ChatGPT turns were captured, or that the active path is known.
function summarizePeerSnapshots(rows,currentDeviceId){
 const byDevice=new Map();
 for(const row of Array.isArray(rows)?rows:[]){
   if(!row||typeof row.device_id!=='string'||!row.device_id.trim())continue;
   const id=row.device_id;
   const old=byDevice.get(id)||{deviceId:id,snapshots:0,rawSnapshots:0,metaSnapshots:0,lastSnapshot:null};
   old.snapshots++;
   if(typeof row.record_key==='string'&&row.record_key.startsWith(PREFIX))old.rawSnapshots++;
   else if(typeof row.record_key==='string'&&RPGMBMeta.classify(row.record_key))old.metaSnapshots++;
   const at=typeof row.created_at==='string'?row.created_at:null;
   if(at&&(!old.lastSnapshot||at>old.lastSnapshot))old.lastSnapshot=at;
   byDevice.set(id,old);
 }
 const devices=[...byDevice.values()].map(d=>({...d,isThisDevice:d.deviceId===currentDeviceId}));
 devices.sort((a,b)=>(b.lastSnapshot||'').localeCompare(a.lastSnapshot||''));
 return {devices,otherDeviceCount:devices.filter(d=>!d.isThisDevice).length};
}
async function cloudPeers(){
 const {cfg,auth}=await authFetch();
 const base=cfg.url+'/rest/v1/rpg_sync_records';
 const rows=[];
 for(let offset=0;offset<10000;offset+=500){
   const url=base+'?select=device_id,record_key,created_at&user_id=eq.'+encodeURIComponent(cfg.user_id)+'&order=created_at.desc&limit=500&offset='+offset;
   const part=await retryIO(()=>request(url,{method:'GET'},auth),'DEVICE STATUS');
   if(!Array.isArray(part))throw Error('Không thể đọc danh sách thiết bị từ Cloud');
   rows.push(...part);
   if(part.length<500)break;
   if(offset===9500)throw Error('Quá nhiều snapshot; chưa thể kiểm tra đầy đủ thiết bị');
 }
 const counts=summarizePeerSnapshots(rows,cfg.device_id);
 const out={at:new Date().toISOString(),thisDeviceId:cfg.device_id,scannedSnapshots:rows.length,...counts,
   note:'Thiết bị khác chỉ xuất hiện sau khi đã upload ít nhất một snapshot. Đây là bằng chứng lưu trữ, không phải báo online.'};
 await chrome.storage.local.set({'rpgmb-cloud-peer-report-v0924':out});
 return out;
}
async function auditCloud(){
 await ensureScopedMeta();
 const {cfg,auth}=await authFetch();
 const base=cfg.url+'/rest/v1/rpg_sync_records';
 const local=await chrome.storage.local.get(null);
 const scope=await assignedScope();
 const keys=Object.keys(local).filter(k=>TRACKED(k)&&local[k]!==undefined&&(!scope||scope.has(k)));
 const entries=[];let confirmed=0,missing=0,mismatched=0,quarantined=0;
 for(const key of keys){
  const payload=local[key];
  if(key.startsWith(DELETE_PREFIX)&&!deletionRecord(key,payload)){entries.push({key,state:'quarantined',reason:'Invalid campaign deletion record'});quarantined++;continue;}
  if(RPGMBMeta.classify(key)&&(!RPGMBMeta.validRecord(key,payload)||await RPGMBMeta.hash(payload.value)!==payload.head)){
    entries.push({key,state:'quarantined',reason:'Invalid scoped metadata source or digest'});quarantined++;continue;
  }
  if(key.startsWith(PREFIX)&&!RPGMBSafe.matchesChat(payload,key)){
    entries.push({key,state:'quarantined',reason:'source-chat identity mismatch or legacy alias'});quarantined++;continue;
  }
  const hash=await digest(payload),id=await digest({key,hash,user:cfg.user_id});
  const rows=await request(base+'?select=id,record_key,content_hash,payload&id=eq.'+encodeURIComponent(id)+'&limit=1',{method:'GET'},auth);
  let state='missing';
  if(rows.length===1){state=rows[0].record_key===key&&rows[0].content_hash===hash&&equalJSON(rows[0].payload,payload)?'confirmed':'mismatch';}
  if(state==='confirmed')confirmed++;else if(state==='missing')missing++;else mismatched++;
  entries.push({key,state,localNativeMessages:Array.isArray(payload?.messages)?payload.messages.filter(m=>RPGLedger.nativeId(m?.id)).length:null,
    localLegacy:Array.isArray(payload?.legacyMessages)?payload.legacyMessages.length:null,
    localProvisional:Array.isArray(payload?.provisionalObservations)?payload.provisionalObservations.length:null,
    localOccurrences:Array.isArray(payload?.provisionalOccurrences)?payload.provisionalOccurrences.length:null,
    localFrames:Array.isArray(payload?.viewportEvidence)?payload.viewportEvidence.length:null,
    unconfirmedNativeClaims:Array.isArray(payload?.messages)?payload.messages.filter(m=>RPGLedger.nativeId(m.id)&&m.identityVerified!==true).length:null,
    identityConflicts:Array.isArray(payload?.identityConflicts)?payload.identityConflicts.length:null});
 }
 const report={at:new Date().toISOString(),total:entries.length,confirmed,missing,mismatched,quarantined,entries,
   caveat:'Exact local snapshots only. Does NOT prove ChatGPT history completeness or identity of provisional captures.'};
 await chrome.storage.local.set({'rpgmb-cloud-audit-v079':report});
 return report;
}
let inFlight=null;
async function sync(options={}){
 if((await get(CLOUD_ARMED))!==true)return {skipped:true,notice:'Cloud đang khóa an toàn sau đợt clean. Chỉ bật lại khi đã kiểm tra local trên cả thiết bị.'};
 if(await isPaused())return {skipped:true,notice:'Đã tạm dừng sau factory reset'};
 if(inFlight)return {busy:true,notice:'Đồng bộ khác đang chạy, chờ hoàn tất rồi thử lại'};
 inFlight=doSync(options);
 try{return await inFlight;}catch(e){await putState({status:'error',error:String(e.message||e)});throw e}
 finally{inFlight=null;}
}
// Recreate the recurring background alarm whenever the service worker starts.
// MV3 workers can sleep: this is intentionally an alarm, not a popup timer.
chrome.alarms.get('rpgmb-cloud-sync').then(a=>{if(!a)chrome.alarms.create('rpgmb-cloud-sync',{periodInMinutes:1});});
chrome.runtime.onInstalled.addListener(()=>{
 chrome.storage.local.get(CLOUD_ARMED).then(state=>{
  if(!Object.hasOwn(state,CLOUD_ARMED))chrome.storage.local.set({[CLOUD_ARMED]:false});
 });
 chrome.alarms.create('rpgmb-cloud-sync',{periodInMinutes:1});
});
chrome.runtime.onStartup.addListener(()=>chrome.alarms.create('rpgmb-cloud-sync',{periodInMinutes:1}));
// Debounce writes into a delayed alarm; never issue a cloud request from content scripts.
// Automatic Day append uses the *already verified* local ledger and only an
// explicitly assigned chat. RAW is never modified by this worker.
let autoDayQueue=Promise.resolve();
async function updateAutoDay(chatId){
 if(await isPaused())return;
 const test=await get(TEST);if(test?.active&&test.allowedChatId!==chatId)return;
 const chat=await get(PREFIX+chatId),assignment=await get('rpgmb-assign-v04')||{};
 if(!chat||!RPGMBSafe.matchesChat(chat,PREFIX+chatId))return;
 const campId=assignment[chatId];if(!RPGMBMeta.safeId(campId||''))return;
 const campaigns=await get('rpgmb-campaigns-v04')||{},camp=campaigns[campId];
 if(!camp||!RPGMBAutoDay.autoOf(RPGMBDay.get(camp)))return;
 if(RPGMBBranch.isCheckpoint(camp,chatId))return; // checkpoint copies are archive-only; no auto Day duplication
 const {campaign,report}=RPGMBAutoDay.apply(camp,campId,chat,assignment);
 if(!campaign){if(report.error)await chrome.storage.local.set({'rpgmb-auto-day-warning-v095':{chatId,reason:report.error,at:new Date().toISOString()}});return;}
 const metaKey=RPGMBMeta.campaignKey(campId),original=await get(metaKey);
 const prepared=await RPGMBMeta.prepare('campaign',campId,campaign,original);
 // Avoid clobbering a popup edit that occurred during the read/prepare cycle.
 const latest=await chrome.storage.local.get(['rpgmb-campaigns-v04',metaKey]);
 if(JSON.stringify(latest[metaKey]?.head)!==JSON.stringify(original?.head)||JSON.stringify(latest['rpgmb-campaigns-v04']?.[campId])!==JSON.stringify(camp)){
  await chrome.storage.local.set({'rpgmb-auto-day-warning-v095':{chatId,reason:'Save được sửa đồng thời; Auto Day tạm bỏ qua lượt này, sẽ thử lại lần sau.',at:new Date().toISOString()}});
  return;
 }
 await chrome.storage.local.set({'rpgmb-campaigns-v04':{...latest['rpgmb-campaigns-v04'],[campId]:campaign},[metaKey]:prepared,'rpgmb-auto-day-last-v095':{chatId,campaignId:campId,added:report.added,createdDays:report.createdDays,at:new Date().toISOString()}});
}
function queueAutoDay(chatId){autoDayQueue=autoDayQueue.then(()=>updateAutoDay(chatId)).catch(e=>chrome.storage.local.set({'rpgmb-auto-day-warning-v095':{chatId,reason:String(e).slice(0,250),at:new Date().toISOString()}}));}
chrome.storage.onChanged.addListener((changes,area)=>{
 if(area!=='local'||resetRequested)return;
 const localRaw=Object.keys(changes).filter(k=>k.startsWith(PREFIX)&&RPGMBSafe.recordKey(k.slice(PREFIX.length)));
 if(localRaw.length){for(const key of localRaw)queueAutoDay(key.slice(PREFIX.length));return;}
 // Assigning a NEW chat to a Campaign lets the player admit that source explicitly.
 if(changes['rpgmb-assign-v04']){
  const before=changes['rpgmb-assign-v04'].oldValue||{},after=changes['rpgmb-assign-v04'].newValue||{};
  for(const [id,campId] of Object.entries(after))if(before[id]!==campId&&RPGMBSafe.recordKey(id))queueAutoDay(id);
 }
});
chrome.storage.onChanged.addListener((changes,area)=>{
 if(area!=='local'||!Object.keys(changes).some(TRACKED))return;
 isPaused().then(paused=>{if(!paused)chrome.alarms.create('rpgmb-cloud-after-write',{delayInMinutes:0.1});}).catch(()=>{});
});
chrome.alarms.onAlarm.addListener(a=>{if(a.name==='rpgmb-cloud-sync'||a.name==='rpgmb-cloud-after-write')sync().catch(()=>{});});
chrome.runtime.onMessage.addListener((msg,sender,send)=>{(async()=>{
 if(msg.type==='factory-reset-local'){
   // Reset is local-only. The cloud was wiped independently by the user.
   // Wait for any active sync to end before the final storage clear.
   resetRequested=true;
   try{
     await chrome.storage.local.set({[PAUSED]:true});
     await chrome.alarms.clear('rpgmb-cloud-sync');
     await chrome.alarms.clear('rpgmb-cloud-after-write');
     if(inFlight)await inFlight.catch(()=>{});
     const before=await chrome.storage.local.get(null);
     // Content scripts already running on a page can be completing a frame.
     // A short second clear while PAUSED=true closes that tail race.
     await chrome.storage.local.clear();
     await chrome.storage.local.set({[PAUSED]:true});
     await new Promise(resolve=>setTimeout(resolve,700));
     await chrome.storage.local.clear();
     const at=new Date().toISOString();
     const receipt={cleared:true,at,deletedKeys:Object.keys(before).filter(k=>k!==PAUSED).length,version:'0.9.3'};
     await chrome.storage.local.set({[PAUSED]:true,[TEST]:{active:true,allowedChatId:null,resetAt:at},'rpgmb-factory-reset-receipt-v092':receipt});
     const remaining=Object.keys(await chrome.storage.local.get(null)).filter(k=>![PAUSED,TEST,'rpgmb-factory-reset-receipt-v092'].includes(k));
     if(remaining.length)throw Error('Local lại xuất hiện khóa trong lúc reset: '+remaining.slice(0,4).join(', '));
     return {...receipt,scope:'local-this-browser-only'};
   }finally{resetRequested=false;}
 }
 if(msg.type==='factory-start-test'){
   const id=String(msg.chatId||'');
   if(!RPGMBSafe.validChatId?.(id) && !/^[a-z0-9-]{16,}$/i.test(id))throw Error('Chat ID không hợp lệ');
   const url=String(msg.sourceUrl||'');
   if(RPGMBSafe.chatIdFromUrl(url)!==id)throw Error('URL hiện tại không trùng chat ID');
   const state=await get(TEST);
   if(!state?.active)throw Error('Hãy reset local trước khi bắt đầu test sạch');
   await chrome.storage.local.set({[TEST]:{...state,active:true,allowedChatId:id,startedAt:new Date().toISOString()},[PAUSED]:false});
   return {started:true,chatId:id};
 }
 if(msg.type==='factory-exit-test'){
   await chrome.storage.local.set({[TEST]:{active:false,exitedAt:new Date().toISOString()},[PAUSED]:false});
   return {exited:true};
 }
 if(msg.type==='cloud-arm'){
   if(await isPaused())throw Error('Capture đang bị pause/reset; chưa bật Cloud được');
   await chrome.storage.local.set({[CLOUD_ARMED]:true});
   chrome.alarms.create('rpgmb-cloud-after-write',{delayInMinutes:0.1});
   return {enabled:true};
 }
 if(msg.type==='cloud-disarm'){
   await chrome.storage.local.set({[CLOUD_ARMED]:false});
   await chrome.alarms.clear('rpgmb-cloud-after-write');
   return {enabled:false};
 }
 if(msg.type==='cloud-login'){
  const url=endpoint(msg.url),key=acceptClientKey(String(msg.key||'').trim()),device_id=(await get(CFG))?.device_id||crypto.randomUUID();
  const t=await request(url+'/auth/v1/token?grant_type=password',{method:'POST'},{key}, {email:msg.email,password:msg.password});
  await chrome.storage.local.set({[CFG]:{url,key,access_token:t.access_token,refresh_token:t.refresh_token,expires_at:Date.now()+t.expires_in*1000,user_id:t.user.id,device_id}});
  chrome.alarms.create('rpgmb-cloud-sync',{periodInMinutes:1});return {user:t.user.email};
 }
 if(msg.type==='cloud-peers')return await cloudPeers();
 if(msg.type==='cloud-sync')return await sync({force:true});
 if(msg.type==='cloud-retry-missing'){
   const report=await get('rpgmb-cloud-audit-v079');
   const keys=(report?.entries||[]).filter(e=>e.state==='missing'||e.state==='mismatch').map(e=>e.key);
   if(!keys.length)return {nothingToRetry:true};
   return await sync({onlyKeys:keys,force:true});
 }
 if(msg.type==='cloud-upload-report')return await get(UPLOAD_REPORT)||null;
 if(msg.type==='cloud-audit')return await auditCloud();
 if(msg.type==='cloud-resolve-meta'){
   const conflicts=await get('rpgmb-cloud-conflicts-v06')||[];
   const conflict=conflicts.find(x=>x.id===msg.id&&x.kind==='META');
   if(!conflict?.metaKey||!['local','remote'].includes(msg.choice))throw Error('Không tìm được xung đột Save hợp lệ');
   const key=conflict.metaKey,ref=RPGMBMeta.classify(key);
   if(!ref)throw Error('Khóa metadata không hợp lệ');
   let local=await get(key);const remote=conflict.remoteRecord;
   if(!remote||!RPGMBMeta.validRecord(key,remote))throw Error('Thiếu bản Cloud xác minh; không tự ghi đè');
   if(!RPGMBMeta.validRecord(key,local)){
     const view=ref.kind==='campaign'?(await get('rpgmb-campaigns-v04')||{})[ref.id]:
       ref.kind==='assign'?(await get('rpgmb-assign-v04')||{})[ref.id]:
       (await get('rpgmb-proposals-v05')||[]).filter(x=>x.campaignId===ref.id);
     if(!RPGMBMeta.validValue(ref.kind,ref.id,view))throw Error('Bản local không hợp lệ; hãy Xuất JSON để xem xét');
     local=await RPGMBMeta.prepare(ref.kind,ref.id,view,null);
   }
   const value=msg.choice==='remote'?remote.value:local.value;
   const head=await RPGMBMeta.hash(value);
   const ancestors=[...new Set([local.head,remote.head,...local.ancestors,...remote.ancestors].filter(x=>x!==head))].slice(0,128);
   const updated={format:'rpgmb-scoped-meta-v093',kind:ref.kind,id:ref.id,value:structuredClone(value),head,ancestors,updatedAt:new Date().toISOString()};
   const changes={[key]:updated,'rpgmb-cloud-conflicts-v06':conflicts.filter(c=>c.id!==conflict.id)};
   if(ref.kind==='campaign')changes['rpgmb-campaigns-v04']={...(await get('rpgmb-campaigns-v04')||{}),[ref.id]:value};
   if(ref.kind==='assign')changes['rpgmb-assign-v04']={...(await get('rpgmb-assign-v04')||{}),[ref.id]:value};
   if(ref.kind==='proposals')changes['rpgmb-proposals-v05']=[...(await get('rpgmb-proposals-v05')||[]).filter(x=>x.campaignId!==ref.id),...value];
   await chrome.storage.local.set(changes);
   return {saved:true,key,choice:msg.choice};
 }
 if(msg.type==='cloud-resolve'){
   const conflicts=await get('rpgmb-cloud-conflicts-v06')||[];const c=conflicts.find(x=>x.id===msg.id);
   if(!c||c.kind!=='CANON')throw Error('Không tìm được xung đột CANON');
   if(!['local','remote','manual'].includes(msg.choice))throw Error('Lựa chọn không hợp lệ');
   const text=msg.choice==='remote'?c.remoteText:msg.choice==='local'?c.localText:String(msg.content||'');
   if(!text.trim())throw Error('Nội dung hợp nhất trống');
   const key='rpgmb-campaigns-v04',campaigns=await get(key)||{};if(!campaigns[c.campaign])throw Error('Campaign không tồn tại trên máy này');
   campaigns[c.campaign].sections??={};campaigns[c.campaign].sections[c.section]=text;campaigns[c.campaign].updatedAt=new Date().toISOString();
   const scoped=RPGMBMeta.campaignKey(c.campaign);
   const next=await RPGMBMeta.prepare('campaign',c.campaign,campaigns[c.campaign],await get(scoped));
   const resolved=await get(RESOLVED)||{};resolved[c.id]=true;
   await chrome.storage.local.set({[key]:campaigns,[scoped]:next,[RESOLVED]:resolved,'rpgmb-cloud-conflicts-v06':conflicts.filter(x=>x.id!==c.id)});
   return {saved:true};
 }
 if(msg.type==='cloud-logout'){await chrome.storage.local.remove([CFG,SENT,VERIFIED]);await chrome.storage.local.set({[CLOUD_ARMED]:false});return {done:true};}
 throw Error('Unsupported action');})().then(result=>send({ok:true,result})).catch(err=>send({ok:false,error:String(err.message||err)}));return true;});
