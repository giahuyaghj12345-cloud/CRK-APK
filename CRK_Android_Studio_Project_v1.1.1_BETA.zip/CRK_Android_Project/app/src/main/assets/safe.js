// Shared provenance and non-destructive backup primitives. No network or DOM dependency.
(function(root){
'use strict';
const UUID=/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
const norm=s=>String(s||'').replace(/\r\n?/g,'\n').replace(/\u00a0/g,' ').trim();
function chatIdFromUrl(source){
 try {const u=new URL(source);if(u.hostname!=='chatgpt.com'||u.protocol!=='https:')return null;
 const found=u.pathname.match(/(?:^|\/)c\/([0-9a-f-]{36})(?:\/|$)/i);return found&&UUID.test(found[1])?found[1].toLowerCase():null;}
 catch{return null;}
}
const recordKey=id=>UUID.test(String(id||''))?'rpgmb:'+id.toLowerCase():null;
function matchesChat(payload,key){
 if(!key?.startsWith('rpgmb:') || !UUID.test(key.slice(6)) ||
  !payload || typeof payload!=='object' || Array.isArray(payload) ||
  String(payload.chatId||'').toLowerCase()!==key.slice(6).toLowerCase())return false;
 if(payload.sourceUrl && chatIdFromUrl(payload.sourceUrl)!==key.slice(6).toLowerCase())return false;
 return true;
}
function trustedOccurrence(o,chatId){
 return !!o&&typeof o==='object'&&UUID.test(o.observationId)&&
  o.role!=='unknown'&&['user','assistant'].includes(o.role)&&
  typeof o.text==='string'&&!!norm(o.text)&&
  o.sourceChatId===chatId && o.captureOrigin==='live-conversation-dom-v090'&&
  chatIdFromUrl(o.sourceUrl)===chatId;
}
function arrayMerge(local,remote,getId,conflicts=[]){
 const results=Array.isArray(local)?local.slice():[],seen=new Map();
 results.forEach((x,i)=>{const id=getId(x);if(id&&!seen.has(id))seen.set(id,i);});
 for(const x of Array.isArray(remote)?remote:[]){const id=getId(x);if(!id){results.push(x);continue;}
  const index=seen.get(id);if(index===undefined){seen.set(id,results.length);results.push(x);}
  else if(JSON.stringify(results[index])!==JSON.stringify(x))conflicts.push({id,kind:'EVIDENCE',reason:'same ID, divergent payload',local:results[index],remote:x});
 }
 return results;
}
function preserveLegacy(local,incoming){
 const a=Array.isArray(local)?local:[],b=Array.isArray(incoming)?incoming:[];
 const same=(x,y)=>JSON.stringify(x)===JSON.stringify(y);
 if(b.length===0)return a.slice();
 if(a.some((_,start)=>start+b.length<=a.length&&b.every((item,i)=>same(item,a[start+i]))))return a.slice();
 if(a.every((item,i)=>i<b.length&&same(item,b[i])))return b.slice();
 return a.concat(b); // Cannot infer identity of two byte-equal legacy turns.
}
function stableEvidence(value){
 if(Array.isArray(value))return value.map(stableEvidence);
 if(value&&typeof value==='object')return Object.fromEntries(Object.keys(value).sort().map(k=>[k,stableEvidence(value[k])]));
 return value;
}
function evidenceSignature(value){return JSON.stringify(stableEvidence(value));}
// An imported conflict observation is evidence, not a chat turn. The identical
// observation must not grow unbounded across repeated restore operations.
function mergeConflictEvidence(...groups){
 const out=[],seen=new Set();
 for(const group of groups)for(const item of Array.isArray(group)?group:[]){
  const signature=evidenceSignature(item);
  if(!seen.has(signature)){seen.add(signature);out.push(item);}
 }
 return out;
}
function withoutTimestamp(v){const copy={...v};delete copy.updatedAt;return evidenceSignature(copy);}
function mergeChatBackup(local,incoming){
 const old=local||{},out={...incoming,...old};const disagreements=[];
 const messages=arrayMerge(old.messages,incoming.messages,x=>x?.id,disagreements);
 // Import never treats a text match as a turn identity. UUID disagreement is
 // quarantined, and originals remain inside backup/importConflictEvidence.
 out.messages=messages;
 const props=[['provisionalOccurrences','observationId'],['viewportEvidence','frameId'],['provisionalObservations',null],['legacyMessages',null],['remoteLegacyClaims','fingerprint'],['identityConflicts',null],['remoteEvidenceArchive','archiveId']];
 for(const [field,idField] of props){
  out[field]=idField?arrayMerge(old[field],incoming[field],x=>x?.[idField],disagreements):
   preserveLegacy(old[field],incoming[field]);
 }
 out.importConflictEvidence=mergeConflictEvidence(old.importConflictEvidence,incoming.importConflictEvidence,disagreements);
 // A user-selected DOM path is a local REVIEW, not proof of a ChatGPT active
 // branch. Never silently overwrite the local choice with a different backup;
 // preserve imported selections as review history for explicit re-selection.
 const reviewOk=r=>r&&r.schema===1&&r.chatId===(old.chatId||incoming.chatId)&&
  r.sourceUrl===(old.sourceUrl||incoming.sourceUrl)&&Array.isArray(r.ids)&&r.ids.length>0&&
  r.ids.every(id=>UUID.test(id))&&typeof r.digest==='string';
 const localReview=reviewOk(old.reviewedPath)?old.reviewedPath:null;
 const otherReview=reviewOk(incoming.reviewedPath)?incoming.reviewedPath:null;
 if(localReview||otherReview)out.reviewedPath=localReview||otherReview;else delete out.reviewedPath;
 const hist=[],keys=new Set();
 for(const r of [...(old.reviewedPathHistory||[]),...(incoming.reviewedPathHistory||[]),
   ...(localReview&&otherReview&&localReview.reviewId!==otherReview.reviewId?[otherReview]:[])]){
  if(!reviewOk(r))continue;
  const id=r.reviewId||r.digest;if(keys.has(id)||id===out.reviewedPath?.reviewId)continue;
  keys.add(id);hist.push(r);
 }
 if(hist.length)out.reviewedPathHistory=hist;else delete out.reviewedPathHistory;
 // Refuse cross-chat metadata rewriting by a backup, even when a title changed.
 if(old.chatId)out.chatId=old.chatId;
 if(old.sourceUrl)out.sourceUrl=old.sourceUrl;
 // A no-op restore must NOT mutate `updatedAt`: cloud snapshots are immutable
 // and a timestamp-only rewrite would consume free-tier quota indefinitely.
 if(local&&withoutTimestamp(out)===withoutTimestamp(old))return local;
 out.updatedAt=new Date().toISOString();
 return out;
}
root.RPGMBSafe={UUID,norm,chatIdFromUrl,recordKey,matchesChat,trustedOccurrence,arrayMerge,mergeChatBackup};
})(typeof globalThis!=='undefined'?globalThis:this);
