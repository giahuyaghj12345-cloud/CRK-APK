// Day UI; writes only on deliberate user actions. Available state from popup.js.
(function(){
 'use strict';
 const ui=id=>document.getElementById(id);
 let traced=[];
 function dayState(){const campaign=campaigns[current()];return campaign?RPGMBDay.get(campaign):null;}
 function dayRows(dayId=null,includeUnassigned=true){const idx=dayState();return idx?RPGMBDay.scopedRows(chats,assign,current(),idx,dayId,includeUnassigned,campaigns[current()]?.branchIndex,campaigns[current()]?.sourceEvents):[];}
 function renderDay(){const idx=dayState(),previous=ui('day-select').value;
  fillOptions(ui('day-select'),idx?Object.values(idx.items).map(d=>[d.id,`${d.label} (${d.status})`]):[],previous);
  const selected=ui('day-select').value;
  ui('day-status').value=idx?.items[selected]?.status||'OPEN';
  const aut=RPGMBAutoDay.autoOf(idx);
  ui('day-auto-status').textContent=aut?`✅ Đang tự lưu RAW mới vào ${idx.items[aut.activeDayId]?.label||'Day'}; tự đổi ngày theo tiêu đề GM: ${aut.autoAdvance?'BẬT':'TẮT'}.`:'Auto Day đang tắt. RAW cũ giữ nguyên; bạn có thể bật cho Day đã tạo.';
  ui('day-auto-heading').checked=!!aut?.autoAdvance;
  const chatBefore=ui('day-chat').value;
  fillOptions(ui('day-chat'),campaignChats(current()).map(c=>[c.chatId,`${c.title||c.chatId} (${RPGLedger.ledger(c).messages.length} RAW đã xác minh)`]),chatBefore);
  const rows=ui('day-ranges');rows.replaceChildren();
  for(const r of (idx?.ranges||[]).filter(x=>x.dayId===selected)){
   const div=document.createElement('div');div.className='day-entry';
   const label=document.createElement('span');label.textContent=`${chats.find(c=>c.chatId===r.chatId)?.title||r.chatId}: lượt #${r.start}–#${r.end}`;
   const del=document.createElement('button');del.className='secondary';del.textContent='Gỡ liên kết Day';del.onclick=async()=>{const c=campaigns[current()];c.dayIndex.ranges=c.dayIndex.ranges.filter(x=>x.id!==r.id);await persist();renderDay();info('Đã gỡ liên kết; RAW gốc vẫn nguyên.');};
   div.append(label,del);rows.append(div);
  }
  const filter=ui('memory-day-filter'),old=filter.value;
  fillOptions(filter,[['','Tất cả Day và RAW chưa gán'],...Object.values(idx?.items||{}).map(d=>[d.id,d.label])],old);
  renderRevisions();
 }
 function renderRevisions(){const selected=ui('revision-message'),old=selected.value,rows=dayRows(null,true);
  fillOptions(selected,[['','Chọn lượt RAW'],...rows.map(r=>[`${r.chatId}|${r.messageId}`,`${r.chatTitle} #${r.ordinal} (${r.role}${r.revisions.length?' · '+r.revisions.length+' phiên bản cũ':''})`])],old);
  const r=rows.find(x=>`${x.chatId}|${x.messageId}`===selected.value);
  ui('revision-history').value=r?`SOURCE: ${r.messageId}\n${r.sourceEvent?'PLAYER báo trạng thái: '+r.sourceEvent.kind+' ('+r.sourceEvent.reason+')\n':''}${r.excluded?'⚠️ ĐÃ ĐÁNH DẤU LOẠI KHỎI CANON\n':''}HIỆN TẠI:\n${r.text}\n\nPHIÊN BẢN QUAN SÁT TRƯỚC:\n`+(r.revisions.length?r.revisions.map((x,i)=>`#${i+1} ${x.at||'không rõ thời điểm'} (${x.reason||'text changed'})\n${x.text}`).join('\n\n'):'Chưa có bản cũ được lưu'):'';
 }
 ui('day-create').onclick=async()=>{const c=campaigns[current()];if(!c)return info('Chưa có campaign');try{const idx=structuredClone(RPGMBDay.get(c));const id=RPGMBDay.create(idx,ui('day-new').value);c.dayIndex=idx;c.updatedAt=stamp();await persist();renderDay();ui('day-select').value=id;renderDay();ui('day-new').value='';info('Đã tạo Day. Chưa tự gán bất kỳ RAW nào.');}catch(e){info(e.message)}};
 ui('day-select').onchange=renderDay;
 ui('day-set-status').onclick=async()=>{const c=campaigns[current()],id=ui('day-select').value,s=ui('day-status').value;if(!c?.dayIndex?.items?.[id])return info('Chưa chọn Day');c.dayIndex.items[id].status=s;c.updatedAt=stamp();await persist();renderDay();info('Đã lưu trạng thái Day.');};
 ui('day-auto-start').onclick=async()=>{const c=campaigns[current()],dayId=ui('day-select').value;if(!c?.dayIndex?.items?.[dayId])return info('Tạo và chọn Day trước.');try{const idx=structuredClone(RPGMBDay.get(c));RPGMBAutoDay.arm(idx,dayId,chats,assign,current(),ui('day-auto-heading').checked);c.dayIndex=idx;c.updatedAt=stamp();await persist();renderDay();info('Auto Day đã bật. Chỉ RAW mới có UUID được tự nối, không nhập lại RAW trước đây.');}catch(e){info('Không bật Auto Day: '+e.message)}};
 ui('day-auto-stop').onclick=async()=>{const c=campaigns[current()];if(!c?.dayIndex?.auto?.enabled)return info('Auto Day đã tắt.');RPGMBAutoDay.disarm(c.dayIndex);c.updatedAt=stamp();await persist();renderDay();info('Đã tắt Auto Day; liên kết cũ giữ nguyên.');};
 ui('day-range-add').onclick=async()=>{const c=campaigns[current()],id=ui('day-select').value,chatId=ui('day-chat').value;if(!c?.dayIndex?.items?.[id])return info('Tạo Day trước');const count=RPGLedger.ledger(chats.find(x=>x.chatId===chatId)||{messages:[]}).messages.length;
  const a=Number(ui('day-start').value),b=Number(ui('day-end').value);if(b>count)return info(`Chat chỉ có ${count} RAW xác minh. Không thể gán #${b}.`);
  try{const ledger=RPGLedger.ledger(chats.find(x=>x.chatId===chatId));RPGMBDay.addRange(c.dayIndex,id,chatId,a,b,ledger.messages[a-1]?.id,ledger.messages[b-1]?.id);c.updatedAt=stamp();await persist();renderDay();ui('day-range-status').textContent=`Đã nối #${a}–#${b} vào ${c.dayIndex.items[id].label}.`;info('Đã liên kết đoạn RAW với Day, không sao chép hoặc sửa RAW.');}catch(e){info(e.message)}
 };
 ui('day-copy-raw').onclick=()=>{const id=ui('day-select').value,c=campaigns[current()];if(!c)return info('Chưa có campaign');try{copy(RPGMBDay.fullDayRaw(c,current(),chats,assign,id))}catch(e){info(e.message)}};
 ui('day-export-raw').onclick=()=>{const id=ui('day-select').value,c=campaigns[current()];if(!c)return info('Chưa có campaign');try{const text=RPGMBDay.fullDayRaw(c,current(),chats,assign,id),blob=new Blob([text],{type:'text/plain;charset=utf-8'}),url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download='RPGMB_'+(c.dayIndex.items[id]?.label||'Day').replace(/[^\w\d-]/g,'_')+'_RAW.txt';a.click();setTimeout(()=>URL.revokeObjectURL(url),20000);info('Đã yêu cầu tải FULL DAY RAW, kiểm tra file trong thư mục tải xuống.');}catch(e){info(e.message)}};
 ui('day-link-correction').onclick=async()=>{const c=campaigns[current()],dayId=ui('day-select').value,v=ui('revision-message').value,reason=ui('revision-reason').value.trim();if(!c?.dayIndex?.items?.[dayId]||!v||!reason)return info('Chọn Day, lượt RAW và ghi lý do correction.');const sep=v.indexOf('|'),chatId=v.slice(0,sep),messageId=v.slice(sep+1);if(!RPGMBDay.native(chatId)||!RPGMBDay.native(messageId))return info('Cần UUID nguồn hợp lệ.');c.dayIndex.links??=[];if(!c.dayIndex.links.some(x=>x.dayId===dayId&&x.chatId===chatId&&x.messageId===messageId))c.dayIndex.links.push({dayId,chatId,messageId,reason,at:stamp()});c.updatedAt=stamp();await persist();renderDay();info('Đã liên kết correction tới Day, không tự thay thế canon.');};
 let pendingStatus='';
 ui('revision-source-report').onclick=async()=>{
  const c=campaigns[current()],value=ui('revision-message').value,reason=ui('revision-reason').value.trim(),kind=ui('revision-source-status').value;
  if(!c||!value||!reason)return info('Chọn RAW và ghi lý do, không thể suy ra xóa từ DOM.');
  const sep=value.indexOf('|'),chatId=value.slice(0,sep),messageId=value.slice(sep+1);
  if(!RPGMBSourceEvents.kinds.includes(kind))return info('Loại sự kiện không hợp lệ.');
  const check=[current(),chatId,messageId,kind,reason].join('|');
  if(pendingStatus!==check){pendingStatus=check;return info('⚠️ PLAYER xác nhận sự kiện '+kind+'. Bấm lại để lưu nhãn. RAW vẫn giữ nguyên; nhãn này không chứng minh ChatGPT đã xóa.');}
  try{c.sourceEvents=RPGMBSourceEvents.record(c.sourceEvents,chatId,messageId,kind,reason);c.updatedAt=stamp();await persist();pendingStatus='';renderDay();info('Đã ghi báo cáo của PLAYER; RAW giữ nguyên, Recall sẽ không dùng bản bị đánh dấu cũ.');}
  catch(e){info('Không ghi nhận được: '+e.message);}
 };
 ui('day-detect').onclick=()=>{const out=ui('day-suggestions');out.replaceChildren();const suggestions=RPGMBDay.suggest(chats,assign,current());for(const h of suggestions){const d=document.createElement('div');d.className='day-entry';d.textContent=`${h.label} • ${h.role} #${h.ordinal} • chat ${h.chatId}\n${h.reason}\nGợi ý chỉ đọc, PLAYER tự tạo Day / gán khoảng.`;out.append(d)}if(!suggestions.length){const d=document.createElement('p');d.className='hint';d.textContent='Không tìm thấy tiêu đề Day rõ ràng. Bạn có thể tạo Day thủ công.';out.append(d)}info(`Tìm được ${suggestions.length} gợi ý Day chưa áp dụng.`);};
 ui('revision-message').onchange=renderRevisions;
 ui('revision-exclude').onclick=async()=>{const c=campaigns[current()],value=ui('revision-message').value,reason=ui('revision-reason').value.trim();if(!c||!value||!reason)return info('Chọn RAW và ghi lý do cụ thể.');const sep=value.indexOf('|'),chatId=value.slice(0,sep),messageId=value.slice(sep+1);if(!RPGMBDay.native(chatId)||!RPGMBDay.native(messageId))return info('Chỉ hỗ trợ lượt có native UUID.');const idx=structuredClone(RPGMBDay.get(c));idx.exclusions=idx.exclusions.filter(x=>!(x.chatId===chatId&&x.messageId===messageId));idx.exclusions.push({chatId,messageId,reason,at:stamp()});c.dayIndex=idx;c.updatedAt=stamp();await persist();renderDay();info('Đã đánh dấu loại khỏi canon, RAW vẫn nguyên.');};
 function renderTrace(){const q=ui('query').value,filter=ui('memory-day-filter').value,rows=dayRows(null,true);traced=RPGMBDay.search(rows,q,{dayId:filter||null,limit:30});const out=ui('trace-results');out.replaceChildren();
  for(const r of traced){const d=document.createElement('div');d.className='result';const heading=document.createElement('div');heading.className='meta';heading.textContent=`${r.dayId?campaigns[current()].dayIndex.items[r.dayId]?.label:'CHƯA GÁN DAY'} • ${r.chatTitle} (${r.chatId}) #${r.ordinal} • ${r.role} • ${r.messageId}`;const tags=document.createElement('div');tags.className='hint';tags.textContent=r.tags.join(' · ')+(r.excluded?' · LOẠI KHỎI CANON':'');const body=document.createElement('div');body.className='excerpt';body.textContent=r.text.slice(0,1100);d.append(heading,tags,body);out.append(d)}info(`Tìm nguồn: ${traced.length} kết quả theo từ khóa. Không thay thế xác minh canon.`);
 }
 ui('memory-trace').onclick=renderTrace;
 ui('memory-pack').onclick=()=>{const c=campaigns[current()];if(!c)return info('Chưa có Campaign');renderTrace();copy(RPGMBDay.memoryPack(c,traced,ui('query').value));};
 window.renderDay=renderDay;
 window.onDayViewOpen=()=>{renderDay();if(ui('day-suggestions').children.length===0)ui('day-detect').click();};
})();
