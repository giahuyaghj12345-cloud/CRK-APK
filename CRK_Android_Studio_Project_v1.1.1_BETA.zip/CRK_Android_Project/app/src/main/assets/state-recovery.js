// RPG RAW Keeper v1.0.10 · read-only recovery of provisional GM status bubbles.
// Work only on the evidence-scoped, in-memory view. Never mutate source
// observations, same-text PLAYER turns, stored branch choices or Cloud.
(function(root){
'use strict';
const norm=s=>String(s||'').replace(/\r\n?/g,'\n').replace(/\u00a0/g,' ').trim();
function progress(o){
 const t=norm(o?.text);
 return o?.role==='assistant'&&t.length>=40&&t.length<=1100&&
  /(?:^|[\s\n])(?:tôi sẽ|mình sẽ|tôi đang|đang xử lý|đang cân nhắc|đang định hình|đang hoàn tất|đã xác định|xác định bước|đẩy nhanh|hoàn tất xác minh|đang kiểm tra|xây dựng diễn biến|sẽ tiếp tục|sẽ lựa chọn)/iu.test(t);
}
function recover(chat){
 if(!chat||!Array.isArray(chat.viewportEvidence)||!Array.isArray(chat.provisionalOccurrences))return chat;
 const originals=chat.provisionalOccurrences;
 const byId=new Map(originals.filter(o=>o?.observationId).map(o=>[o.observationId,o]));
 const frames=chat.viewportEvidence.filter(f=>Array.isArray(f.turns)&&
   f.turns.every(t=>byId.has(t.observationId)));
 if(!frames.length)return chat;
 // The same PLAYER observation ID is our positional anchor. Never match on a
 // short text like "1", "3", or "4" (which is valid at many RPG turns).
 const perUser=new Map();
 for(const f of frames){
  let userId=null;
  for(const t of f.turns){
   const o=byId.get(t.observationId);if(!o)continue;
   if(o.role==='user')userId=o.observationId;
   else if(userId&&o.role==='assistant'){
    if(!perUser.has(userId))perUser.set(userId,{statuses:new Set(),finals:new Set()});
    const group=perUser.get(userId);
    if(progress(o))group.statuses.add(o.observationId);
    else if(norm(o.text).length>=1200)group.finals.add(o.observationId);
   }
  }
 }
 const statuses=new Set();
 for(const group of perUser.values())if(group.finals.size)
  for(const id of group.statuses)statuses.add(id);
 if(!statuses.size)return chat;
 const rewritten=frames.map(f=>({...f,turns:f.turns.filter(t=>!statuses.has(t.observationId))}))
  .filter(f=>f.turns.length);
 const activeIds=new Set(rewritten.flatMap(f=>f.turns.map(t=>t.observationId)));
 const retained=originals.filter(o=>activeIds.has(o.observationId)&&!statuses.has(o.observationId));
 return {...chat,provisionalOccurrences:retained,viewportEvidence:rewritten,
  stateRecovery:{originalObservationCount:originals.length,originalFrameCount:frames.length,
   statusObservationsSuppressed:statuses.size,source:'derived-read-only-view',nativeIdentityVerified:false}};
}
root.RPGMBStateRecovery={recover};
})(typeof globalThis!=='undefined'?globalThis:this);
