// RPGMB v0.9.5 Auto Day. Pure, deterministic, opt-in logic.
// The service worker invokes it on locally VERIFIED RAW writes; it never edits RAW.
(function(root){
 'use strict';
 const d=root.RPGMBDay;
 const plain=x=>JSON.parse(JSON.stringify(x));
 function autoOf(index){const a=index?.auto;return a&&typeof a==='object'&&!Array.isArray(a)&&a.enabled===true&&typeof a.activeDayId==='string'&&index.items[a.activeDayId]?a:null;}
 function arm(index,dayId,chats,assignment,campaignId,autoAdvance=false){
  if(!index?.items?.[dayId])throw Error('Day không tồn tại');
  const cursors={};
  for(const chat of chats){if(assignment[chat.chatId]!==campaignId)continue;
   const ms=root.RPGLedger.ledger(chat).messages;
   // Everything already observed is historical: enabling Auto Day does NOT backfill it.
   if(ms.length)cursors[chat.chatId]=ms[ms.length-1].id;
  }
  index.auto={enabled:true,activeDayId:dayId,autoAdvance:!!autoAdvance,cursors,armedAt:new Date().toISOString(),note:'Only verified RAW observed after arming will be added; new chat requires explicit campaign assignment.'};
  return index.auto;
 }
 function disarm(index){if(index?.auto)index.auto.enabled=false;}
 function dayHeading(message){
  // Only a GM heading at the FIRST line; a historical reference within prose does not count.
  if(message?.role!=='assistant')return null;
  const first=String(message.text||'').trimStart().split(/\r?\n/,1)[0].trim();
  const m=first.match(/^(?:#{1,3}\s*)?(?:DAY|NGÀY)\s+#?(\d{1,4})(?:\s*[|:–-]\s*[\p{L}\p{N}\s.'(),-]{1,70})?$/iu);
  return m?'Day '+Number(m[1]):null;
 }
 function appendRange(idx,dayId,chatId,start,end,messages,report){
  if(end<start)return;
  // One chat/position belongs to at most one Day. Manual assignments win.
  let s=-1,last=-1;
  const flush=()=>{
   if(s<0)return;
   const existing=idx.ranges.find(r=>r.chatId===chatId&&r.dayId===dayId&&r.end===s-1&&r.endId===messages[s-2]?.id);
   if(existing){existing.end=last;existing.endId=messages[last-1].id;}
   else d.addRange(idx,dayId,chatId,s,last,messages[s-1].id,messages[last-1].id);
   report.added+=last-s+1;s=-1;last=-1;
  };
  for(let i=start;i<=end;i++){
   const taken=d.lookup(idx,chatId,i,messages);
   if(taken){flush();report.skipped++;continue;}
   if(s<0)s=i;last=i;
  }
  flush();
 }
 function apply(campaign,campaignId,chat,assignment){
  // Return a cloned updated campaign only if a meaningful change was found.
  const index=d.get(campaign),auto=autoOf(index),report={changed:false,added:0,skipped:0,createdDays:[],error:null};
  if(!auto||assignment[chat?.chatId]!==campaignId)return {campaign:null,report};
  const messages=root.RPGLedger.ledger(chat).messages;
  if(!messages.length)return {campaign:null,report};
  const id=chat.chatId,previous=auto.cursors?.[id];
  const prevPosition=previous?messages.findIndex(m=>m.id===previous):-1;
  if(previous&&prevPosition<0){report.error='Auto Day dừng: UUID mốc RAW của chat không còn trong ledger; cần kiểm tra thủ công.';return {campaign:null,report};}
  const start=prevPosition+1;
  if(start>=messages.length)return {campaign:null,report};
  const updated=plain(campaign),idx=d.get(updated),a=idx.auto;
  let active=a.activeDayId,from=start+1;
  for(let i=start;i<messages.length;i++){
   const heading=a.autoAdvance?dayHeading(messages[i]):null;
   if(heading){
    const currentLabel=idx.items[active]?.label||'';
    // Ignore an identical day heading. Never treat a heading below top line as transition.
    const oldDay=/^(?:(?:Day|Ngày)\s+)?(\d{1,4})(?=\b|\s|[·.:|-]|$)/i.exec(currentLabel);
    const newDay=/^Day\s+(\d+)/.exec(heading);
    if(!oldDay||Number(oldDay[1])!==Number(newDay[1])){
     appendRange(idx,active,id,from,i,messages,report);
     let next=Object.values(idx.items).find(x=>x.label.toLowerCase()===heading.toLowerCase());
     if(!next){const newId=d.create(idx,heading);next=idx.items[newId];report.createdDays.push(heading);}
     // Do not silently reopen an intentionally CLOSED day.
     if(next.status!=='OPEN'){report.error='Tìm thấy tiêu đề '+heading+' nhưng Day đã đóng; cần PLAYER kiểm tra.';return {campaign:null,report};}
     active=next.id;from=i+1;
    }
   }
  }
  appendRange(idx,active,id,from,messages.length,messages,report);
  a.activeDayId=active;a.cursors??={};a.cursors[id]=messages[messages.length-1].id;
  updated.dayIndex=idx;updated.updatedAt=new Date().toISOString();report.changed=true;
  if(!d.validIndex(idx))return {campaign:null,report:{...report,changed:false,error:'Day index không hợp lệ hoặc vượt giới hạn; không lưu thay đổi.'}};
  return {campaign:updated,report};
 }
 root.RPGMBAutoDay={arm,disarm,autoOf,dayHeading,apply};
})(typeof globalThis==='undefined'?self:globalThis);
