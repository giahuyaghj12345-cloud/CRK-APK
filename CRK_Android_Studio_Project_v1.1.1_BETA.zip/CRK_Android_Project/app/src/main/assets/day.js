// RPG Memory Bridge 0.9.4 - Day index, traceable retrieval and cautious rule hints.
// The engine NEVER rewrites captured RAW, declares canon or infers NPC knowledge.
(function(root){
 'use strict';
 const safeId = s=>typeof s==='string'&&/^[a-zA-Z0-9_-]{1,180}$/.test(s);
 const native = s=>/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(String(s||''));
 const empty=()=>({items:{},ranges:[],exclusions:[],links:[]});
 function validIndex(idx){
  if(!idx||typeof idx!=='object'||Array.isArray(idx)||!idx.items||typeof idx.items!=='object'||Array.isArray(idx.items)||!Array.isArray(idx.ranges)||!Array.isArray(idx.exclusions))return false;
  if(Object.keys(idx.items).length>500||idx.ranges.length>10000||idx.exclusions.length>10000||(idx.links&&(!Array.isArray(idx.links)||idx.links.length>10000)))return false;
  if(JSON.stringify(idx).length>750000)return false;
  for(const [id,d] of Object.entries(idx.items))if(!safeId(id)||!d||d.id!==id||typeof d.label!=='string'||d.label.length>140||!['OPEN','CLOSED','REVISED'].includes(d.status))return false;
  for(const r of idx.ranges)if(!r||!safeId(r.id)||!idx.items[r.dayId]||!native(r.chatId)||!Number.isSafeInteger(r.start)||r.start<1||!Number.isSafeInteger(r.end)||r.end<r.start||r.end>1000000||(r.startId&&!native(r.startId))||(r.endId&&!native(r.endId)))return false;
  for(const x of idx.exclusions)if(!x||!native(x.chatId)||!native(x.messageId)||typeof x.reason!=='string'||x.reason.length>500)return false;
  for(const x of (idx.links||[]))if(!x||!idx.items[x.dayId]||!native(x.chatId)||!native(x.messageId)||typeof x.reason!=='string'||x.reason.length>500)return false;
  return true;
 }
 const get=campaign=>campaign?.dayIndex&&validIndex(campaign.dayIndex)?campaign.dayIndex:empty();
 const norm=s=>String(s||'').normalize('NFC').toLocaleLowerCase('vi-VN');
 function create(idx,label){
  const name=String(label||'').trim();if(!name||name.length>140)throw Error('Tên Day phải từ 1 đến 140 ký tự.');
  if(Object.values(idx.items).some(x=>norm(x.label)===norm(name)))throw Error('Day này đã tồn tại.');
  const id='day-'+Date.now().toString(36)+'-'+Math.random().toString(36).slice(2,8);
  idx.items[id]={id,label:name,status:'OPEN',createdAt:new Date().toISOString()};return id;
 }
 function addRange(idx,dayId,chatId,start,end,startId=null,endId=null){
  start=Number(start);end=Number(end);
  if(!idx.items[dayId]||!native(chatId)||!Number.isSafeInteger(start)||!Number.isSafeInteger(end)||start<1||end<start||end>1000000)throw Error('Khoảng lượt không hợp lệ.');
  if(idx.ranges.some(r=>r.chatId===chatId&&r.start<=end&&start<=r.end))throw Error('Các lượt này đã thuộc một khoảng Day khác. Gỡ khoảng cũ trước khi gán lại.');
  if((startId&&!native(startId))||(endId&&!native(endId)))throw Error('UUID mốc Day không hợp lệ.');
  const r={id:'range-'+Date.now().toString(36)+'-'+Math.random().toString(36).slice(2,8),dayId,chatId,start,end,...(startId&&endId?{startId,endId}:{}),at:new Date().toISOString()};idx.ranges.push(r);return r;
 }
 function lookup(idx,chatId,ordinal,messages=null){return idx.ranges.find(r=>{
   if(r.chatId!==chatId)return false;
   if(r.startId&&r.endId&&Array.isArray(messages)){
    const a=messages.findIndex(m=>m.id===r.startId),b=messages.findIndex(m=>m.id===r.endId);
    // A missing anchor is NOT permission to reassign a Day by stale index.
    return a>=0&&b>=a&&ordinal>=a+1&&ordinal<=b+1;
   }
   return r.start<=ordinal&&ordinal<=r.end;
  })?.dayId||null;}
 function scopedRows(chats,assign,campaignId,idx,dayId=null,includeUnassigned=false,branchIndex=null,sourceEvents=null){
  const rows=[];
  for(const chat of chats){if(assign[chat.chatId]!==campaignId||branchIndex?.links?.some(l=>l.childChatId===chat.chatId&&l.mode==='checkpoint'))continue;
   const messages=root.RPGLedger.ledger(chat).messages;
   messages.forEach((m,i)=>{const day=lookup(idx,chat.chatId,i+1,messages);const links=(idx.links||[]).filter(x=>x.chatId===chat.chatId&&x.messageId===m.id).map(x=>x.dayId);if(dayId&&day!==dayId&&!links.includes(dayId))return;if(!day&&!includeUnassigned&&!dayId)return;
    rows.push({chatId:chat.chatId,chatTitle:chat.title||chat.chatId,ordinal:i+1,dayId:day,linkedDayIds:links,messageId:m.id,role:m.role,text:m.text,updatedAt:m.updatedAt||'',revisions:m.revisions||[],excluded:idx.exclusions.some(x=>x.chatId===chat.chatId&&x.messageId===m.id)||Boolean(root.RPGMBSourceEvents?.excludedFromRecall(sourceEvents,chat.chatId,m.id)),sourceEvent:root.RPGMBSourceEvents?.current(sourceEvents,chat.chatId,m.id)||null});
   });
  }
  return rows;
 }
 function hints(text){
  const lines=String(text||'').slice(0,550).split(/\r?\n/).slice(0,5);
  const results=[];for(const line of lines){
   const m=line.trim().match(/^(?:#{1,4}\s*)?(?:\[|【)?(?:day|ngày)\s*(?:#|:|-)?\s*(\d{1,4})(?:\s*\]|\s*】)?(?:\s|$|[.,:|–-])/i);
   if(m)results.push({label:'Day '+Number(m[1]),reason:'Có tiêu đề Day trong RAW (chưa xác minh mốc thời gian)'});
  }return results;
 }
 function suggest(chats,assign,campaignId){
  const found=[];for(const c of chats){if(assign[c.chatId]!==campaignId)continue;
   for(const [i,m] of root.RPGLedger.ledger(c).messages.entries())for(const h of hints(m.text))found.push({...h,chatId:c.chatId,ordinal:i+1,sourceId:m.id,role:m.role});
  }return found.slice(0,100);
 }
 function classify(text){
  const s=String(text||'');const tag=[];
  if(/\[(?:HỒ SƠ NGẦM NPC|GM ONLY|SECRET|HIDDEN)\]|\bGM ONLY\b/i.test(s))tag.push('GM_ONLY');
  if(/(?:^|\n)\s*(?:GM\s*:\s*)?(?:correction|retcon|đính chính|sửa lại|chốt lại|canon correction)\b/i.test(s))tag.push('POSSIBLE_CORRECTION');
  if(/\b(?:mana|cooldown|damage|skill|class|khả năng|kỹ năng|tiêu hao|giới hạn)\b/i.test(s))tag.push('POSSIBLE_GAME_RULE');
  if(/\b(?:vương quốc|lục địa|gia tộc|học viện|house|kingdom|world building)\b/i.test(s))tag.push('POSSIBLE_WORLD_BUILDING');
  if(/\b(?:npc|quan hệ|động cơ|ngoại hình|tính cách)\b/i.test(s))tag.push('POSSIBLE_NPC');
  return tag.length?tag:['STORY_OR_UNCLASSIFIED'];
 }
 function terms(text){return [...new Set(norm(text).match(/[\p{L}\p{N}]{2,}/gu)||[])].filter(x=>!['và','cho','các','the','tôi','với','của','một','những','không','trong','được','this'].includes(x));}
 function search(rows,q,{dayId=null,limit=30}={}){
  const keywords=terms(q);if(!keywords.length)return [];
  return rows.filter(r=>!dayId||r.dayId===dayId||r.linkedDayIds?.includes(dayId)).map(r=>{
   const hay=norm(r.text),words=new Set(terms(r.text));let matches=0;
   for(const w of keywords)if(words.has(w)||hay.includes(w))matches++;
   const all=keywords.every(w=>hay.includes(w));let score=matches*10+(all?15:0)+(r.excluded?-100:0);return {...r,score,tags:classify(r.text)};
  }).filter(r=>r.score>0).sort((a,b)=>b.score-a.score||a.chatId.localeCompare(b.chatId)||a.ordinal-b.ordinal).slice(0,limit);
 }
 function memoryPack(campaign,rows,query){
  const out=[`[RPG TRACEABLE MEMORY | ${campaign?.name||'Campaign'}]`,`QUERY: ${query}`,`CẢNH BÁO: Kết quả tìm theo từ khóa, KHÔNG xác nhận canon. Đọc nguồn và correction trước khi dùng. GM_ONLY không tự trở thành kiến thức của PC.`];
  for(const r of rows){out.push(`\n[DAY ${r.dayId?campaign.dayIndex.items[r.dayId]?.label:'CHƯA GÁN'} | CHAT ${r.chatId} | SOURCE ${r.messageId} | #${r.ordinal} | ${r.role} | ${r.tags.join(', ')}${r.excluded?' | EXCLUDED_FROM_CANON':''}${r.linkedDayIds?.length?' | CORRECTION_LINKED_TO:'+r.linkedDayIds.join(','):''}]`);out.push(r.text.slice(0,5000));}
  out.push('[END RPG MEMORY]');return out.join('\n');
 }

 function fullDayRaw(campaign,campaignId,chats,assign,dayId){
  const idx=get(campaign),day=idx.items[dayId];if(!day)throw Error('Chưa chọn Day hợp lệ.');
  const out=[`[FULL DAY RAW | ${campaign.name||''} | ${day.label} | ${day.status}]`,
   'SOURCE EVIDENCE: Chỉ những lượt đã được capture và xác minh UUID. Không bảo đảm lịch sử ChatGPT đầy đủ; cần kiểm tra các continuation thiếu. Thứ tự các đoạn theo thứ tự PLAYER đã gán, không mặc định là đồng hồ RPG.'];
  const included=new Set(),versions=[];
  for(const range of idx.ranges.filter(r=>r.dayId===dayId)){
   const chat=chats.find(c=>c.chatId===range.chatId&&assign[c.chatId]===campaignId);
   if(!chat){out.push(`
[MISSING CHAT ${range.chatId}; KHÔNG ĐƯỢC SUY ĐOÁN]`);continue;}
   const messages=root.RPGLedger.ledger(chat).messages;
   const a=range.startId?messages.findIndex(m=>m.id===range.startId):range.start-1;
   const b=range.endId?messages.findIndex(m=>m.id===range.endId):range.end-1;
   if(a<0||b<a){out.push(`
[MISSING UUID ANCHOR CHAT ${range.chatId} ${range.startId||''}..${range.endId||''}; KHÔNG GÁN BẰNG SỐ LƯỢT CŨ]`);continue;}
   out.push(`
[SEGMENT | CHAT ${range.chatId} | #${a+1}–#${b+1}]`);
   for(let i=a;i<=b;i++){
    const m=messages[i],unique=chat.chatId+'|'+m.id;if(included.has(unique))continue;included.add(unique);
    const excluded=idx.exclusions.some(x=>x.chatId===chat.chatId&&x.messageId===m.id);
    const sourceEvent=root.RPGMBSourceEvents?.current(campaign.sourceEvents,chat.chatId,m.id)||null;
    out.push(`
[${m.role.toUpperCase()} | SOURCE ${chat.chatId} #${i+1} | UUID ${m.id}${excluded?' | EXCLUDED_FROM_CANON':''}${sourceEvent?' | PLAYER_REPORTED:'+sourceEvent.kind:''}]
${m.text}`);
    if(m.revisions?.length)versions.push({chatId:chat.chatId,sourceId:m.id,versions:m.revisions});
   }
  }
  const refs=(idx.links||[]).filter(x=>x.dayId===dayId);
  if(refs.length)out.push('\n[CROSS-DAY CORRECTION REFERENCES; không tự ghi đè canon]');
  for(const ref of refs){const chat=chats.find(c=>c.chatId===ref.chatId&&assign[c.chatId]===campaignId),m=chat&&root.RPGLedger.ledger(chat).messages.find(x=>x.id===ref.messageId);
   out.push(m?`
[REFERENCE | CHAT ${ref.chatId} | UUID ${ref.messageId} | ${m.role} | ${ref.reason}]
${m.text}`:`
[MISSING CORRECTION REFERENCE ${ref.chatId} ${ref.messageId}]`);
  }
  if(versions.length){out.push('\n[OLDER OBSERVED VERSIONS: may include streaming text, not confirmed edits]');for(const v of versions)for(const r of v.versions)out.push(`[CHAT ${v.chatId} | UUID ${v.sourceId} | ${r.at||'unknown'}] ${r.reason||'content changed'}
${r.text}`);}
  out.push('\n[END FULL DAY RAW]');return out.join('\n');
 }

 root.RPGMBDay={safeId,native,empty,validIndex,get,create,addRange,lookup,scopedRows,hints,suggest,classify,terms,search,memoryPack,fullDayRaw};
})(typeof globalThis==='undefined'?self:globalThis);
