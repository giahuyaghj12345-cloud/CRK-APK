/* Android bridge for the original CRK extension APIs.
 * Only bundled pages get the full bridge; ChatGPT receives a storage-limited one. */
(() => {
 'use strict';
 if (window.__crkBridgeLoaded) return;
 window.__crkBridgeLoaded = true;
 const native = window.AndroidCRK;
 if (!native) return;
 const handlers = {storage:[], alarm:[], message:[], installed:[], startup:[]};
 const pending = new Map();
 let seq = 0;
 const decode = s => { try { return JSON.parse(s); } catch (_) { return null; } };
 const req = (kind, msg, callback) => {
   const id = 'r' + Date.now() + '_' + (++seq);
   const promise = new Promise((resolve, reject) => {
     pending.set(id, {resolve, reject});
     try { native.message(kind, JSON.stringify(msg), id); }
     catch(e) { pending.delete(id); reject(e); }
   });
   if (typeof callback === 'function') {
     promise.then(x => callback(x), e => callback({ok:false,error:String(e)}));
     return;
   }
   return promise;
 };
 window.__crkResult = (id, encoded) => {
   const cb = pending.get(id); if (!cb) return;
   pending.delete(id);
   cb.resolve(decode(encoded));
 };
 window.__crkReceive = (encoded, id) => {
   const msg = decode(encoded);
   let sent = false;
   const reply = result => {
     if (sent) return;
     sent = true;
     native.reply(id, JSON.stringify(result));
   };
   if (!handlers.message.length) { reply({ok:false,error:'CRK receiver not ready'}); return; }
   try {
     for (const fn of handlers.message) {
       const result = fn(msg, {tab:{id:1}}, reply);
       if (result && typeof result.then === 'function') result.then(reply,e=>reply({ok:false,error:String(e)}));
     }
   } catch(e) {reply({ok:false,error:String(e)});}
 };
 window.__crkStorageChanged = encoded => {
   const changes = decode(encoded);
   if (changes) for (const fn of handlers.storage) try {fn(changes, 'local');} catch(e) {console.error(e);}
 };
 window.__crkFireAlarm = name => {
   for (const fn of handlers.alarm) try {fn({name});} catch(e) {console.error(e);}
 };
 const store = {
   get: async keys => decode(native.getStore(JSON.stringify(keys===undefined?null:keys))) || {},
   set: async values => { native.setStore(JSON.stringify(values)); },
   remove: async keys => { native.removeStore(JSON.stringify(keys)); },
   clear: async () => { native.clearStore(); }
 };
 const polyfill = {
   storage: {local:store,onChanged:{addListener:fn=>handlers.storage.push(fn)}},
   runtime: {
     getManifest: () => ({version:'1.1.1',name:'CRK Campaign RAW Keeper Android'}),
     sendMessage: (msg,callback) => req('cloud',msg,callback),
     onMessage: {addListener:fn=>handlers.message.push(fn)},
     onInstalled: {addListener:fn=>{handlers.installed.push(fn);setTimeout(fn,100);}},
     onStartup: {addListener:fn=>{handlers.startup.push(fn);setTimeout(fn,100);}},
     lastError: null
   },
   tabs: {
     query: async () => {const tab=decode(native.getActiveTab());return tab?[tab]:[];},
     sendMessage: (tabId,msg) => req('content',msg)
   },
   permissions: {request: async req => {
     const origins = req?.origins || [];
     return origins.length>0 && origins.every(x=>/^https:\/\/[a-z0-9-]+\.supabase\.co\/\*$/i.test(x));
   }},
   alarms: {
     create: (name,opts) => native.setAlarm(name,JSON.stringify(opts||{})),
     get: async name => decode(native.getAlarm(name)),
     clear: async name => native.clearAlarm(name),
     onAlarm: {addListener:fn=>handlers.alarm.push(fn)}
   }
 };
 window.chrome = Object.assign(window.chrome || {}, polyfill);
 // Download Blob exports from original popup by routing them through Android MediaStore.
 if (location.hostname === 'appassets.androidplatform.net' && !location.pathname.includes('cloud-host')) {
   const click = HTMLAnchorElement.prototype.click;
   HTMLAnchorElement.prototype.click = function() {
     if (String(this.href).startsWith('blob:') && this.download) {
       const name = this.download;
       fetch(this.href).then(r=>r.blob()).then(blob=>new Promise((resolve,reject)=>{
         const rd = new FileReader();
         rd.onload=()=>resolve(String(rd.result).split(',')[1]);
         rd.onerror=()=>reject(rd.error);
         rd.readAsDataURL(blob);
       })).then(data=>native.saveFile(name, data))
         .catch(e=>console.error('CRK export failed',e));
       return;
     }
     return click.call(this);
   };
 }
 // Some Android WebViews do not grant clipboard permissions to local assets.
 try {
   if (!navigator.clipboard || !navigator.clipboard.writeText) {
     Object.defineProperty(navigator,'clipboard',{configurable:true,value:{writeText:async text=>native.copyText(String(text))}});
   }
 } catch(_) {}
})();
