// v0.9.26 · Campaign provenance for individual RAW observations.
// Assignment alone does not prove ownership of historical evidence.
// A message/observation/frame with no campaignId stays in a separate,
// non-counted legacy pool; nothing is silently deleted or re-attributed.
(function(root){
 'use strict';
 const validId=x=>typeof x==='string'&&/^[\w-]{1,180}$/.test(x)&&!['__proto__','prototype','constructor'].includes(x);
 const same=(x,id)=>validId(id)&&x?.campaignId===id;
 function scope(chat,id){
  if(!chat||!validId(id))return null;
  const included=new Set((chat.provisionalOccurrences||[]).filter(x=>same(x,id)).map(x=>x.observationId));
  const native=(chat.messages||[]).filter(x=>same(x,id));
  const frames=(chat.viewportEvidence||[]).filter(f=>same(f,id) &&
    Array.isArray(f.turns)&&f.turns.every(t=>t.nativeId||included.has(t.observationId)));
  const scoped={...chat,campaignScopeId:id,
   messages:native,provisionalOccurrences:(chat.provisionalOccurrences||[]).filter(x=>same(x,id)),
   viewportEvidence:frames,
   // Before per-RAW provenance existed these had no provable owner.
   provisionalObservations:[],legacyMessages:[],
   identityConflicts:(chat.identityConflicts||[]).filter(x=>same(x,id))};
  const idset=new Set(scoped.provisionalOccurrences.map(o=>o.observationId));
  const review=chat.reviewedPath;
  if(!review||!Array.isArray(review.ids)||!review.ids.length||!review.ids.every(x=>idset.has(x)))delete scoped.reviewedPath;
  scoped.reviewedPathHistory=(chat.reviewedPathHistory||[]).filter(r=>Array.isArray(r.ids)&&r.ids.every(x=>idset.has(x)));
  const identityView=root.RPGMBIdentityRecovery ? root.RPGMBIdentityRecovery.recover(scoped) : scoped;
  return root.RPGMBStateRecovery ? root.RPGMBStateRecovery.recover(identityView) : identityView;
 }
 function audit(chat,id){
  const occurrences=chat?.provisionalOccurrences||[],frames=chat?.viewportEvidence||[],native=chat?.messages||[];
  const count=x=>x.filter(t=>same(t,id)).length;
  return {assignedObservations:count(occurrences),assignedFrames:count(frames),assignedNative:count(native),
   unattributedObservations:occurrences.filter(x=>!validId(x?.campaignId)).length,
   otherCampaignObservations:occurrences.filter(x=>validId(x?.campaignId)&&x.campaignId!==id).length,
   unattributedFrames:frames.filter(x=>!validId(x?.campaignId)).length,
   otherCampaignFrames:frames.filter(x=>validId(x?.campaignId)&&x.campaignId!==id).length,
   unattributedNative:native.filter(x=>!validId(x?.campaignId)).length,
   legacyRaw:(chat?.legacyMessages||[]).length+(chat?.provisionalObservations||[]).length,
   otherCampaignNative:native.filter(x=>validId(x?.campaignId)&&x.campaignId!==id).length};
 }
 root.RPGMBCampaignScope={validId,scope,audit};
})(typeof globalThis==='undefined'?self:globalThis);
