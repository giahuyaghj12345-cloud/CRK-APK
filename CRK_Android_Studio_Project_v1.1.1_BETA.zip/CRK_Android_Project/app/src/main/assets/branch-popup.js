// Branch registration is opt-in. Opening Save never creates a branch or changes RAW.
(function(){
 'use strict';
 const ui=id=>document.getElementById(id);
 let confirmation='';
 function options(el,items,old){el.replaceChildren();const placeholder=document.createElement('option');placeholder.value='';placeholder.textContent='-- Chọn hội thoại --';el.append(placeholder);
  for(const [id,title] of items){const opt=document.createElement('option');opt.value=id;opt.textContent=title;el.append(opt);}el.value=items.some(x=>x[0]===old)?old:'';
 }
 function renderBranch(){const camp=campaigns[current()],links=camp?.branchIndex?.links||[];
  const p=ui('branch-parent'),ch=ui('branch-child'),a=p.value,b=ch.value;
  options(p,chats.filter(x=>assign[x.chatId]===current()&&!RPGMBBranch.isCheckpoint(camp,x.chatId)).map(x=>[x.chatId,x.title||x.chatId]),a);
  options(ch,chats.filter(x=>!assign[x.chatId]||assign[x.chatId]===current()).map(x=>[x.chatId,`${x.title||x.chatId}${assign[x.chatId]===current()?' ✓':''}`]),b);
  const out=ui('branch-list');out.replaceChildren();for(const link of links){const row=document.createElement('div');row.className='day-entry';row.textContent=`${link.mode==='checkpoint'?'📌 Checkpoint':'🌿 Alternative'}: ${chats.find(c=>c.chatId===link.childChatId)?.title||link.childChatId} ← ${chats.find(c=>c.chatId===link.parentChatId)?.title||link.parentChatId}\n${link.evidence} · UUID chung: ${link.sharedCount} · trùng text quan sát: ${link.textOnlyCount??"chưa lưu"}`;out.append(row);}
 }
 ui('branch-check').onclick=()=>{const p=chats.find(c=>c.chatId===ui('branch-parent').value),ch=chats.find(c=>c.chatId===ui('branch-child').value);
  if(!p||!ch)return ui('branch-report').textContent='Chọn chat gốc và nhánh để phân tích.';
  const a=RPGMBBranch.analyze(p,ch);ui('branch-report').textContent=`${a.evidence}\nUUID chung: ${a.sharedCount}; tiền tố giống text: ${a.textOnlyCount}.\nKhung DOM hợp lệ: gốc ${a.parentFrameCount}, nhánh ${a.childFrameCount}; lượt lớn nhất thấy: ${a.parentViewportObserved} / ${a.childViewportObserved}.\n${a.note}\nChỉ là tương đồng của DOM đã quan sát, KHÔNG chứng minh cùng UUID, quan hệ nhân quả hoặc điểm fork.`;confirmation='';
 };
 ui('branch-save').onclick=async()=>{const cid=current(),camp=campaigns[cid],parent=chats.find(c=>c.chatId===ui('branch-parent').value),child=chats.find(c=>c.chatId===ui('branch-child').value);
  if(!camp||!parent||!child)return ui('branch-report').textContent='Chọn Campaign, chat gốc và nhánh.';
  if(assign[parent.chatId]!==cid||assign[child.chatId]&&assign[child.chatId]!==cid)return ui('branch-report').textContent='Nhánh hoặc chat gốc đang thuộc Campaign khác; không tự chuyển.';
  try{
   const analysis=RPGMBBranch.analyze(parent,child),fingerprint=[cid,parent.chatId,child.chatId,ui('branch-mode').value,analysis.evidence].join('|');
   if(confirmation!==fingerprint){confirmation=fingerprint;ui('branch-report').textContent=`⚠️ XÁC NHẬN: nhánh ${analysis.evidence}, ${analysis.sharedCount} UUID chung. Bấm lần hai để ghi quan hệ. Không tự đồng nhất các tin có text giống nhau. RAW gốc không đổi.`;return;}
   const branch=RPGMBBranch.register(camp.branchIndex||{links:[]},parent,child,ui('branch-mode').value);
   camp.branchIndex=branch.index;camp.updatedAt=stamp();assign[child.chatId]=cid;await persist();confirmation='';render();renderBranch();if(window.renderDay)window.renderDay();
   ui('branch-report').textContent=`✅ Đã liên kết ${branch.record.mode} (${branch.record.evidence}). Nhánh checkpoint không vào Auto Day hoặc Recall; bản RAW vẫn lưu riêng.`;
  }catch(err){ui('branch-report').textContent='Không thể liên kết: '+err.message;}
 };
 for(const id of ['branch-parent','branch-child','branch-mode'])ui(id).addEventListener('change',()=>{confirmation='';});
 window.renderBranch=renderBranch;
 setTimeout(renderBranch,0);
})();
