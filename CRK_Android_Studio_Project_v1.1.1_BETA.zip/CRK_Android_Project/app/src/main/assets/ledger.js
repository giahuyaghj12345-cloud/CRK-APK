// Canonical RAW is a non-destructive materialized VIEW. Historical snapshots stay untouched.
(function(root){
const norm=s=>String(s||'').replace(/\r\n?/g,'\n').replace(/\u00a0/g,' ').trim();
const flat=s=>norm(s).replace(/\s+/g,'');
const ephemeral=s=>/^(?:đang suy nghĩ|thinking\.{0,3}|analyzing\.{0,3}|generating\.{0,3})$/i.test(norm(s));
const nativeId=s=>typeof s==='string'&&/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(s);
const strength=m=>(m.identityVerified&&m.identityProof==='same-turn-native-id-role-v081'?100000:0)+(norm(m.text).includes('\n')?1000:0)+norm(m.text).length;
function build(snapshots){
 const candidates=new Map(), rejected=new Set(), sequences=[], legacy=[], suspect=[];
 for(const snapshot of snapshots){
  const msgs=Array.isArray(snapshot?.messages)?snapshot.messages:[];
  const seq=[];
  for(const m of msgs){
   if(!m||!['user','assistant'].includes(m.role)||typeof m.text!=='string')continue;
   if(ephemeral(m.text)){suspect.push({reason:'streaming_placeholder',id:m.id||null});continue;}
   if(!nativeId(m.id)){legacy.push(m);continue;}
   // Legacy `verified:true` from earlier DOM parsers is not an identity proof.
   if(m.identityVerified!==true||m.identityProof!=='same-turn-native-id-role-v081'){legacy.push(m);suspect.push({reason:'legacy_id_claim_unconfirmed',id:m.id});continue;}
   if(rejected.has(m.id))continue;
   const old=candidates.get(m.id);
   if(old){
     if(old.role!==m.role){candidates.delete(m.id);rejected.add(m.id);suspect.push({reason:'conflicting_proven_role',id:m.id});continue;}
     const mentions=(entry,text)=>(entry.revisions||[]).some(r=>norm(r.text)===norm(text));
     const nextIsDescendant=mentions(m,old.text),oldIsDescendant=mentions(old,m.text);
     const prefixExpansion=norm(m.text).startsWith(norm(old.text));
     const prefixRegression=norm(old.text).startsWith(norm(m.text));
     if(norm(old.text)!==norm(m.text)&&!nextIsDescendant&&!oldIsDescendant&&!prefixExpansion&&!prefixRegression){
       candidates.delete(m.id);rejected.add(m.id);suspect.push({reason:'unlinked_different_version_same_id',id:m.id});continue;
     }
     if(nextIsDescendant&&!oldIsDescendant){candidates.set(m.id,{...m,text:norm(m.text)});}
     else if(!oldIsDescendant && prefixExpansion && strength(m)>strength(old))candidates.set(m.id,{...m,text:norm(m.text)});
     else if(norm(old.text)===norm(m.text)&&strength(m)>strength(old))candidates.set(m.id,{...m,text:norm(m.text)});
   }else candidates.set(m.id,{...m,text:norm(m.text)});
   if(!seq.includes(m.id))seq.push(m.id);
  }
  if(seq.length)sequences.push(seq);
  for(const m of (snapshot?.legacyMessages||[]))legacy.push(m);
 }
 // Refuse historical parser artifacts that concatenated several assistant turns.
 const items=[...candidates.values()];
 for(const m of items.filter(x=>x.role==='assistant')){
  const body=flat(m.text);
  const contained=items.filter(x=>x.id!==m.id&&x.role==='assistant'&&flat(x.text).length>=25&&body.includes(flat(x.text)));
  if(contained.length>=2){candidates.delete(m.id);suspect.push({reason:'merged_assistant_turns',id:m.id});}
 }
 const valid=new Set(candidates.keys());
 // Each actual viewport scan provides reliable relative ordering, even when its
 // numeric turn index was recycled by ChatGPT mobile virtualization.
 const clean=sequences.map(s=>s.filter(id=>valid.has(id)));
 const ordered=[];const used=new Set();
 clean.sort((a,b)=>b.length-a.length);
 if(clean[0])for(const id of clean[0]){ordered.push(id);used.add(id);}
 for(const seq of clean){
  for(let i=0;i<seq.length;i++){
   const id=seq[i];if(used.has(id))continue;
   const left=seq.slice(0,i).reverse().find(x=>used.has(x));
   const right=seq.slice(i+1).find(x=>used.has(x));
   const l=left?ordered.indexOf(left):-1,r=right?ordered.indexOf(right):-1;
   if(l>=0&&(r<0||l<r))ordered.splice(l+1,0,id);
   else if(r>=0)ordered.splice(r,0,id);
   else ordered.push(id);
   used.add(id);
  }
 }
 const messages=ordered.map((id,index)=>({...candidates.get(id),canonicalIndex:index+1}));
 let orderingConflicts=0;
 for(const seq of clean)for(let i=1;i<seq.length;i++)if(ordered.indexOf(seq[i-1])>ordered.indexOf(seq[i]))orderingConflicts++;
 return {version:2,messages,legacyCount:legacy.length,suspect,orderingConflicts,
  integrity:{nativeIds:messages.length,snapshotCount:snapshots.length,orderMethod:'viewport-sequence-evidence',completeHistoryVerified:false,
   status:orderingConflicts?'REVIEW_ORDER':'PARTIAL_DOM_VERIFIED'}};
}
function ledger(chat){const r=build([chat]);return {messages:r.messages,unmatched:(chat.legacyMessages||[]),discarded:r.suspect.length};}
root.RPGLedger={ledger,build,norm,ephemeral,nativeId};
})(typeof globalThis!=='undefined'?globalThis:this);
