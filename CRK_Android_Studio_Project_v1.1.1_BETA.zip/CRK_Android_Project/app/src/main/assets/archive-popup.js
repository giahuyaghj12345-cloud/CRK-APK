// Local Drive-ready archive preview/export/verified import. No Google API calls.
(async()=>{
'use strict';
const $=id=>document.getElementById(id);
const panel=$('archive-report'),campaign=$('campaign');
const busy=b=>{for(const id of ['archive-preview','archive-export','archive-import'])$(id).disabled=b;};
async function plan(){const id=campaign.value;if(!id)throw Error('Chọn Campaign trong tab Save trước');const all=await chrome.storage.local.get(null);return RPGMBArchive.plan(all,id);}
$('archive-preview').onclick=async()=>{busy(true);try{
 const p=await plan();panel.textContent=`Campaign: ${p.campaignId}\nRAW UUID đã xác minh: ${p.counts.verified}\nDOM provisional chưa xác minh: ${p.counts.provisional}\nViewport frames: ${p.counts.frames}\nChunk dự tính (80 record/chunk): ${p.pendingChunks.length}\nDung lượng nén dữ liệu: ${p.pendingChunks.reduce((n,x)=>n+x.compressedBytes,0).toLocaleString()} B\nMetadata gzip: ${p.metadata.compressedBytes.toLocaleString()} B\nCảnh báo: ${p.warnings.length?p.warnings.join('; '):'Không có'}\nChỉ là dự tính; CHƯA upload Drive.`;
 }catch(e){panel.textContent='Không tạo được archive: '+e.message;}finally{busy(false);}};
$('archive-export').onclick=async()=>{busy(true);try{
 const p=await plan();const doc={format:'rpgmb-portable-campaign-archive-v2',metadata:p.metadata.doc,records:p.pendingChunks.flatMap(x=>x.doc.records),excludedWarnings:p.warnings};
 const out=await RPGMBArchive.encode(doc);
 // Full SHA in filename allows import to verify without trusting another field inside ZIP/JSON.
 const suffix=p.campaignId.replace(/[^a-zA-Z0-9_-]/g,'_').slice(0,75);
 const name=`RPGMB_${suffix}_${out.hash}.json.gz`;
 const url=URL.createObjectURL(new Blob([out.packed],{type:'application/gzip'}));
 const a=document.createElement('a');a.href=url;a.download=name;document.body.append(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),10000);
 panel.textContent=`Đã yêu cầu tải ${name}\nSHA-256 của JSON chưa nén: ${out.hash}\nKích thước gzip: ${out.compressedBytes.toLocaleString()} B\n${p.counts.verified} RAW có UUID + ${p.counts.provisional} DOM provisional + ${p.counts.frames} viewport frames.\nLegacy chưa đủ nguồn vẫn cần Xuất JSON đầy đủ.\nKHÔNG xóa RAW local hay Supabase.`;
 }catch(e){panel.textContent='Xuất archive thất bại: '+e.message;}finally{busy(false);}};
$('archive-import').onchange=async e=>{const file=e.target.files?.[0];if(!file)return;busy(true);
 try{
  if(file.size>RPGMBArchive.limits.maxCompressedBytes)throw Error('File gzip vượt giới hạn an toàn. Hãy tách archive thành chunk.');
  // The checksum must be known independently of the compressed JSON being decoded.
  const m=file.name.match(/_([0-9a-f]{64})\.json\.gz$/i);if(!m)throw Error('Tên archive thiếu SHA-256 đầy đủ. Không tự đoán checksum.');
  const doc=await RPGMBArchive.decode(new Uint8Array(await file.arrayBuffer()),m[1]);
  const existing=await chrome.storage.local.get(null);const prepared=RPGMBArchive.restorePlan(doc,existing,RPGMBSafe);
  // Write only changed keys. Reimporting the same archive must not update
  // timestamps or trigger new immutable Cloud snapshots via onChanged.
  const changed=Object.fromEntries(Object.entries(prepared.updates).filter(([key,value])=>
   RPGMBArchive.canonical(value)!==RPGMBArchive.canonical(existing[key])));
  if(Object.keys(changed).length){
   await chrome.storage.local.set(changed);
   await load(); // refresh Save/Day from restored local, not only popup preview
   await persist(); // rebuild scoped Cloud metadata without network upload
  }
  panel.textContent=`Đã nhập archive v2 và đối chiếu SHA-256.\nKhóa local thực sự thay đổi: ${Object.keys(changed).length}\nCampaign: ${prepared.campaignId}\n${prepared.chatCount} chat · ${prepared.counts.verified} RAW UUID · ${prepared.counts.provisional} DOM provisional · ${prepared.counts.frames} frames.\n${prepared.warnings.length?'⚠️ CẦN ĐỐI CHIẾU METADATA:\n'+prepared.warnings.join('\n')+'\n':'Metadata: không có khác biệt đã phát hiện.\n'}Không xóa bản local hay Cloud. Kiểm tra lại Campaign và xuất JSON backup.`;
 }catch(err){panel.textContent='KHÔNG nhập archive: '+String(err.message||err);}finally{e.target.value='';busy(false);}};
})();
