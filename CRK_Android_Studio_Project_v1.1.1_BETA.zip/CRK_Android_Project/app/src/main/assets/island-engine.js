// RPG RAW Keeper v1.0.8 · Detached Evidence Continuation Engine.
// Read-only, never declares DOM observations to be a verified ChatGPT branch.
// This engine is deliberately isolated from primary TXT, Cloud and Campaign storage.
(function(root){
'use strict';
const API=root.RPGMBTimeline;if(!API)return;
const previousProject=API.project;
const norm=s=>String(s||'').replace(/\r\n?/g,'\n').replace(/\u00a0/g,' ').replace(/\s+/g,' ').trim();
const draft=o=>o?.role==='user'&&/(?:^|\n)\s*(?:Hủy|Huỷ)\s*\n\s*Gửi\s*$/i.test(String(o.text||'').slice(-200));
const status=o=>o?.role==='assistant'&&norm(o.text).length>=35&&norm(o.text).length<=1200&&
 (/^(?:Mình sẽ|Tôi sẽ|Tôi đang|Đang|Đã kiểm tra|Đã xác định|Đã định hình|Lượt trước thiếu|GM sẽ|Rõ[,!.]?\s.+(?:mình sẽ|tôi sẽ))/i.test(norm(o.text)) ||
 /^(?:Tôi hiểu|Mình hiểu|Đúng|Được)[,:.!]?\s+.{0,500}(?:tôi sẽ|mình sẽ)/i.test(norm(o.text)));
const completed=o=>o?.role==='assistant'&&norm(o.text).length>=1300&&!status(o);
// Same-slot short assistant notices can be rewritten several times before
// the substantive answer. Use adjacency + a strong prior viewport anchor,
// never global text-only de-duplication.
const shortNotice=o=>o?.role==='assistant'&&norm(o.text).length>=40&&norm(o.text).length<=850;
const prefixOverlap=(a,b)=>{let n=0;while(n<a.length&&n<b.length&&a[n]===b[n])n++;return n;};
const hash=s=>{let h=2166136261;for(let i=0;i<s.length;i++){h^=s.charCodeAt(i);h=Math.imul(h,16777619);}return(h>>>0).toString(36);};
function detect(chat,prior,options={}){
 const seed=prior.detachedTail;if(!seed?.count)return null;
 const occ=(chat?.provisionalOccurrences||[]).filter(o=>o?.observationId&&o.sourceChatId===chat.chatId&&o.sourceUrl===chat.sourceUrl&&
  o.captureOrigin==='live-conversation-dom-v090'&&['user','assistant'].includes(o.role)&&typeof o.text==='string'&&norm(o.text));
 const byId=new Map(occ.map(o=>[o.observationId,o]));
 const normalized=new Map(occ.map(o=>[o.observationId,norm(o.text)]));
 const text=id=>normalized.get(id)||'',role=id=>byId.get(id)?.role;
 const eq=(a,b)=>!!a&&!!b&&role(a)===role(b)&&text(a)===text(b);
 const allFrames=(chat.viewportEvidence||[]).filter(f=>f?.chatId===chat.chatId&&f?.sourceUrl===chat.sourceUrl&&
  Array.isArray(f.turns)&&f.turns.every(t=>byId.has(t.observationId)));
 // A viewport can show interim status followed by its full replacement; the
 // two are not counted as two GM turns. Distinct completed GM answers stay separate.
 function normalizeFrame(f){
  const ids=[];let dropped=0;
  for(const item of f.turns){
   const id=item.observationId,o=byId.get(id);if(draft(o)){dropped++;continue;}
   const last=ids.at(-1),old=byId.get(last);
   if(old?.role==='assistant'&&o.role==='assistant'){
    const a=text(last),b=text(id);
    if((a.length>=40&&b.length>=a.length+20&&b.startsWith(a)) ||
       ((status(old)||shortNotice(old))&&completed(o)) ||
       (status(old)&&!status(o)&&b.length>=450)){ids[ids.length-1]=id;dropped++;continue;}
    // A shorter, stale renderer must not displace a complete answer.
    if((b.length>=40&&a.length>=b.length+20&&a.startsWith(b)) ||
       (completed(old)&&(status(o)||shortNotice(o)))){dropped++;continue;}
   }
   ids.push(id);
  }
  return {ids,dropped};
 }
 // Long, unique GM messages are the anchors. Short identical choices ("1")
 // can contribute order only AFTER an independent GM anchor is established.
 const stableRun=(path,frame)=>{
  let best=null;
  for(let i=0;i<path.length;i++)for(let j=0;j<frame.length;j++){
   if(!eq(path[i],frame[j]))continue;
   let len=0,longs=new Set(),users=0;
   while(i+len<path.length&&j+len<frame.length&&eq(path[i+len],frame[j+len])){
    const id=path[i+len];if(role(id)==='assistant'&&text(id).length>=700)longs.add(text(id));
    if(role(id)==='user'&&text(id).length>=15)users++;len++;
   }
   const end=i+len,dist=path.length-end;
   const strong=len>=3&&longs.size&&(longs.size>=2||users>=1||len>=4);
   // On a virtualized mobile tail, only the last GM and the newly sent
   // PLAYER may remain visible. Recover only if a substantial GM anchor is
   // UNIQUE on both sides AND occurs at the actual end of the known island.
   // A lone "1" or any early-history match is NEVER sufficient.
   const soleLongGM=role(path[i])==='assistant'&&text(path[i]).length>=900;
   const anchorUnique=soleLongGM&&path.filter(id=>eq(id,path[i])).length===1&&
     frame.filter(id=>eq(id,frame[j])).length===1;
   const nearTail=dist<=2 && i>=Math.max(0,path.length-4);
   const weak=anchorUnique&&nearTail&&len>=1&&j+len<frame.length&&
     (len>=2 || (len===1&&role(frame[j+1])==='user'&&text(frame[j+1]).length>=2));
   if(!strong&&!weak)continue;
   const score=(strong?1000:0)+len*30+longs.size*40+Math.min(20,users*5)+
     (end===path.length?60:0)+(j+len===frame.length?10:0);
   if(!best||score>best.score)best={i,j,len,end,jEnd:j+len,score,weak:!strong};
  }
  return best;
 };
 // A seed from an earlier projection may contain two GM elements for a
 // single observed ChatGPT response: its planning/status bubble followed by
 // its short final answer. Only compact such a pair if an actual viewport
 // explicitly shows both adjacent, and keep BOTH in the lossless JSON.
 const coVisible=new Set();
 for(const f of allFrames)for(let k=1;k<f.turns.length;k++){
  coVisible.add(f.turns[k-1].observationId+'|'+f.turns[k].observationId);
 }
 const original=[];let seedStatusCompactions=0;
 for(const item of seed.turns){
  const id=item.observationId;if(!byId.has(id)||draft(byId.get(id)))continue;
  const prev=original.at(-1),prior=byId.get(prev),fresh=byId.get(id);
  if(prior?.role==='assistant'&&fresh?.role==='assistant'&&
    status(prior)&&!status(fresh)&&norm(fresh.text).length>=450&&
    coVisible.has(prev+'|'+id)){
   original[original.length-1]=id;seedStatusCompactions++;continue;
  }
  original.push(id);
 }
 const seedLast=original.at(-1);
 let start=allFrames.findIndex((f,i)=>i>=Math.max(0,(seed.firstFrameIndex||0))&&f.turns.some(t=>t.observationId===seedLast));
 // A fully reminted viewport might not carry the last observation ID. Find
 // the same long, contextual tail instead, not just any earlier PLAYER "1".
 if(start<0){const gm=original.slice().reverse().find(id=>role(id)==='assistant'&&text(id).length>=900);
  if(gm)start=allFrames.findIndex((f,i)=>i>=Math.max(0,(seed.firstFrameIndex||0))&&
   f.turns.some(t=>eq(t.observationId,gm)));
 }
 if(start<0)start=Math.max(0,seed.firstFrameIndex||0);
 let primary=original.slice(),promotions=0,appended=0,ignored=0,uncertain=0,excludedDrafts=0,weakTailAnchors=0;
 const variants=new Map();
 const sufficientTail=(path,run)=>run.end>=Math.max(0,path.length-1);
 function handleFrame(path,frame,fi,mayFork){
  const run=stableRun(path,frame);
  if(!run)return {kind:'skip'};
  // Viewport is only an old/prefix slice: never roll an established branch back.
  if(run.jEnd>=frame.length)return {kind:'noop'};
  const suffix=frame.slice(run.jEnd),point=run.end;
  if(point<path.length){
   const old=byId.get(path[point]),next=byId.get(suffix[0]);
   // Exactly the SAME logical GM slot: status or streaming preview, then full.
   if(point===path.length-1&&old?.role==='assistant'&&next?.role==='assistant'&&
     (((status(old)||shortNotice(old))&&completed(next)) ||
       ((status(old)||shortNotice(old))&&shortNotice(next)&&prefixOverlap(text(path[point]),text(suffix[0]))>=75) ||
       (text(path[point]).length>=40&&text(suffix[0]).startsWith(text(path[point]))&&
        text(suffix[0]).length>text(path[point]).length+20))){
    path.splice(point,1,...suffix);return {kind:'promoted',count:suffix.length-1,weak:run.weak};
   }
   // Text is identical after a remint: advance only genuinely new suffix.
   let k=0;while(point+k<path.length&&k<suffix.length&&eq(path[point+k],suffix[k]))k++;
   if(k===suffix.length)return {kind:'noop'};
   if(point+k===path.length){path.push(...suffix.slice(k));return {kind:'append',count:suffix.length-k,weak:run.weak};}
   const a=byId.get(path[point+k]),b=byId.get(suffix[k]);
   const plausible=(a?.role===b?.role)&&(
    a.role==='user'&&(!draft(b)&&norm(a.text)!==norm(b.text)) ||
    a.role==='assistant'&&completed(a)&&completed(b)&&norm(a.text)!==norm(b.text));
   if(!plausible||!mayFork)return {kind:'ambiguous'};
   const pivot=point+k,id='island:'+pivot+':'+hash(path.slice(Math.max(0,pivot-3),pivot).join('|')+'\u001f'+b.role+'\u001f'+norm(b.text));
   if(!variants.has(id)&&variants.size<14)variants.set(id,{id,pivot,createdAtFrame:fi,
    label:(b.role==='user'?'PLAYER sửa':'GM Thử lại')+' tại B #'+(pivot+1),
    path:path.slice(0,pivot).concat(suffix.slice(k))});
   return {kind:'fork'};
  }
  // Verified within the SAME observed viewport, but *not* verified against
  // ChatGPT's currently active server branch.
  path.push(...suffix);return {kind:'append',count:suffix.length,weak:run.weak};
 }
 for(let fi=start;fi<allFrames.length;fi++){
  const f=normalizeFrame(allFrames[fi]);excludedDrafts+=f.dropped;
  if(f.ids.length<2)continue;
  const outcome=handleFrame(primary,f.ids,fi,true);
  if(outcome.weak && ['append','promoted'].includes(outcome.kind))weakTailAnchors++;
  if(outcome.kind==='promoted'){promotions++;appended+=outcome.count||0;}
  else if(outcome.kind==='append')appended+=outcome.count||0;
  else if(outcome.kind==='ambiguous'||outcome.kind==='fork')uncertain++;
  else ignored++;
  for(const variant of variants.values())if(fi>variant.createdAtFrame){
   const o=handleFrame(variant.path,f.ids,fi,true);
   if(o.kind==='ambiguous')variant.conflicts=(variant.conflicts||0)+1;
  }
 }
 const selected=variants.get(options?.selectedDetachedId);
 const chosen=(selected?.path||primary);
 const unique=[],seen=new Set();for(const id of chosen)if(!seen.has(id)){seen.add(id);unique.push(id);}
 const turns=unique.map(id=>byId.get(id)).filter(Boolean);
 const counts=()=>({count:turns.length,userCount:turns.filter(o=>o.role==='user').length,
  gmCount:turns.filter(o=>o.role==='assistant').length});
 const altOptions=[{id:'',label:'Đường RAW rời mặc định',count:primary.length,
  lastText:byId.get(primary.at(-1))?.text.slice(0,170)||''},
  ...[...variants.values()].map(v=>({id:v.id,label:v.label,count:v.path.length,
   pivot:v.pivot,firstText:byId.get(v.path[v.pivot])?.text.slice(0,150)||'',
   lastText:byId.get(v.path.at(-1))?.text.slice(0,150)||''}))];
 return {...seed,...counts(),turns,pendingEdit:seed.pendingEdit||variants.size>0,
  lastPreview:norm(turns.at(-1)?.text).slice(0,150),
  resumedAfterStatus:promotions,seedStatusCompactions,continuedTurns:appended,frameScanStart:start,
  ignoredFrames:ignored,uncertainFrames:uncertain,weakTailAnchors,excludedEditorDrafts:excludedDrafts,
  optionCount:altOptions.length,branchOptions:altOptions,selectedDetachedId:selected?.id||'',
  lastGMStatus:turns.at(-1)?.role==='assistant'&&status(turns.at(-1)),
  generation:'1.0.8',missingBridge:true,
  important:'RAW rời được nối từ các khung DOM có mốc chung. Còn khoảng trống với TXT chính, không xác minh nhánh ChatGPT hiện hành.'};
}
API.project=function(chat,options={}){
 const p=previousProject(chat,options);
 if(!p.detachedTail?.count)return p;
 try{
  const r=detect(chat,p,options);if(!r)return p;
  const more=r.count-p.detachedTail.count;
  const warnings=[...(p.coreIntegrity?.warnings||[])];
  if(r.uncertainFrames&&!warnings.includes('ISLAND_BRANCHES_REQUIRE_REVIEW'))warnings.push('ISLAND_BRANCHES_REQUIRE_REVIEW');
  if(r.lastGMStatus&&!warnings.includes('ISLAND_TAIL_GM_STATUS_PENDING'))warnings.push('ISLAND_TAIL_GM_STATUS_PENDING');
  if(r.weakTailAnchors&&!warnings.includes('ISLAND_SINGLE_GM_ANCHOR_UNVERIFIED'))warnings.push('ISLAND_SINGLE_GM_ANCHOR_UNVERIFIED');
  return {...p,detachedTail:r,coreIntegrity:{...p.coreIntegrity,detachedCandidateCount:r.count,
   islandRecovered:more,islandBranchCount:r.optionCount, warnings}};
 }catch(err){return {...p,islandRebuildError:String(err?.stack||err)};}
};
API.islandEngineVersion='1.0.8';
root.RPGMBIslandEngine={detect,version:'1.0.8'};
})(typeof globalThis!=='undefined'?globalThis:this);
