// RPG RAW Keeper v1.0.4 - continuous *observed* turn accounting, explicit gap.
// Read-only. This module changes neither captured evidence nor cloud state.
(function(root){
'use strict';
const safe=o=>Array.isArray(o)?o:[];
const user=x=>x?.role==='user';
const gm=x=>x?.role==='assistant';
const title=x=>String(x?.c?.title||x?.c?.chatId||'Chat');
function tally(items){
 const rows=safe(items);
 let mainCount=0,detachedCount=0,player=0,gmCount=0,gapCount=0;
 for(const item of rows){
  const p=item?.projection||{};
  const a=safe(p.turns),b=safe(p.detachedTail?.turns);
  mainCount+=a.length;detachedCount+=b.length;
  player+=a.filter(user).length+b.filter(user).length;
  gmCount+=a.filter(gm).length+b.filter(gm).length;
  if(a.length&&b.length)gapCount++;
 }
 return {mainCount,detachedCount,count:mainCount+detachedCount,player,gm:gmCount,gapCount};
}
function generate(items,version='1.0.4',{audit=false}={}){
 const out=[`CRK CAMPAIGN RAW KEEPER v${version} · RAW ĐÃ GHI NHẬN THEO NHÁNH ĐƯỢC CHỌN`,
  '⚠️ CHỈ LÀ DỮ LIỆU ỨNG VIÊN TỪ DOM. CHƯA XÁC MINH UUID HOẶC NHÁNH HOẠT ĐỘNG.',
  '⚠️ KHOẢNG TRỐNG CAPTURE ĐƯỢC ĐÁNH DẤU RIÊNG. TỔNG SỐ LƯỢT ĐÃ THẤY KHÔNG PHẢI LỊCH SỬ LIỀN MẠCH/CANON.',
  'Giữ Backup JSON vì các phiên bản Edit/Retry khác không nằm trong bản xuất này.'];
 const totals=tally(items);
 out.push(`TỔNG ĐÃ DỰNG: ${totals.count} lượt (${totals.player} PLAYER + ${totals.gm} GM). Phần chính ${totals.mainCount}, RAW rời ${totals.detachedCount}, ${totals.gapCount} khoảng đứt đã biết.`);
 for(const it of safe(items)){
  const c=it?.c||{},p=it?.projection||{},a=safe(p.turns),b=safe(p.detachedTail?.turns);
  if(!a.length&&!b.length)continue;
  out.push(`========== ${title(it)} | CHAT ${c.chatId||'?'} ==========`);
  if(p.retroFork?.requiresChoice)out.push('⚠️ NHÁNH EDIT CHÍNH CHƯA CHỌN. CHỈ CÓ PHẦN CHUNG ĐẾN ĐIỂM RẼ.');
  if(p.branchOptions?.some(o=>o.kind==='retry'))out.push('⚠️ CÓ GM THỬ LẠI. Chỉ xuất đường đang được chọn trên thiết bị này.');
  function block(prefix,turns){
   out.push(`========== ĐOẠN ${prefix}: ${turns.length} LƯỢT ==========`);
   for(let i=0;i<turns.length;i++){
    const x=turns[i];let header=`[${prefix} #${i+1} · ${user(x)?'PLAYER':'GM'}`;
    if(audit)header+=` · ${x.observationId||'NO_ID'} · CHƯA XÁC MINH UUID`;
    out.push(`${header}]\n${String(x.text||'')}`);
   }
  }
  if(a.length)block('A',a);
  if(b.length){
   if(a.length){
    out.push('================================================================');
    out.push('⚠️ ĐỨT LỊCH SỬ Ở ĐÂY. KHÔNG CÓ BẰNG CHỨNG LIỀN MẠCH GIỮA A VÀ B.');
    out.push('⚠️ Một hoặc nhiều lượt có thể chưa từng được Capture. KHÔNG tự suy đoán kết quả hoặc xem A+B là một đường canon.');
    out.push(`A kết thúc: ${(a.at(-1)?.text||'').slice(0,170)}`);
    out.push(`B bắt đầu: ${(b[0]?.text||'').slice(0,170)}`);
    out.push('================================================================');
   }
   if(p.detachedTail?.pendingEdit)out.push('⚠️ ĐOẠN B CÓ PLAYER ĐÃ SỬA. Cần đối chiếu nhánh gốc; bản nháp Hủy/Gửi đã loại khỏi bản xuất.');
   if(p.detachedTail?.branchOptions?.length>1)out.push('⚠️ ĐOẠN B CÓ NHIỀU NHÁNH. Đang dùng phương án được chọn cục bộ, không xác minh bằng UUID.');
   if(p.detachedTail?.lastGMStatus)out.push('⚠️ GM cuối đoạn B có thể chưa hoàn chỉnh.');
   block('B',b);
  }
  if(audit){
   const unused=safe(p.unused);if(unused.length)out.push(`CÓ ${unused.length} QUAN SÁT KHÁC (quét lặp, Edit/Retry, streaming hoặc chưa nối) CHỈ NẰM TRONG JSON. ID: `+unused.map(x=>x.observationId).join(', '));
  }
 }
 return out.join('\n\n');
}
root.RPGMBWorkingRaw={tally,generate,version:'1.0.4'};
})(typeof globalThis!=='undefined'?globalThis:this);
