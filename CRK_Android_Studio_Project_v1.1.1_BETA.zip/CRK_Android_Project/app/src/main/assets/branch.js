// Checkpoint branch lineage is explicit and evidence-based. Never infer a fork
// merely from a title or equal text. ChatGPT's DOM is partial and virtualized.
(function(root){
 'use strict';
 const uuid=id=>/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(String(id||''));
 const norm=s=>String(s||'').replace(/\r\n?/g,'\n').replace(/\u00a0/g,' ').trim();
 const proven=m=>uuid(m?.id)&&m?.identityVerified===true&&m?.identityProof==='same-turn-native-id-role-v081'&&['user','assistant'].includes(m?.role);
 const from=chat=>root.RPGLedger.ledger(chat||{messages:[]}).messages.filter(proven);
 // ChatGPT's desktop DOM sometimes exposes no native message UUID at all.
 // identity.js stores SHA-256(role + separator + normalized text) per visible
 // viewport turn. These tokens can show text similarity, NEVER source identity.
 const HASH=/^[0-9a-f]{64}$/i;
 function trustedFrames(chat){
  const id=chat?.chatId;
  if(!uuid(id))return [];
  return (Array.isArray(chat.viewportEvidence)?chat.viewportEvidence:[]).slice(-40).filter(f=>{
   if(f?.chatId!==id||!uuid(f?.frameId)||!HASH.test(String(f?.signature||''))||
      !Array.isArray(f.turns)||!f.turns.length||f.turns.length>5000)return false;
   const urlId=root.RPGMBSafe?.chatIdFromUrl?.(f.sourceUrl);
   if(urlId?urlId!==id:!new RegExp('^https://chatgpt\\.com/c/'+id+'(?:[?#].*)?$','i').test(f.sourceUrl||''))return false;
   return f.turns.every(t=>t&&['user','assistant'].includes(t.role)&&HASH.test(String(t.token||'')));
  });
 }
 function observedTextPrefix(parent,child){
  const pa=trustedFrames(parent),ch=trustedFrames(child);
  let best=0,selected=null;
  // Multiple captures are normal. Use only matching prefixes of *observed*
  // viewport frames. A match is not necessarily the start of conversation.
  for(const a of pa)for(const b of ch){
   let n=0;
   while(n<a.turns.length&&n<b.turns.length&&
     a.turns[n].role===b.turns[n].role&&a.turns[n].token===b.turns[n].token)n++;
   if(n>best){best=n;selected={parentFrameId:a.frameId,childFrameId:b.frameId};}
  }
  return {count:best,parentFrameCount:pa.length,childFrameCount:ch.length,
   parentObserved:pa.reduce((n,f)=>Math.max(n,f.turns.length),0),
   childObserved:ch.reduce((n,f)=>Math.max(n,f.turns.length),0),frames:selected};
 }
 function analyze(parent,child){
  const a=from(parent),b=from(child),equal=(x,y)=>x.id===y.id&&x.role===y.role&&norm(x.text)===norm(y.text);
  let shared=0,verifiedTextPrefix=0;
  while(shared<a.length&&shared<b.length&&equal(a[shared],b[shared]))shared++;
  while(verifiedTextPrefix<a.length&&verifiedTextPrefix<b.length&&a[verifiedTextPrefix].role===b[verifiedTextPrefix].role&&norm(a[verifiedTextPrefix].text)===norm(b[verifiedTextPrefix].text))verifiedTextPrefix++;
  const observed=observedTextPrefix(parent,child);
  const textOnly=Math.max(verifiedTextPrefix,observed.count);
  const evidence=shared>=2?'VERIFIED_SHARED_PREFIX':textOnly>=2?'TEXT_ONLY_UNVERIFIED':'INSUFFICIENT_EVIDENCE';
  return {evidence,sharedCount:shared,textOnlyCount:textOnly,parentObserved:a.length,childObserved:b.length,
   viewportTextPrefixCount:observed.count,parentViewportObserved:observed.parentObserved,
   childViewportObserved:observed.childObserved,parentFrameCount:observed.parentFrameCount,
   childFrameCount:observed.childFrameCount,observedFrameIds:observed.frames,
   forkAnchorId:shared>=2?a[shared-1].id:null,
   note:evidence==='VERIFIED_SHARED_PREFIX'?'These captured turns share native UUIDs. Hidden history may still be missing.':
    evidence==='TEXT_ONLY_UNVERIFIED'?'Observed role/text prefix matches, but identical content does not establish common source identity or actual fork point. Do not deduplicate or assign canon by text.':
    'No matching prefix in the available trusted evidence. History may be partially rendered or missing; the branch can still exist.'};
 }
 function validateIndex(index){
  if(!index || typeof index!=='object'||Array.isArray(index) || !Array.isArray(index.links)||index.links.length>5000)return false;
  const children=new Set();
  const parentOf=new Map();
  const shaped=index.links.every(link=>{
   if(!link||!uuid(link.parentChatId)||!uuid(link.childChatId)||link.parentChatId===link.childChatId||
      !['checkpoint','alternate'].includes(link.mode)||
      !['VERIFIED_SHARED_PREFIX','TEXT_ONLY_UNVERIFIED','INSUFFICIENT_EVIDENCE'].includes(link.evidence)||
      (link.forkAnchorId!==null&&link.forkAnchorId!==undefined&&!uuid(link.forkAnchorId))||
      !Number.isSafeInteger(link.sharedCount)||link.sharedCount<0||link.sharedCount>1000000||
      (link.textOnlyCount!==undefined&&(!Number.isSafeInteger(link.textOnlyCount)||link.textOnlyCount<0||link.textOnlyCount>1000000))||
      typeof link.createdAt!=='string'||link.createdAt.length>64||children.has(link.childChatId))return false;
   children.add(link.childChatId);
   parentOf.set(link.childChatId,link.parentChatId);
   return true;
  });
  if(!shaped)return false;
  // Imported/remote branch metadata must be a DAG too. Register() previously
  // prevented newly created cycles, but validateIndex() accepted preexisting ones.
  const completed=new Set();
  for(const start of parentOf.keys()){
   if(completed.has(start))continue;
   const path=new Set();let current=start;
   while(parentOf.has(current)&&!completed.has(current)){
    if(path.has(current))return false;
    path.add(current);current=parentOf.get(current);
   }
   for(const node of path)completed.add(node);
  }
  return true;
 }
 function register(index,parent,child,mode='checkpoint',date=new Date().toISOString()){
  if(index!==undefined&&index!==null&&!validateIndex(index))throw Error('Branch index đầu vào không hợp lệ hoặc có vòng lặp.');
  if(!parent?.chatId||!child?.chatId||!uuid(parent.chatId)||!uuid(child.chatId)||parent.chatId===child.chatId)throw Error('Chọn hai hội thoại khác nhau có Chat ID hợp lệ.');
  if(!['checkpoint','alternate'].includes(mode))throw Error('Loại nhánh không hợp lệ.');
  const result=analyze(parent,child),prior=(index?.links||[]).find(x=>x.childChatId===child.chatId),links=[...(index?.links||[])].filter(x=>x.childChatId!==child.chatId);
  // Checkpoint chains cannot be circular.
  let current=parent.chatId;const seen=new Set([child.chatId]);
  while(current){if(seen.has(current))throw Error('Quan hệ nhánh tạo vòng lặp, đã chặn.');seen.add(current);current=links.find(x=>x.childChatId===current)?.parentChatId||null;}
  const record={parentChatId:parent.chatId,childChatId:child.chatId,mode,evidence:result.evidence,
   forkAnchorId:result.forkAnchorId,sharedCount:result.sharedCount,textOnlyCount:result.textOnlyCount,createdAt:prior?.createdAt||date,updatedAt:date};
  links.push(record);const next={links};if(!validateIndex(next))throw Error('Branch index không hợp lệ.');
  return {index:next,record,analysis:result};
 }
 function isCheckpoint(campaign,chatId){return !!campaign?.branchIndex?.links?.some(l=>l.childChatId===chatId&&l.mode==='checkpoint');}
 // Render/extract on a parent, not a copied branch: duplicated ancestor content
 // must remain available as evidence, but isn't counted as a second Day event.
 root.RPGMBBranch={uuid,proven,observedTextPrefix,analyze,register,validateIndex,isCheckpoint};
})(typeof globalThis==='undefined'?self:globalThis);
