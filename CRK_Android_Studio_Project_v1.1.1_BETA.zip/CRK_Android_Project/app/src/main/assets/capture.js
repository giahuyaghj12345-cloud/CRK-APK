(()=>{
  if (window.__rpgmb090) return;
  window.__rpgmb090 = true;
  const EXT_VERSION=chrome.runtime.getManifest().version;
  const PREFIX='rpgmb:';
  const canonicalSource=id=>'https://chatgpt.com/c/'+id;
  const ignoredNode=n=>!!n?.closest('aside,nav,[role=dialog],[role=search],[data-testid=search-results],[data-testid=conversation-search-results]');
  const clean=s=>String(s||'').replace(/\u00a0/g,' ').trim();
  // Inline Edit controls are not part of PLAYER's message. A draft may stay
  // visible for seconds while the user decides whether to Save or Cancel.
  // Never let it enter the active timeline or the legacy DOM evidence.
  const draftToolbar=/\b(?:Hủy|Huỷ|Cancel)\s*\n\s*(?:Gửi|Send|Save)\s*$/i;
  const draftText=t=>draftToolbar.test(clean(t));
  function inlineEditOpen(root){
    const turns=[...root.querySelectorAll('[class*="group/user-message"],[data-message-author-role="user"]')];
    return turns.some(n=>{
      const scope=n.closest('[data-testid^="conversation-turn-"]')||n;
      const controls=[...scope.querySelectorAll('button,[role="button"]')].map(b=>
        clean([b.getAttribute('aria-label'),b.getAttribute('title'),b.getAttribute('data-testid'),b.innerText].filter(Boolean).join(' ')).toLowerCase());
      const cancel=controls.some(x=>/(?:^|\s)(?:hủy|huỷ|cancel)(?:$|\s)/i.test(x));
      const submit=controls.some(x=>/(?:^|\s)(?:gửi|send|save|lưu)(?:$|\s)|send-button|submit-button/i.test(x));
      const editable=!!scope.querySelector('[contenteditable="true"],textarea,[role="textbox"]');
      return (cancel && (submit || editable)) || (editable && cancel);
    });
  }
  function textOf(node){
    // innerText on the LIVE node preserves visible paragraph boundaries.
    // A detached clone's innerText may be empty and textContent joins paragraphs.
    const live=node.innerText;
    if(typeof live==='string' && live.trim())return clean(live);
    const clone=node.cloneNode(true);
    clone.querySelectorAll('button,svg,script,style,textarea,input,nav,footer,[aria-hidden="true"],[data-testid*="action-bar"]').forEach(n=>n.remove());
    clone.querySelectorAll('br').forEach(n=>n.replaceWith('\n'));
    clone.querySelectorAll('p,li,h1,h2,h3,h4,blockquote').forEach(n=>n.append(document.createTextNode('\n')));
    return clean(clone.textContent);
  }
  // Do not infer assistant messages merely because a block is not a user block.
  function roleOf(node){
    for(let n=node,steps=0;n&&steps<22;n=n.parentElement,steps++){
      const explicit=n.getAttribute?.('data-message-author-role')||n.getAttribute?.('data-role');
      if(['user','assistant'].includes(explicit))return explicit;
      const tid=n.getAttribute?.('data-testid')||'';
      const cls=typeof n.className==='string'?n.className:'';
      if(/(?:conversation-turn-user|user-message|user-turn)/i.test(tid)||/group\/user-message|bg-user-message/.test(cls))return 'user';
      if(/(?:conversation-turn-assistant|assistant-message|assistant-turn)/i.test(tid)||/(?:agent-turn|group\/assistant-message|group\/assistant-turn)/.test(cls))return 'assistant';
    }
    return 'unknown';
  }
  function assistantBoundary(heading,root){
    // A scoped block contains one ChatGPT message; stop before the nearest
    // conversation group (otherwise one answer could swallow several turns).
    let el=heading.parentElement, fallback=null;
    for(let depth=0;el && depth<9 && root.contains(el);el=el.parentElement,depth++){
      const cls=typeof el.className==='string'?el.className:'';
      if(/(?:^|\s)block-[\w-]{4,}(?=\s|$)/.test(cls))return el;
      if(!fallback && el.querySelector('[class*="DilResponseRoot"],[class*="MarkdownRoot"],.markdown,[class*="puik-root"]'))fallback=el;
      if(/(?:^|\s)group\/thread|thread-scroll-container|group\/turn-messages/.test(cls))break;
    }
    return fallback;
  }
  function assistantText(wrapper,heading){
    const bodySelector='[class*="DilResponseRoot"],[class*="MarkdownRoot"],.markdown,[class*="puik-root"],[data-message-content]';
    let bodies=[...wrapper.querySelectorAll(bodySelector)]
      .filter(n=>!n.closest('[class*="group/user-message"]') &&
        !n.closest('[class*="activity-header"],[class*="agent-activity"],[data-agent-activity]'));
    // Inner-most accessible renderer is OK as long as only ONE text copy is read;
    // choose outermost eligible bodies instead of concatenating nested DIL nodes.
    bodies=bodies.filter(n=>!bodies.some(other=>other!==n&&other.contains(n)));
    const texts=bodies.map(textOf).filter(Boolean);
    let output=clean(texts.join('\n\n'));
    if(output)return {text:output,method:'assistant-renderer'};
    // Some UI versions put the answer in siblings without MarkdownRoot/DIL root.
    // Read only within the same bounded message block, never its parent/group.
    const clone=wrapper.cloneNode(true);
    clone.querySelectorAll('button,svg,script,style,textarea,input,nav,footer,[aria-hidden="true"],.sr-only,[class*="activity-header"],[class*="agent-activity"],[data-agent-activity],[data-testid*="action-bar"]').forEach(el=>el.remove());
    clone.querySelectorAll('br').forEach(n=>n.replaceWith('\n'));
    clone.querySelectorAll('p,li,h1,h2,h3,h4,blockquote').forEach(n=>n.append(document.createTextNode('\n')));
    output=clean(clone.textContent).replace(/^(?:ChatGPT đã nói|ChatGPT said|Assistant said)\s*:\s*/i,'');
    // Do not accidentally store streaming activity summaries / empty placeholders.
    if(output.length<12 || /^(?:Đang suy nghĩ|Thinking|Analyzing|Phản hồi mới nhất)\b/i.test(output))return {text:'',method:'pending'};
    return {text:output,method:'assistant-boundary'};
  }
  const USER_SELECTOR='[data-testid*="user-message"],.text-size-chat.whitespace-pre-wrap,[class*="group/user-message"]';
  function read(){
    const root=document.querySelector('main')||document.body;
    const metric={turns:root.querySelectorAll('[data-testid*="conversation-turn"]').length,roles:root.querySelectorAll('[data-message-author-role]').length,articles:root.querySelectorAll('article').length,markdown:root.querySelectorAll('.markdown').length};
    // An open ChatGPT inline user editor is not committed conversation data.
    if(inlineEditOpen(root))return {msgs:[],mode:'inline-editor-open',metric,editorOpen:true};
    // Android/modern ChatGPT renders native turn IDs and author roles. Prefer
    // those over class-name guesses and never scrape one paragraph as a turn.
    const nativeTurns=[...root.querySelectorAll('[data-testid^="conversation-turn-"]')].filter(n=>!ignoredNode(n));
    const nativeMessages=[];
    const nativeCandidateNodes=[];
    for(const turn of nativeTurns){
      // A native ID is trusted only when role and ID live on the SAME
      // message container nested within this particular turn.
      const containers=[...turn.querySelectorAll('[data-message-author-role][data-message-id]')];
      if(turn.matches('[data-message-author-role][data-message-id]'))containers.unshift(turn);
      const source=containers.find(el=>{
        const role=el.getAttribute('data-message-author-role');
        return (role==='user'||role==='assistant') &&
          /^[0-9a-f]{8}-[0-9a-f-]{27,}$/i.test(el.getAttribute('data-message-id')||'');
      })||turn.querySelector('[data-message-author-role]');
      const role=source?.getAttribute('data-message-author-role');
      if(role!=='user'&&role!=='assistant')continue;
      const claimedId=source.getAttribute('data-message-id')||null;
      const nativeId=/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(claimedId||'')?claimedId:null;
      // The renderers vary across desktop/mobile. Prefer the message body over
      // surrounding buttons, virtualized controls, or hidden accessibility text.
      let body;
      if(role==='user')body=source.querySelector('.rich-text-user-turn,[class*="text-size-chat"].whitespace-pre-wrap,[class*="user-message-bubble-color"]')||source;
      else body=source.querySelector('[class*="MarkdownRoot"],.markdown,[class*="agent-turn"],[data-message-content]')||source;
      const txt=textOf(body).replace(/^ChatGPT (?:đã nói|said):\s*/i,'').trim();
      // Some desktop variants expose the Edit toolbar in the same text node.
      if(role==='user' && draftText(txt))return {msgs:[],mode:'inline-editor-draft',metric,editorOpen:true};
      if(!txt || /^(đang suy nghĩ|thinking\.{0,3}|analyzing\.{0,3})$/i.test(txt))continue;
      nativeMessages.push({id:nativeId||`provisional:native-turn:${turn.getAttribute('data-testid')}:${role}`,role,text:txt,position:Number((turn.getAttribute('data-testid')||'').match(/conversation-turn-(\d+)/)?.[1]??nativeMessages.length),sourceTurn:Number((turn.getAttribute('data-testid')||'').match(/conversation-turn-(\d+)/)?.[1]??nativeMessages.length),method:'native-turn',verified:!!nativeId,provisional:!nativeId});
      nativeCandidateNodes.push(turn);
    }
    // On some Android builds ChatGPT supplies only native USER wrappers while
    // GM answers are still rendered in non-native assistant containers. Do not
    // accept the native subset as the complete viewport in that situation.
    if(nativeMessages.some(x=>x.role==='assistant')){
      if(nativeMessages.some(x=>x.role==='user'&&draftText(x.text)))
        return {msgs:[],mode:'inline-editor-draft',metric,editorOpen:true};
      return {msgs:nativeMessages,mode:'native-turns',metric,editorOpen:false};
    }
    // Desktop UI (Oct 2026) does not always expose native turn wrappers.
    // Treat a visually bounded assistant answer as provisional, NEVER as native.
    const msgs=[];
    const candidates=nativeMessages.map((m,i)=>({node:nativeCandidateNodes[i],role:m.role,
      text:m.text,method:m.method,nativeId:m.verified?m.id:null,
      captureStatus:'visible-dom'}));
    const userNodes=[...root.querySelectorAll('[class*="group/user-message"]')]
      .filter(n=>!n.parentElement?.closest('[class*="group/user-message"]') && !ignoredNode(n));
    for(const node of userNodes){
      if(candidates.some(c=>c.role==='user' && (c.node===node || c.node.contains(node))))continue;
      const body=node.querySelector('.text-size-chat.whitespace-pre-wrap') ||
        node.querySelector('[class*="bg-user-message"]') ||
        node.querySelector('.rich-text-user-turn');
      const txt=clean((body||node).innerText||(body||node).textContent);
      if(draftText(txt))return {msgs:[],mode:'inline-editor-draft',metric,editorOpen:true};
      if(!txt)continue;
      // Some attachment-only messages expose only a file card/filename. Never
      // claim a file preview is the original user-entered/pasted document.
      const attachmentOnly=!body && /(?:\.txt|\.pdf|\.docx?|\.json|\.xlsx?)\s*(?:Tài liệu|Document)?\s*$/i.test(txt);
      candidates.push({node,role:'user',text:txt,method:attachmentOnly?'attachment-preview':'user-group',captureStatus:attachmentOnly?'file-card-only':undefined});
    }
    // New desktop UI can render assistant answers using either Markdown or DIL.
    // The hidden accessibility heading identifies a *message boundary*; the
    // minified CSS names are deliberately only hints, not identity guarantees.
    const headings=[...root.querySelectorAll('h2,h3,h4')].filter(n=>n.classList.contains('sr-only') &&
      /^(?:ChatGPT đã nói|ChatGPT said|Assistant said)\s*:/i.test(clean(n.textContent)) && !ignoredNode(n));
    for(const heading of headings){
      const wrapper=assistantBoundary(heading,root);
      if(!wrapper || wrapper.closest('[class*="group/user-message"]'))continue;
      const extracted=assistantText(wrapper,heading);
      if(!extracted.text)continue;
      if(candidates.some(c=>c.role==='assistant' && (c.node===wrapper || c.node.contains(wrapper) || wrapper.contains(c.node))))continue;
      candidates.push({node:wrapper,role:'assistant',text:extracted.text,method:extracted.method});
    }
    // Android and newer ChatGPT variants can omit the accessibility heading
    // entirely. Read ONLY bounded assistant-specific containers, not arbitrary
    // paragraphs outside USER bubbles. This is a conservative evidence fallback.
    const assistantContainers=[...root.querySelectorAll(
      '[data-message-author-role="assistant"],[class*="group/assistant-message"],[class*="group/assistant-turn"],[class*="agent-turn"]')]
      .filter(n=>!ignoredNode(n) && !n.closest('[class*="group/user-message"]'));
    for(const node of assistantContainers){
      if(candidates.some(c=>c.role==='assistant' &&
        (c.node===node || c.node.contains(node) || node.contains(c.node))))continue;
      // Skip broad thread/group containers capable of swallowing multiple
      // answers or a PLAYER message: exact message role is required for that.
      const explicitlyScoped=node.matches('[data-message-author-role="assistant"]');
      if(!explicitlyScoped &&
        (node.querySelector('[class*="group/user-message"],[data-message-author-role="user"]') ||
         node.querySelectorAll('h2.sr-only,h3.sr-only,h4.sr-only').length>1))continue;
      const body=node.querySelector('[class*="DilResponseRoot"],[class*="MarkdownRoot"],.markdown,[class*="puik-root"],[data-message-content]');
      // For generic agent-turn wrappers, require a renderer so tool/activity
      // containers cannot masquerade as completed assistant answers.
      if(!body && !explicitlyScoped && !node.matches('[class*="group/assistant-message"]'))continue;
      const extracted=assistantText(node,null);
      if(!extracted.text)continue;
      candidates.push({node,role:'assistant',text:extracted.text,method:extracted.method});
    }
    if(nativeMessages.length && !candidates.some(c=>c.role==='assistant')){
      if(nativeMessages.some(x=>x.role==='user'&&draftText(x.text)))
        return {msgs:[],mode:'inline-editor-draft',metric,editorOpen:true};
      return {msgs:nativeMessages,mode:'native-turns-user-only',metric,editorOpen:false};
    }
    // Sort nodes by document order to preserve USER/GM sequence.
    candidates.sort((a,b)=>a.node===b.node?0:(a.node.compareDocumentPosition(b.node)&Node.DOCUMENT_POSITION_FOLLOWING?-1:1));
    for(let i=0;i<candidates.length;i++){
      const c=candidates[i];
      const src=c.node.closest('[data-message-id][data-message-author-role]');
      const claimedId=src?.getAttribute('data-message-author-role')===c.role
        ? src.getAttribute('data-message-id') : null;
      const nativeId=/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(claimedId||'')?claimedId:null;
      // Versioned provisional ID prevents old incorrectly segmented fallback
      // messages from being silently overwritten. Mark unverified until a
      // native ID is known; DOM-only extraction is not an integrity guarantee.
      const id=c.nativeId||nativeId||`provisional:v068:${c.role}:${i}`;
      msgs.push({id,role:c.role,text:c.text,position:i,method:c.method,captureStatus:c.captureStatus||'visible-dom',verified:!!(c.nativeId||nativeId),provisional:!(c.nativeId||nativeId)});
    }
    const mode=candidates.some(x=>x.role==='assistant')?'user+assistant-groups':candidates.length?'user-groups':'none';
    // Last-chance fail-closed guard for variants where Edit controls are not
    // descendants of the bubble we inspected above.
    if(msgs.some(x=>x.role==='user' && draftText(x.text)))
      return {msgs:[],mode:'inline-editor-draft',metric,editorOpen:true};
    return {msgs,mode,metric,editorOpen:false};
  }
  function assistantDiscovery(root){
    // Inspect paragraphs/headings/list items in the conversation which are not
    // inside user bubbles. We deliberately do NOT automatically save these.
    const userSelector='[class*="group/user-message"],[class*="bg-user-message"]';
    const items=[...root.querySelectorAll('p,li,h1,h2,h3,h4,blockquote,[data-virtualized-turn-content]')];
    const visited=new Set(), out=[];
    for(const node of items){
      if(node.closest(userSelector)||node.closest('nav,aside,header,footer,button,[role="navigation"],form'))continue;
      if(node.matches('[data-virtualized-turn-content]')&&node.querySelector('p,li,h1,h2,h3,h4'))continue;
      const txt=clean(node.innerText||node.textContent);
      if(txt.length<15 || visited.has(txt)) continue;
      visited.add(txt);
      let e=node,trail=[];
      for(let j=0;e&&j<11;e=e.parentElement,j++){
        const attrs={};for(const k of ['data-testid','data-message-author-role','data-message-id','data-role','role','data-virtualized-turn-content']){
          const v=e.getAttribute?.(k);if(v!==null && v!==undefined)attrs[k]=String(v).slice(0,100);
        }
        trail.push({tag:e.tagName?.toLowerCase(),className:typeof e.className==='string'?e.className.slice(0,150):'',attrs});
      }
      out.push({tag:node.tagName.toLowerCase(),chars:txt.length,preview:txt.slice(0,100),ancestorTrail:trail});
      if(out.length>=12)break;
    }
    return {count:out.length,candidates:out};
  }
  // Explicit, on-demand inspector. Never modifies ChatGPT or canon.
  function inspect(){
    const root=document.querySelector('main')||document.body;
    const selectors=['[data-testid^="conversation-turn-"]','[data-message-author-role]','[data-testid*="user-message"]','[data-message-id]','article','.markdown','.whitespace-pre-wrap','[class*="group/user-message"]','[class*="agent-turn"]','[class*="group/assistant-message"]'];
    const counts=Object.fromEntries(selectors.map(x=>[x,root.querySelectorAll(x).length]));
    const result=read();
    const assistantBoundaries=[...root.querySelectorAll('h2.sr-only,h3.sr-only,h4.sr-only')].filter(n=>/^(?:ChatGPT đã nói|ChatGPT said|Assistant said)\s*:/i.test(clean(n.textContent))).slice(0,12).map(h=>{const b=assistantBoundary(h,root);const out=b?assistantText(b,h):{text:'',method:'none'};return {heading:clean(h.textContent),boundaryClass:typeof b?.className==='string'?b.className.slice(0,90):null,extraction:out.method,chars:out.text.length,rendererCount:b?.querySelectorAll('[class*="DilResponseRoot"],[class*="MarkdownRoot"],.markdown').length||0}});
    const assistantScan=assistantDiscovery(root);
    const candidates=result.msgs.slice(0,30).map((m,i)=>{
      const selector=result.mode==='turns'?selectors[0]:result.mode==='role'?selectors[1]:result.mode==='articles'?selectors[4]:null;
      const nodes=selector?[...root.querySelectorAll(selector)]:result.mode==='message-groups'?[...root.querySelectorAll('[class*="group/user-message"],[class*="agent-turn"],[class*="group/assistant-message"]')].filter(n=>!([...root.querySelectorAll('[class*="group/user-message"],[class*="agent-turn"],[class*="group/assistant-message"]')].some(p=>p!==n&&p.contains(n)))):[...root.querySelectorAll('[data-testid*="user-message"],.markdown,.whitespace-pre-wrap')];
      const n=result.mode==='native-turns'?[...root.querySelectorAll('[data-testid^="conversation-turn-"]')].filter(x=>x.querySelector('[data-message-author-role]'))[m.position]:(result.mode==='user+assistant-groups'||result.mode==='user-groups')
        ? (m.role==='user'?[...root.querySelectorAll('[class*="group/user-message"]')].filter(x=>!x.parentElement?.closest('[class*="group/user-message"]'))
           :[...root.querySelectorAll('h4.sr-only')].filter(x=>/^ChatGPT đã nói\s*:/i.test(clean(x.textContent))).map(x=>x.closest('[class*="block-"]')))
          .find(x=>x && clean(x.innerText||x.textContent).includes(m.text.slice(0,Math.min(25,m.text.length))))
        : nodes[m.position];const trail=[];
      for(let e=n,j=0;e&&j<7;e=e.parentElement,j++){
        const attrs={};for(const k of ['data-testid','data-message-author-role','data-message-id','data-role','role']){const v=e.getAttribute?.(k);if(v)attrs[k]=v.slice(0,100);}
        trail.push({tag:e.tagName?.toLowerCase(),className:typeof e.className==='string'?e.className.slice(0,100):'',attrs});
      }
      return {number:i+1,role:m.role,method:m.method,chars:m.text.length,preview:m.text.slice(0,90),sourceId:m.provisional?'provisional':'native',ancestorTrail:trail};
    });
    return {version:EXT_VERSION,assistantBoundaries,urlType:location.pathname.match(/\/c\/[^/]+/)?'conversation':'other',time:new Date().toISOString(),mainFound:!!document.querySelector('main'),counts,method:result.mode,found:result.msgs.length,candidates,assistantScan,assistantSaved:result.msgs.filter(m=>m.role==='assistant').length,userSaved:result.msgs.filter(m=>m.role==='user').length,warning:'Chẩn đoán chỉ dựa trên DOM hiển thị; chưa chứng minh đầy đủ lịch sử. Có thể chứa đoạn lời thoại riêng tư, hãy xem trước khi chia sẻ.'};
  }
  chrome.runtime.onMessage.addListener((msg,sender,sendResponse)=>{
    if(msg?.type!=='rpgmb-inspect')return;
    try{sendResponse({ok:true,report:inspect()});}catch(e){sendResponse({ok:false,error:String(e)});}
    return false;
  });
  const PAUSED='rpgmb-capture-paused-v091',TEST='rpgmb-fresh-test-v091';
  const ASSIGN='rpgmb-assign-v04',CAMPAIGNS='rpgmb-campaigns-v04';
  async function permitted(chatId){
    const state=await chrome.storage.local.get([PAUSED,TEST,ASSIGN,CAMPAIGNS]);
    if(state[PAUSED]===true||!chatId)return false;
    const mode=state[TEST];
    // Explicitly selected isolated test source can bypass Campaign assignment.
    if(mode?.active)return mode.allowedChatId===chatId;
    const campaignId=state[ASSIGN]?.[chatId];
    return !!(campaignId&&Object.hasOwn(state[CAMPAIGNS]||{},campaignId));
  }
  let timer,active=false,rerun=false,lastUrl=location.href,lastCandidate=null;
  // Session-only intent. A browser F5 never implies a revision.
  let pendingAction=null;
  function captureAction(event){
    const button=event.target?.closest?.('button,[role="button"]');
    if(!button)return;
    const label=clean([button.getAttribute('aria-label'),button.getAttribute('title'),
      button.getAttribute('data-testid'),button.innerText].filter(Boolean).join(' ')).toLowerCase();
    if(pendingAction?.kind==='edit' && /(?:^|\s)(?:cancel|hủy|huỷ)(?:$|\s)/i.test(label)){
      pendingAction=null;return;
    }
    const kind=/(regenerate|retry|try again|thử lại|tạo lại|tạo phản hồi khác|regenerate-button)/i.test(label)?'retry':
      /(?:^|\s)(?:edit|chỉnh sửa|sửa tin nhắn|edit message)(?:$|\s)/i.test(label)?'edit':
      /(previous response|next response|phiên bản trước|phiên bản sau)/i.test(label)?'switch':null;
    if(!kind)return;
    const turn=button.closest('[data-testid^="conversation-turn-"],[data-message-author-role],'+
      '[class*="group/user-message"],[class*="group/assistant-message"],[class*="agent-turn"]');
    if(!turn)return; // No safe target; don't truncate another message.
    const current=read().msgs;
    let item=null;
    const source=turn.matches('[data-message-author-role]')?turn:
      turn.querySelector('[data-message-author-role][data-message-id]');
    const sourceId=source?.getAttribute('data-message-id')||null;
    if(sourceId)item=current.find(m=>m.id===sourceId);
    if(!item){
      const tid=turn.getAttribute('data-testid')||'';
      const n=Number(tid.match(/conversation-turn-(\d+)/)?.[1]);
      if(Number.isFinite(n))item=current.find(m=>m.sourceTurn===n);
    }
    if(!item){
      const body=clean(turn.innerText||'');
      const matched=current.filter(m=>body.includes(m.text.slice(0,Math.min(m.text.length,140))));
      if(matched.length===1)item=matched[0];
    }
    if(!item)return;
    pendingAction={kind,sourceId:/^[0-9a-f]{8}-[0-9a-f-]{27,}$/i.test(item.id)?item.id:null,
      role:item.role,text:item.text,startedAt:Date.now(),eventId:crypto.randomUUID(),
      chatId:RPGMBSafe.chatIdFromUrl(location.href)};
    schedule(700);
  }
  document.addEventListener('click',captureAction,true);

  function schedule(delay=700){clearTimeout(timer);timer=setTimeout(run,delay);}
  async function run(){
    if(active){rerun=true;return;}active=true;
    try{
      const chatId=RPGMBSafe.chatIdFromUrl(location.href);
      const sourceUrl=chatId?canonicalSource(chatId):null;
      if(!(await permitted(chatId)))return;
      const {msgs,mode,metric,editorOpen}=read(),now=new Date().toISOString();
      const reason=editorOpen?'ChatGPT đang mở ô sửa tin nhắn; CRK tạm ngưng chụp bản nháp':!chatId?'Chưa có conversation UUID hợp lệ trong URL':!msgs.length?'Không nhận thấy khối tin nhắn':'Đã tìm thấy nội dung; bằng chứng DOM chưa chứng minh đủ toàn bộ lịch sử';
      await chrome.storage.local.set({'rpgmb-diagnostic':{version:EXT_VERSION,chatId,found:msgs.length,unknown:msgs.filter(m=>m.role==='unknown').length,method:mode,metrics:metric,assistantCandidates:assistantDiscovery(document.querySelector('main')||document.body).count,reason,time:now}});
      if(editorOpen){lastCandidate=null;schedule(1200);return;}
      if(!chatId||!msgs.length)return;
      // A stable viewport prevents streaming progress text becoming immutable RAW.
      const signature=JSON.stringify(msgs.map(m=>[m.role,m.text,m.method]));
      if(lastCandidate?.chatId!==chatId||lastCandidate?.signature!==signature){
        lastCandidate={chatId,signature,since:Date.now()};schedule(1800);return;
      }
      if(Date.now()-lastCandidate.since<1600){schedule(1700);return;}
      const inProgress=!!document.querySelector('button[aria-label*="Stop generating"],button[aria-label*="Dừng tạo"],button[data-testid*="stop-button"]');
      if(inProgress){schedule(2300);return;}
      // Web Locks serialize local RAW read/modify/write across tabs of the same chat.
      // Falls back to best effort on browsers without navigator.locks.
      const storeFrame=async()=>{
      if(!(await permitted(chatId)))return;
      // Recheck after the storage/lock await: a user may reopen Edit mid-write.
      if(inlineEditOpen(document.querySelector('main')||document.body))return;
      const key=PREFIX+chatId;
      const prev=(await chrome.storage.local.get(key))[key]||{chatId,createdAt:now,messages:[]};
      if((prev.chatId&&prev.chatId!==chatId)||(prev.sourceUrl&&RPGMBSafe.chatIdFromUrl(prev.sourceUrl)!==chatId)){
        await chrome.storage.local.set({'rpgmb-diagnostic':{version:EXT_VERSION,chatId,reason:'BLOCKED: stored chat identity conflicts with current URL. Export backup and inspect before modifying.',time:now}});
        return;
      }
      // Historical parser versions produced multiple IDs for the same displayed turn.
      // Preserve every original in immutable audit history, build a separate canonical
      // visible-turn view. Never claim DOM-only records are verified.
      const legacy=Array.isArray(prev.legacyMessages)?prev.legacyMessages:[];
      // Verified canonical turns are NOT legacy. Copying them into legacy on every
      // rescan was creating duplicate archival copies of the same UUID.
      const historical=[...legacy,...(prev.messages||[]).filter(x=>!(x?.identityVerified===true&&x.identityProof==='same-turn-native-id-role-v081'))];
      const audit=new Map();
      for(const item of historical){
        if(!item||typeof item.text!=='string')continue;
        const key=[item.id||'',item.role||'',item.text,item.position??''].join('\u001f');
        if(!audit.has(key))audit.set(key,item);
      }
      const normalize=t=>String(t||'').replace(/\r\n?/g,'\n').replace(/\u00a0/g,' ').trim();
      // Only source-native UUIDs are eligible for canonical RAW. Viewport indices
      // are reused by virtualized chat layouts and MUST NOT become stable IDs.
      const isNative=id=>/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(String(id||''));
      const canonicalMap=new Map();
      const identityConflicts=[...(prev.identityConflicts||[])];
      const proof='same-turn-native-id-role-v081';
      for(const entry of (prev.messages||[])){
        if(!isNative(entry?.id))continue;
        // Old builds sometimes attached another turn's native UUID to a message.
        // A legacy `verified:true` flag has NO authority without a new proof.
        canonicalMap.set(entry.id,entry.identityProof===proof?entry:{...entry,verified:false,identityVerified:false,identityStatus:'legacy-id-claim-unconfirmed'});
      }
      const provisional=[...(prev.provisionalObservations||[])]; // preserved as legacy evidence
      // Resolve campaign ownership AT capture time, never by later assignment.
      // A one-chat test without an assigned campaign remains unattributed.
      const ownership=(await chrome.storage.local.get([ASSIGN,CAMPAIGNS]));
      const assignedId=ownership[ASSIGN]?.[chatId];
      const campaignId=assignedId&&Object.hasOwn(ownership[CAMPAIGNS]||{},assignedId)?assignedId:null;
      const observed=await RPGMBIdentity.reconcile(prev.provisionalOccurrences,prev.viewportEvidence, msgs,now,chatId,sourceUrl,campaignId);
      // The new active layer is independent of old non-destructive forensic
      // records. Explicit UI action + corroborated viewport anchors are required
      // to prune a historical tail. A scroll/F5 has no such action.
      const hint=pendingAction?.chatId===chatId&&Date.now()-pendingAction.startedAt<10*60*1000?pendingAction:null;
      const timelineResult=CRKActiveTimeline.apply(prev.activeTimeline,msgs,{now,hint});
      const activeTimeline={...timelineResult.state,campaignId};
      const activeMetaChanged=JSON.stringify(prev.activeTimeline?.issues||[])!==JSON.stringify(activeTimeline.issues||[]);
      if(timelineResult.status==='fork')pendingAction=null;

      // A viewport with several PLAYER turns but no GM after prior GM evidence
      // is a partial mobile rendering, NOT an authoritative new conversation
      // branch. Keep the raw frame but label it so timeline projection can
      // separate it until a mixed-role viewport corroborates the sequence.
      const hasPreviousGM=(prev.provisionalOccurrences||[]).some(x=>x.role==='assistant' && x.sourceChatId===chatId);
      const partialUserOnly=hasPreviousGM && msgs.length>=2 && msgs.every(x=>x.role==='user');
      if(partialUserOnly && observed.newFrame){
        const latest=observed.frames[observed.frames.length-1];
        latest.viewportQuality='partial-user-only';
        latest.viewportWarning='Android/mobile DOM omitted assistant turns; preserve as evidence, do not promote to ordered path without mixed-role overlap.';
      }
      for(const m of msgs){
        const text=normalize(m.text);
        if(!text||!isNative(m.id))continue;
        const old=canonicalMap.get(m.id);
        if(old?.identityVerified===true&&old.role!==m.role){
          if(!identityConflicts.some(x=>x.id===m.id&&x.observedRole===m.role))identityConflicts.push({id:m.id,priorRole:old.role,priorText:old.text,observedRole:m.role,observedText:text,detectedAt:now,reason:'Proven role changed; do not overwrite native UUID automatically.'});
          continue;
        }
        // A changed text on the SAME native UUID and the SAME author role is
        // an observed version, not an identity conflict. Streaming and user edits
        // cannot be distinguished from DOM alone. Role changes still conflict.
        if(old&&old.role!==m.role && !identityConflicts.some(x=>x.id===m.id&&x.priorRole===old.role&&x.priorText===old.text)){
          identityConflicts.push({id:m.id,priorRole:old.role,priorText:old.text,
            observedRole:m.role,observedText:text,detectedAt:now,
            reason:'Previously attached UUID has a different author role; review identity.'});
        }
        const revisions=old?.role===m.role?[...(old.revisions||[])]:[];
        if(old&&old.role===m.role&&normalize(old.text)!==text && !revisions.some(r=>normalize(r.text)===normalize(old.text))){
          revisions.push({at:now,text:old.text,reason:'same-native-uuid-observed-update (streaming/edit unknown)'});
        }
        canonicalMap.set(m.id,{...m,id:m.id,text,firstSeen:old?.firstSeen||now,updatedAt:now,
          campaignId:old&&Object.hasOwn(old,'campaignId')?old.campaignId:campaignId,
          identityProof:proof,identityVerified:true,identityStatus:'native-role-confirmed',
          verified:true,provisional:false,revisions});
      }
      const canonical=[...canonicalMap.values()];
      const oldAudit=[...audit.values()];
      // Legacy snapshots are never discarded due to equal text, because a
      // distinct turn may intentionally repeat identical content.
      const uniqueAudit=new Map();
      for(const x of oldAudit){const fp=[x.id||'',x.role||'',normalize(x.text),x.position??''].join('\u001f');if(!uniqueAudit.has(fp))uniqueAudit.set(fp,x);}
      canonical.sort((a,b)=> (Number(a.sourceTurn??a.position??0)-Number(b.sourceTurn??b.position??0)) || String(a.firstSeen||'').localeCompare(String(b.firstSeen||'')));
      const title=clean(document.title.replace(/\s*[|\-]\s*ChatGPT\s*$/i,''));
      const oldCanonical=(prev.messages||[]).map(x=>[x.id,x.role,normalize(x.text),x.position,x.identityProof]);
      const newCanonical=canonical.map(x=>[x.id,x.role,x.text,x.position,x.identityProof]);
      if(JSON.stringify(oldCanonical)!==JSON.stringify(newCanonical)||title!==prev.title || prev.canonicalVersion!==2 || observed.newFrame || timelineResult.changed || activeMetaChanged || identityConflicts.length!==(prev.identityConflicts||[]).length){
        if(!(await permitted(chatId)))return;
        await chrome.storage.local.set({[key]:{...prev,canonicalVersion:2,title,sourceUrl,
          messages:canonical,activeTimeline,legacyMessages:[...uniqueAudit.values()],provisionalObservations:provisional,
          provisionalOccurrences:observed.occurrences,viewportEvidence:observed.frames,
          identityConflicts,updatedAt:now,
          integrity:{source:'visible-dom',completeHistoryVerified:false,visibleCount:msgs.length,
            confirmedNativeCount:canonical.filter(x=>x.identityVerified===true&&x.identityProof===proof).length,
            legacyNativeClaims:canonical.filter(x=>x.identityProof!==proof).length,
            provisionalOccurrenceCount:observed.occurrences.length,
            oldCollapsedObservations:provisional.length,
            identityConflictCount:identityConflicts.length,
            note:'Viewport evidence preserves identical displayed turns; only same-turn native IDs have identity proof. Cross-viewport completeness is unverified.'}}});
      }
      };
      if(navigator.locks?.request)await navigator.locks.request('rpgmb-write-'+chatId,{mode:'exclusive'},storeFrame);
      else await storeFrame();

    }catch(e){try{await chrome.storage.local.set({'rpgmb-diagnostic':{version:EXT_VERSION,reason:'Capture failed: '+String(e),time:new Date().toISOString()}});}catch{}}
    finally{active=false;if(rerun){rerun=false;schedule();}}
  }
  const observer=new MutationObserver(()=>schedule(1000));
  observer.observe(document.documentElement,{subtree:true,childList:true,characterData:true});
  document.addEventListener('visibilitychange',()=>{if(!document.hidden)schedule(200);});
  window.addEventListener('pageshow',()=>schedule(200));
  window.addEventListener('popstate',()=>schedule(200));
  // SPA route changes and suspended tabs do not require the extension popup.
  setInterval(()=>{if(location.href!==lastUrl){lastUrl=location.href;lastCandidate=null;pendingAction=null;schedule(200);}else schedule(300);},15000);
  schedule(200);
})();
