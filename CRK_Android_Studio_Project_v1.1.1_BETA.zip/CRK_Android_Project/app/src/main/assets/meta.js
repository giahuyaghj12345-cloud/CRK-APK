// RPG Memory Bridge v0.9.3: scoped, source-addressed Save metadata.
// Kept separate from RAW. No GM text is interpreted as executable code.
(function(root){
 'use strict';
 const PREFIX='rpgmb-meta-v093:';
 const TYPES=['campaign','assign','proposals'];
 const normal=x=>Array.isArray(x)?x.map(normal):x&&typeof x==='object'?Object.fromEntries(Object.keys(x).sort().map(k=>[k,normal(x[k])])):x;
 const stable=x=>JSON.stringify(normal(x));
 const campaignKey=id=>PREFIX+'campaign:'+id;
 const assignKey=id=>PREFIX+'assign:'+id;
 const proposalKey=id=>PREFIX+'proposals:'+id;
 const classify=k=>{
  if(!k.startsWith(PREFIX))return null;
  const rest=k.slice(PREFIX.length),i=rest.indexOf(':'),kind=rest.slice(0,i),id=rest.slice(i+1);
  return i>0&&TYPES.includes(kind)&&id.length>0&&id.length<=180?{kind,id}:null;
 };
 const safeId=id=>/^[\w-]{1,180}$/.test(id)&&!['__proto__','prototype','constructor'].includes(id);
 const validDayIndex=x=>{try{return x&&typeof x==='object'&&!Array.isArray(x)&&x.items&&typeof x.items==='object'&&!Array.isArray(x.items)&&Object.keys(x.items).length<=500&&Array.isArray(x.ranges)&&x.ranges.length<=10000&&Array.isArray(x.exclusions)&&x.exclusions.length<=10000&&(!x.links||(Array.isArray(x.links)&&x.links.length<=10000&&x.links.every(e=>x.items[e.dayId]&&/^[0-9a-f-]{36}$/i.test(e.chatId)&&/^[0-9a-f-]{36}$/i.test(e.messageId)&&typeof e.reason==='string'&&e.reason.length<=500)))&&JSON.stringify(x).length<=750000&&Object.entries(x.items).every(([id,d])=>safeId(id)&&d?.id===id&&typeof d.label==='string'&&d.label.length<=140&&['OPEN','CLOSED','REVISED'].includes(d.status))&&x.ranges.every(r=>safeId(r.id)&&x.items[r.dayId]&&/^[0-9a-f-]{36}$/i.test(r.chatId)&&Number.isSafeInteger(r.start)&&r.start>=1&&Number.isSafeInteger(r.end)&&r.end>=r.start&&r.end<=1000000&&(!r.startId||/^[0-9a-f-]{36}$/i.test(r.startId))&&(!r.endId||/^[0-9a-f-]{36}$/i.test(r.endId)))&&x.exclusions.every(e=>/^[0-9a-f-]{36}$/i.test(e.chatId)&&/^[0-9a-f-]{36}$/i.test(e.messageId)&&typeof e.reason==='string'&&e.reason.length<=500)}catch{return false}};
 const validCampaign=(id,c)=>safeId(id)&&c&&typeof c==='object'&&!Array.isArray(c)&&typeof c.name==='string'&&c.name.length<=256&&c.sections&&typeof c.sections==='object'&&!Array.isArray(c.sections)&&Object.entries(c.sections).every(([k,v])=>/^[a-zA-Z_]{2,40}$/.test(k)&&typeof v==='string'&&v.length<=500000)&&(!c.dayIndex||validDayIndex(c.dayIndex))&&(!c.branchIndex||(root.RPGMBBranch&&root.RPGMBBranch.validateIndex(c.branchIndex)))&&(!c.sourceEvents||(root.RPGMBSourceEvents&&root.RPGMBSourceEvents.valid(c.sourceEvents)));
 const validAssignment=(id,v)=>/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(id)&&typeof v==='string'&&safeId(v);
 const validProposals=(id,v)=>safeId(id)&&Array.isArray(v)&&v.length<=10000&&v.every(p=>p&&typeof p.id==='string'&&p.id.length<=300&&p.campaignId===id&&typeof p.status==='string'&&['pending','approved','rejected'].includes(p.status));
 const validValue=(kind,id,val)=>kind==='campaign'?validCampaign(id,val):kind==='assign'?validAssignment(id,val):validProposals(id,val);
 const validRecord=(key,p)=>{
  const k=classify(key);return !!(k&&p&&p.format==='rpgmb-scoped-meta-v093'&&p.kind===k.kind&&p.id===k.id&&typeof p.head==='string'&&/^[0-9a-f]{64}$/.test(p.head)&&Array.isArray(p.ancestors)&&p.ancestors.length<=128&&p.ancestors.every(a=>typeof a==='string'&&/^[0-9a-f]{64}$/.test(a))&&validValue(k.kind,k.id,p.value));
 };
 async function hash(val){const data=new TextEncoder().encode(stable(val)),buf=await crypto.subtle.digest('SHA-256',data);return Array.from(new Uint8Array(buf),b=>b.toString(16).padStart(2,'0')).join('');}
 async function prepare(kind,id,value,old){
  if(!TYPES.includes(kind)||!validValue(kind,id,value))throw Error('Metadata không hợp lệ: '+kind+' / '+id);
  const h=await hash(value);
  if(old&&old.head===h&&stable(old.value)===stable(value))return old;
  const previous=old?.head&&old.head!==h?[old.head,...(old.ancestors||[])]:[];
  const ancestors=[...new Set(previous.filter(x=>/^[0-9a-f]{64}$/.test(x)))].slice(0,128);
  return {format:'rpgmb-scoped-meta-v093',kind,id,value:structuredClone(value),head:h,ancestors,updatedAt:new Date().toISOString()};
 }
 function lineage(local,remote){
  if(local.head===remote.head&&stable(local.value)===stable(remote.value))return 'equal';
  if(local.ancestors?.includes(remote.head))return 'keep-local';
  if(remote.ancestors?.includes(local.head))return 'take-remote';
  return 'conflict';
 }
 const api={PREFIX,safeId,campaignKey,assignKey,proposalKey,classify,validRecord,validValue,hash,prepare,lineage,stable};
 root.RPGMBMeta=api;
})(typeof globalThis==='undefined'?self:globalThis);
