// v0.9.38. Follow explicitly selected local branch after status-only or prefix-streamed GM bubbles.
// This module NEVER changes stored evidence, never selects canon by timestamp,
// never merges alternate PLAYER edits, and refuses a GM Retry without proof.
(function(root){
'use strict';
const API=root.RPGMBTimeline;if(!API)return;
const prior=API.project;
const norm=s=>String(s||'').replace(/\s+/g,' ').trim();
// Progress bubbles may start with an acknowledgement (e.g. "Đúng, ... Mình sẽ...")
// rather than the first-person phrase itself. Require a concrete forward-looking
// verb, keep the message short, and never treat length alone as a reason to drop
// a genuine RPG response. Full GM narratives remain untouched.
const planning=t=>{const s=norm(t);return s.length>=35&&s.length<=950&&(
 /^(?:Mình sẽ|Tôi sẽ|Tôi đang|Đã xác định|Đã xử lý)(?:\s|$)/i.test(s)||
 /^(?:Đúng|Được|Rõ)[,.!]?\s.{0,350}(?:mình sẽ|tôi sẽ|tôi đang)/i.test(s)
);};
const isFinishedGM=t=>{const s=norm(t);return s.length>=650&&!planning(s);};
function bridge(chat,result,options,forced=null){
 // A chosen, local branch is required. This never overrides the safe common
 // prefix of a campaign where the user did not identify the RPG branch.
 if(!options?.selectedPathId||result?.branchChoice!==options.selectedPathId||
    !Array.isArray(result.turns)||result.turns.length<8)return result;
 const all=(chat?.provisionalOccurrences||[]).filter(o=>o?.observationId&&
   o.sourceChatId===chat.chatId&&o.sourceUrl===chat.sourceUrl&&
   ['user','assistant'].includes(o.role));
 const byId=new Map(all.map(o=>[o.observationId,o]));
 const frames=(chat?.viewportEvidence||[]).filter(f=>f?.chatId===chat.chatId&&
   f?.sourceUrl===chat.sourceUrl&&Array.isArray(f.turns)&&
   f.turns.every(t=>byId.has(t.observationId)));
 const get=id=>byId.get(id), role=id=>get(id)?.role;
 const textCache=new Map(all.map(o=>[o.observationId,norm(o.text)]));
 const txt=id=>textCache.get(id)||'',eq=(a,b)=>role(a)===role(b)&&txt(a)===txt(b);
 const ids=result.turns.map(t=>t.observationId).filter(id=>byId.has(id));
 if(forced&&ids[forced.index]&&role(ids[forced.index])==='assistant'&&
    role(forced.id)==='assistant'&&isFinishedGM(txt(forced.id)))ids[forced.index]=forced.id;
 let appendCount=0,replacedStatus=0,expandedGM=0,identicalReobserved=0,stagedStatus=0;
 // Weighted monotonic alignment local to the last ~14 chosen turns. It cannot
 // jump over a historic edit because a candidate must touch the actual tail.
 function match(frame){
  const start=Math.max(0,ids.length-22),a=frame,b=ids.slice(start);
  const m=a.length,n=b.length,dp=Array.from({length:m+1},()=>new Int32Array(n+1));
  const weight=id=>role(id)==='assistant'&&txt(id).length>300?100:role(id)==='user'&&txt(id).length>12?12:2;
  for(let i=m-1;i>=0;i--)for(let j=n-1;j>=0;j--){
   const pair=eq(a[i],b[j])?weight(a[i])+dp[i+1][j+1]:-1;
   dp[i][j]=Math.max(pair,dp[i+1][j],dp[i][j+1]);
  }
  const matches=[];let i=0,j=0;
  while(i<m&&j<n){const pair=eq(a[i],b[j])?weight(a[i])+dp[i+1][j+1]:-1;
   if(pair>0&&pair>=dp[i+1][j]&&pair>=dp[i][j+1]){
    matches.push({i,j:j+start,id:a[i]});i++;j++;
   }else if(dp[i+1][j]>dp[i][j+1])i++;else j++;
  }
  const long=new Set(matches.filter(x=>role(x.id)==='assistant'&&txt(x.id).length>=300).map(x=>txt(x.id)));
  return {matches,long:long.size};
 }
 const append=(chunk,frame)=>{
  // A short status has no narrative value until its complete answer exists.
  // Preserve it in JSON but avoid poisoning selected TXT with a false GM turn.
  const statuses=new Set();for(let k=0;k<chunk.length;k++){
   const id=chunk[k];if(role(id)!=='assistant')continue;
   const pos=frame.indexOf(id),next=frame[pos+1],body=txt(id);
   // ChatGPT can expose non-narrative mini-GM bubbles that do not start
   // with "Mình sẽ": e.g. "Tóm tắt cảnh đang triển khai". If the same
   // viewport puts a complete, much longer GM answer immediately after it,
   // that mini bubble is auxiliary, not another RPG turn. Require adjacency.
   const adjacentComplete=pos>=0&&next&&role(next)==='assistant'&&
     isFinishedGM(txt(next))&&body.length<650;
   if(adjacentComplete||(planning(body)&&k===chunk.length-1))statuses.add(id);
  }
  for(const id of chunk){if(statuses.has(id)){stagedStatus++;continue;}
   if(ids.some(prev=>prev===id))continue;
   if(ids.length&&eq(ids.at(-1),id)){identicalReobserved++;continue;}
   const old=get(ids.at(-1)),fresh=get(id);
   if(old?.role==='assistant'&&fresh?.role==='assistant'){
    const oldText=txt(ids.at(-1)),newText=txt(id);
    if(oldText.length>=40&&newText.startsWith(oldText)&&newText.length>oldText.length+20){
      ids[ids.length-1]=id;replacedStatus++;continue;
    }
    // Two full GM replies to one PLAYER are a Retry/variant, not two turns.
    // Never auto-append them to the selected canon path.
    if(isFinishedGM(oldText)&&isFinishedGM(newText))continue;
   }
   ids.push(id);appendCount++;
  }
 };
 // The selected path may end with a status text (or a streaming status suffix)
 // that was mistakenly counted as GM #218. Do NOT treat it as final GM.
 // Replace only with the assistant that directly follows the same PLAYER
 // in a viewport with >=2 substantial unique matched GM anchors.
 for(const frame of frames){
  const incoming=frame.turns.map(t=>t.observationId);if(!incoming.length)continue;
  const {matches,long}=match(incoming);if(long<2||matches.length<4)continue;
  const last=matches.at(-1);if(!last)continue;
  if(last.j===ids.length-2&&role(ids.at(-1))==='assistant'&&
    planning(txt(ids.at(-1)))&&role(ids.at(-2))==='user'){
   const next=incoming[last.i+1];
   if(role(last.id)==='user'&&next&&role(next)==='assistant'&&
       isFinishedGM(txt(next))&&last.j===ids.length-2){
    ids[ids.length-1]=next;replacedStatus++;
    append(incoming.slice(last.i+2),incoming);continue;
   }
  }
  // v0.9.37: The previously selected GM can be a partially streamed
  // narrative (e.g. 2,093 chars) rather than a short progress bubble. In the
  // next viewport, a LONGER version with the EXACT same substantial prefix
  // is a completion of the same GM slot, not a Retry or another RPG turn.
  // Demand the same immediately preceding PLAYER, multiple independent GM
  // anchors and strict whole-prefix expansion. No fuzzy matching here.
  if(last.j===ids.length-2&&last.i<incoming.length-1&&
     role(last.id)==='user'&&role(ids.at(-2))==='user'&&
     role(ids.at(-1))==='assistant'){
    const next=incoming[last.i+1],priorId=ids.at(-1);
    const shortGM=txt(priorId),fullGM=txt(next);
    const markedExpansion=get(priorId)?.supersededBy===next&&
      get(priorId)?.supersessionReason==='same-slot-prefix-expansion';
    if(role(next)==='assistant'&&(shortGM.length>=300||markedExpansion)&&
       fullGM.length>shortGM.length+250&&
       fullGM.startsWith(shortGM)&&isFinishedGM(fullGM)){
      ids[ids.length-1]=next;
      expandedGM++;
      append(incoming.slice(last.i+2),incoming);
      continue;
    }
  }
  if(last.j!==ids.length-1||last.i===incoming.length-1)continue;
  // Last observed identity must match the exact candidate tail (same text,
  // role), and more than a bare numeric choice must establish the offset.
  if(!eq(last.id,ids.at(-1)))continue;
  append(incoming.slice(last.i+1),incoming);
 }
 const out=ids.map(id=>get(id)).filter(Boolean);
 const chosen=new Set(ids);
 const modified=!!forced||out.length!==result.turns.length||out.some((o,i)=>o.observationId!==result.turns[i]?.observationId);
 if(!modified)return result;
 const optionsList=(result.branchOptions||[]).map(b=>b.id===options.selectedPathId?
   {...b,count:out.length,lastText:out.at(-1)?.text?.slice(0,180)||''}:b);
 return {...result,turns:out,branchOptions:optionsList,
   unused:all.filter(o=>!chosen.has(o.observationId)),
   selectedTailFollow:{appended:appendCount,replacedStatus,expandedGM,identicalReobserved,stagedStatus,
    method:'selected-path-long-GM-anchored-viewports',verified:false},
   issues:[...(result.issues||[]),{reason:'selected-branch-tail-follow-not-native-verified',
    appended:appendCount,replacedStatus,expandedGM}],
   disclaimer:'Selected DOM-evidence path only; native ChatGPT active branch remains unverified.'};
}
// A completed GM Retry after the selected path may be visible with subsequent
// PLAYER continuation. It is NOT automatically canon: offer a separate locally
// selectable candidate, rather than silently overwrite a full GM answer.
function retryVariants(chat,path,parentId){
 const all=(chat?.provisionalOccurrences||[]),byId=new Map(all.map(o=>[o.observationId,o]));
 const frames=(chat?.viewportEvidence||[]).filter(f=>f?.chatId===chat.chatId&&f?.sourceUrl===chat.sourceUrl&&
  Array.isArray(f.turns)&&f.turns.every(t=>byId.has(t.observationId)));
 const arr=path.turns, candidates=[];
 const cache=new Map(all.filter(o=>o?.observationId).map(o=>[o.observationId,norm(o.text)]));
 const t=id=>cache.get(id)||'',role=id=>byId.get(id)?.role;
 const futureGM=new Set();
 for(const f of frames){const run=f.turns.map(x=>x.observationId);
   for(let k=0;k<run.length-2;k++)if(role(run[k])==='assistant'&&
      role(run[k+1])==='user'&&role(run[k+2])==='assistant')futureGM.add(t(run[k]));
 }
 const eq=(a,b)=>role(a)===role(b)&&t(a)===t(b);
 const hash=s=>{let h=2166136261;for(const c of s){h^=c.charCodeAt(0);h=Math.imul(h,16777619);}return(h>>>0).toString(36);};
 // Consider only the last 8 GM turns. Earlier Edit/Retry decisions belong to
 // the original multi-edit chooser and must not be overwritten by this bridge.
 for(let j=Math.max(1,arr.length-16);j<arr.length;j++){
  const old=arr[j],prev=arr[j-1];
  if(!old||!prev||old.role!=='assistant'||prev.role!=='user'||
    !isFinishedGM(old.text)||norm(prev.text).length<20)continue;
  const oldId=old.observationId,prevId=prev.observationId;
  const earlier=new Set(arr.slice(Math.max(0,j-18),j-1).filter(x=>x.role==='assistant'&&norm(x.text).length>=300).map(x=>norm(x.text)));
  for(const f of frames){const ids=f.turns.map(x=>x.observationId);
   for(let i=0;i<ids.length-1;i++){
    if(!eq(ids[i],prevId)||role(ids[i+1])!=='assistant')continue;
    const proposed=ids[i+1];if(eq(proposed,oldId)||!isFinishedGM(t(proposed)))continue;
    const long=new Set(ids.slice(0,i).filter(id=>role(id)==='assistant'&&t(id).length>=300&&
      earlier.has(t(id))).map(t));
    if(long.size<2)continue;
    // Following PLAYER & GM must have been observed consecutively after this
    // specific alternate reply. This distinguishes real path continuation
    // from an uncommitted short-lived re-render at the same GM position.
    const follow=futureGM.has(t(proposed));
    if(!follow)continue;
    const id='retry:'+String(j+1)+':'+hash(t(proposed))+'@'+parentId;
    if(candidates.some(x=>x.id===id))continue;
    candidates.push({id,parentId,index:j,replacement:byId.get(proposed),
     label:'GM Thử lại tại #'+(j+1)+' (cần tự đối chiếu)',
     kind:'retry',pivot:j,firstText:byId.get(proposed)?.text?.slice(0,180)||'',
     lastText:byId.get(proposed)?.text?.slice(0,180)||''});
   }
  }
 }
 return candidates.slice(0,4);
}
// Discover nested Retry options without selecting any branch. Previously the
// menu included a Retry only when that Retry was ALREADY selected or its parent
// Edit branch was active. Losing a local choice therefore made a captured 304
// turn candidate disappear from the menu, although JSON still held the RAW.
// Use cached internal candidate paths from multi-edit rather than re-projecting
// the complete chat (which is expensive on mobile).
function discoverUnselectedRetries(chat,result){
 const candidates=(result.branchCandidatePaths||[]).filter(p=>p.kind==='new'&&p.ids?.length>=10)
   .sort((a,b)=>b.ids.length-a.ids.length).slice(0,3);
 if(!candidates.length)return result;
 const byId=new Map((chat?.provisionalOccurrences||[]).map(o=>[o.observationId,o]));
 const known=new Set((result.branchOptions||[]).map(x=>x.id));
 const additions=[];
 const branchOptions=(result.branchOptions||[]).map(o=>({...o}));
 let revisedCounts=false;
 for(const parent of candidates){
  const turns=parent.ids.map(id=>byId.get(id)).filter(Boolean);
  if(turns.length!==parent.ids.length)continue;
  const base={...result,turns,branchChoice:parent.id};
  const parentOptions={selectedPathId:parent.id};
  const followed=bridge(chat,base,parentOptions);
  // Refresh the parent count even in the unselected menu if the selected-path
  // tail bridge can recover turns. This is a candidate preview, not a choice.
  const main=branchOptions.find(x=>x.id===parent.id);
  if(main&&followed.turns.length>main.count){
   revisedCounts=true;
   main.count=followed.turns.length;
   main.lastText=followed.turns.at(-1)?.text?.slice(0,180)||main.lastText;
  }
  for(const variant of retryVariants(chat,followed,parent.id)){
   if(known.has(variant.id))continue;
   const rebuilt=bridge(chat,followed,parentOptions,{index:variant.index,id:variant.replacement.observationId});
   if(rebuilt.turns.length<=followed.turns.length)continue;
   known.add(variant.id);
   additions.push({id:variant.id,kind:'retry',pivot:variant.pivot,
    label:variant.label,count:rebuilt.turns.length,firstText:variant.firstText,
    lastText:rebuilt.turns.at(-1)?.text?.slice(0,180)||'',parentId:parent.id,
    needsManualChoice:true});
  }
 }
 if(!additions.length&&!revisedCounts)return result;
 return {...result,branchOptions:[...branchOptions,...additions],
  issues:additions.length?[...(result.issues||[]),{reason:'unselected-nested-retries-visible',count:additions.length}]:result.issues};
}
API.project=function(chat,options={}){
 const requested=options.selectedPathId||'';
 const parentId=requested.startsWith('retry:')&&requested.includes('@')?
   requested.slice(requested.indexOf('@')+1):requested;
 const parentOptions={...options,selectedPathId:parentId};
 const base=prior(chat,parentOptions);
 try{
  const followed=bridge(chat,base,parentOptions);
  if(!parentId||followed.branchChoice!==parentId)return discoverUnselectedRetries(chat,followed);
  const variants=retryVariants(chat,followed,parentId);
  if(!variants.length)return followed;
  const details=variants.map(v=>{
   const rebuilt=bridge(chat,followed,parentOptions,{index:v.index,id:v.replacement.observationId});
   return {...v,turns:rebuilt.turns,count:rebuilt.turns.length,lastText:rebuilt.turns.at(-1)?.text?.slice(0,180)||''};
  });
  const chosen=details.find(v=>v.id===requested);
  const candidate=chosen?bridge(chat,followed,parentOptions,{index:chosen.index,id:chosen.replacement.observationId}):followed;
  // The parent Edit branch does NOT inherit the Retry length when a Retry is
  // selected. Keep separate, accurate option counts (e.g. parent 232, Retry 304).
  const existing=(followed.branchOptions||[]).filter(v=>!v.id.startsWith('retry:'));
  return {...candidate,branchChoice:chosen?.id||parentId,
   branchOptions:[...existing,...details.map(({turns,replacement,parentId,index,...v})=>v)],
   retroFork:candidate.retroFork?{...candidate.retroFork,
    notice:chosen?'Đã chọn GM Thử lại từ chứng cứ DOM; chưa xác minh UUID/nhánh hiện hành.':
    candidate.retroFork.notice}:candidate.retroFork,
   issues:[...(candidate.issues||[]),{reason:'gm-retry-branch-requires-manual-selection',options:details.length}]};
 }catch(e){
  return {...base,issues:[...(base.issues||[]),{reason:'tail-follow-error',detail:String(e?.message||e)}]};
 }
};
API.tailFollowPatchVersion='0.9.38';
})(typeof globalThis!=='undefined'?globalThis:this);
