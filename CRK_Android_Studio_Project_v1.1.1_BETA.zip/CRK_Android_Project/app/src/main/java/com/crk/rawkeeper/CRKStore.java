package com.crk.rawkeeper;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.content.ContentValues;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.*;

/** JSON values are stored verbatim in SQLite, without the Android SharedPreferences size limit. */
final class CRKStore extends SQLiteOpenHelper {
    private static final String TABLE = "kv";
    CRKStore(Context ctx) { super(ctx, "crk_store_v1.db", null, 1); }
    @Override public void onCreate(SQLiteDatabase db) { db.execSQL("CREATE TABLE kv(k TEXT PRIMARY KEY, v TEXT NOT NULL)"); }
    @Override public void onUpgrade(SQLiteDatabase db, int oldVer, int newVer) { /* no destructive migration */ }

    synchronized JSONObject get(String encodedKeys, boolean restricted) {
        JSONObject result = new JSONObject();
        try {
            Object wanted = new org.json.JSONTokener(encodedKeys).nextValue();
            if (wanted == JSONObject.NULL) wanted = null;
            if (restricted && wanted == null) return result;
            Map<String,Object> keys = new LinkedHashMap<>();
            if (wanted == null) {
                try (Cursor cur = getReadableDatabase().rawQuery("SELECT k FROM kv", null)) {
                    while (cur.moveToNext()) keys.put(cur.getString(0), null);
                }
            } else if (wanted instanceof JSONArray) {
                JSONArray arr=(JSONArray)wanted;
                for(int i=0;i<arr.length();i++) keys.put(arr.optString(i),null);
            } else if (wanted instanceof JSONObject) {
                JSONObject obj=(JSONObject)wanted;
                for(Iterator<String> it=obj.keys();it.hasNext();) {String k=it.next();keys.put(k,obj.opt(k));}
            } else {keys.put(String.valueOf(wanted),null);}
            for(Map.Entry<String,Object> entry:keys.entrySet()) {
                String k=entry.getKey();
                if (restricted && !isContentKey(k)) continue;
                try(Cursor cur=getReadableDatabase().rawQuery("SELECT v FROM kv WHERE k=?",new String[]{k})) {
                    if(cur.moveToNext()) result.put(k,new org.json.JSONTokener(cur.getString(0)).nextValue());
                    else if(entry.getValue()!=null) result.put(k,entry.getValue());
                }
            }
        } catch(Exception e) {android.util.Log.w("CRKStore","get",e);}
        return result;
    }
    synchronized JSONObject set(String encodedValues,boolean restricted) throws Exception {
        JSONObject values=new JSONObject(encodedValues),changes=new JSONObject();
        SQLiteDatabase db=getWritableDatabase();
        db.beginTransaction();
        try {
            for(Iterator<String> it=values.keys();it.hasNext();) {
                String key=it.next();
                if(restricted && !isContentWritableKey(key)) continue;
                Object updated=values.get(key), old=JSONObject.NULL;
                try(Cursor c=db.rawQuery("SELECT v FROM kv WHERE k=?",new String[]{key})) {
                    if(c.moveToNext()) old=new org.json.JSONTokener(c.getString(0)).nextValue();
                }
                String updatedText=jsonValue(updated);
                if(!Objects.equals(jsonValue(old),updatedText)) {
                    ContentValues row=new ContentValues();row.put("k",key);row.put("v",updatedText);
                    db.insertWithOnConflict(TABLE,null,row,SQLiteDatabase.CONFLICT_REPLACE);
                    JSONObject diff=new JSONObject().put("newValue",updated);
                    if(old!=JSONObject.NULL) diff.put("oldValue",old);
                    changes.put(key,diff);
                }
            }
            db.setTransactionSuccessful();
        } finally {db.endTransaction();}
        return changes;
    }
    synchronized JSONObject remove(String keysJson,boolean restricted) throws Exception {
        Object obj=new org.json.JSONTokener(keysJson).nextValue();
        JSONArray keys=obj instanceof JSONArray?(JSONArray)obj:new JSONArray().put(obj);
        JSONObject changes=new JSONObject();SQLiteDatabase db=getWritableDatabase();
        db.beginTransaction();try {
            for(int i=0;i<keys.length();i++){
                String k=keys.optString(i);if(restricted&&!isContentWritableKey(k))continue;
                try(Cursor c=db.rawQuery("SELECT v FROM kv WHERE k=?",new String[]{k})){
                    if(c.moveToNext()) changes.put(k,new JSONObject().put("oldValue",new org.json.JSONTokener(c.getString(0)).nextValue()));
                }
                db.delete(TABLE,"k=?",new String[]{k});
            }
            db.setTransactionSuccessful();
        }finally{db.endTransaction();}
        return changes;
    }
    synchronized JSONObject clear(boolean restricted) throws Exception {
        JSONObject changes = new JSONObject();SQLiteDatabase db=getWritableDatabase();
        db.beginTransaction();try(Cursor cur=db.rawQuery("SELECT k,v FROM kv",null)) {
            while(cur.moveToNext()){
                String k=cur.getString(0);if(restricted&&!isContentWritableKey(k))continue;
                changes.put(k,new JSONObject().put("oldValue",new org.json.JSONTokener(cur.getString(1)).nextValue()));
                db.delete(TABLE,"k=?",new String[]{k});
            }
            db.setTransactionSuccessful();
        }finally{db.endTransaction();}
        return changes;
    }
    private static String jsonValue(Object v) { String arr=new JSONArray().put(v).toString(); return arr.substring(1,arr.length()-1); }
    static boolean isContentKey(String k) {
        return isContentWritableKey(k)
            || k.equals("rpgmb-capture-paused-v091") || k.equals("rpgmb-fresh-test-v091")
            || k.equals("rpgmb-assign-v04") || k.equals("rpgmb-campaigns-v04");
    }
    static boolean isContentWritableKey(String k) {
        return k.startsWith("rpgmb:") || k.startsWith("rpgmb-ledger-v075:")
            || k.equals("rpgmb-diagnostic");
    }
}
