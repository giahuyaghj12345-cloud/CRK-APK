package com.crk.rawkeeper;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Build;
import android.content.Intent;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.ContentValues;
import android.content.ActivityNotFoundException;
import android.provider.MediaStore;
import android.os.Environment;
import android.net.Uri;
import android.graphics.Color;
import android.view.View;
import android.view.ViewGroup;
import android.view.Gravity;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.Toast;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.ValueCallback;
import android.util.Base64;
import android.util.Log;
import org.json.JSONObject;
import java.io.InputStream;
import java.io.ByteArrayOutputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.Map;
import java.util.HashMap;
import java.util.Locale;

/** Android WebView adaptation of CRK v1.1.1 beta; foreground-only cloud worker. */
public class MainActivity extends Activity {
    private static final String ASSET_HOST = "appassets.androidplatform.net";
    private static final String ASSET_PREFIX = "https://appassets.androidplatform.net/assets/";
    private static final int FILE_PICKER_REQUEST=4904;
    private static final String TAG="CRKAndroid";
    private final Handler ui=new Handler(Looper.getMainLooper());
    private final Map<String,WebView> inFlight=new HashMap<>();
    private final Map<String,Alarm> alarms=new HashMap<>();
    private WebView chat, popup, cloud;
    private Button chatButton, crkButton;
    private FrameLayout frame;
    private ValueCallback<Uri[]> uploadCallback;
    private CRKStore store;
    private volatile String chatUrl="https://chatgpt.com/";
    private String contentScript;
    private boolean cloudReady=false;

    @Override public void onCreate(Bundle state){
        super.onCreate(state);
        store=new CRKStore(this);
        getWindow().setStatusBarColor(Color.rgb(17,27,42));
        getWindow().setNavigationBarColor(Color.rgb(17,27,42));
        try {
            StringBuilder b=new StringBuilder();
            for(String file:new String[]{"bridge.js","safe.js","identity.js","ledger.js","active-timeline.js","capture.js"})
                b.append("\n;\n").append(load(file));
            contentScript=b.toString();
        }catch(Exception e) {contentScript=""; Log.e(TAG,"Failed to load CRK capture",e);}
        LinearLayout shell=new LinearLayout(this);shell.setOrientation(LinearLayout.VERTICAL);
        shell.setBackgroundColor(Color.rgb(11,17,29));
        frame=new FrameLayout(this);
        LinearLayout bar=new LinearLayout(this);bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setPadding(dp(5),dp(3),dp(5),dp(3));bar.setBackgroundColor(Color.rgb(17,27,42));
        chatButton=toolbar("🌐 ChatGPT",()->showChat());
        crkButton=toolbar("📦 CRK",()->showCRK());
        Button reload=toolbar("↻",()->{if(chat.getVisibility()==View.VISIBLE)chat.reload();else popup.reload();});
        Button back=toolbar("‹",()->{if(chat.getVisibility()==View.VISIBLE&&chat.canGoBack())chat.goBack();});
        bar.addView(chatButton,new LinearLayout.LayoutParams(0,dp(48),3));
        bar.addView(crkButton,new LinearLayout.LayoutParams(0,dp(48),2));
        bar.addView(reload,new LinearLayout.LayoutParams(dp(53),dp(48)));
        bar.addView(back,new LinearLayout.LayoutParams(dp(53),dp(48)));
        shell.addView(bar,new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,dp(54)));
        shell.addView(frame,new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,0,1));
        setContentView(shell);

        cloud=web(false);cloud.addJavascriptInterface(new Bridge(false),"AndroidCRK");
        cloud.setWebViewClient(assetClient(true));
        frame.addView(cloud,new FrameLayout.LayoutParams(dp(1),dp(1),Gravity.TOP|Gravity.LEFT));
        cloud.setAlpha(0.01f); // Keep JS worker alive while app is visible; no background guarantee.

        popup=web(false);popup.addJavascriptInterface(new Bridge(false),"AndroidCRK");
        popup.setWebViewClient(assetClient(false));
        popup.setWebChromeClient(pickerClient());
        frame.addView(popup,new FrameLayout.LayoutParams(-1,-1));

        chat=web(true);chat.addJavascriptInterface(new Bridge(true),"AndroidCRK");
        chat.setWebViewClient(chatClient());
        chat.setWebChromeClient(pickerClient());
        frame.addView(chat,new FrameLayout.LayoutParams(-1,-1));
        cloud.loadUrl(ASSET_PREFIX+"cloud-host.html");
        popup.loadUrl(ASSET_PREFIX+"popup.html");
        chat.loadUrl("https://chatgpt.com/");
        showChat();
    }
    private Button toolbar(String title,Runnable action){
        Button b=new Button(this);b.setText(title);b.setAllCaps(false);b.setTextSize(13);
        b.setTextColor(Color.WHITE);b.setBackgroundColor(Color.rgb(28,47,69));
        b.setOnClickListener(v->action.run());return b;
    }
    private int dp(int n){return (int)(n*getResources().getDisplayMetrics().density+0.5f);}
    private void showChat(){chat.setVisibility(View.VISIBLE);popup.setVisibility(View.GONE);chatButton.setAlpha(1);crkButton.setAlpha(0.65f);}
    private void showCRK(){
        // ChatGPT is a SPA: history.pushState may change its URL without onPageFinished.
        chat.evaluateJavascript("window.location.href",value->{
            try{Object url=new org.json.JSONTokener(value).nextValue();chatUrl=String.valueOf(url);}
            catch(Exception e){Log.w(TAG,"active chat URL",e);}
        });
        chat.setVisibility(View.GONE);popup.setVisibility(View.VISIBLE);
        chatButton.setAlpha(0.65f);crkButton.setAlpha(1);
    }
    private WebView web(boolean remote){
        WebView w=new WebView(this);WebSettings s=w.getSettings();
        s.setJavaScriptEnabled(true);s.setDomStorageEnabled(true);s.setDatabaseEnabled(true);
        s.setAllowFileAccess(false);s.setAllowContentAccess(true);s.setJavaScriptCanOpenWindowsAutomatically(false);
        s.setSupportMultipleWindows(false);s.setMediaPlaybackRequiresUserGesture(true);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        s.setUserAgentString(s.getUserAgentString());
        if(Build.VERSION.SDK_INT>=26) s.setSafeBrowsingEnabled(true);
        w.setBackgroundColor(remote?Color.WHITE:Color.rgb(11,17,29));
        return w;
    }
    private WebViewClient assetClient(boolean isCloud){return new WebViewClient(){
        @Override public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request){
            Uri u=request.getUrl();
            if(!"https".equals(u.getScheme())||!ASSET_HOST.equals(u.getHost())||!u.getPath().startsWith("/assets/"))return null;
            String path=u.getPath().substring("/assets/".length());
            if(!path.matches("[A-Za-z0-9._-]+")||path.startsWith("."))return null;
            try{
                InputStream in=getAssets().open(path);
                String mime=path.endsWith(".html")?"text/html":path.endsWith(".css")?"text/css":path.endsWith(".js")?"application/javascript":"application/octet-stream";
                return new WebResourceResponse(mime,"UTF-8",in);
            }catch(Exception e){return null;}
        }
        @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest req){
            Uri url=req.getUrl();
            if("https".equals(url.getScheme())&&ASSET_HOST.equals(url.getHost())&&url.getPath().startsWith("/assets/"))return false;
            openExternal(url);return true;
        }
        @Override public void onPageFinished(WebView v,String url){
            if(isCloud){ cloudReady=true; }
        }
    };}
    private WebViewClient chatClient(){return new WebViewClient(){
        @Override public boolean shouldOverrideUrlLoading(WebView w,WebResourceRequest request){
            Uri url=request.getUrl();String host=url.getHost()==null?"":url.getHost().toLowerCase(Locale.ROOT);
            if("https".equals(url.getScheme())&&(host.equals("chatgpt.com")||host.equals("auth.openai.com")||host.equals("login.openai.com"))){
                if(request.isForMainFrame())chatUrl=url.toString();return false;
            }
            if(request.isForMainFrame()){openExternal(url);return true;}
            return false;
        }
        @Override public void onPageFinished(WebView w,String url){
            chatUrl=url;
            if(url.startsWith("https://chatgpt.com/")&&!contentScript.isEmpty()) {
                w.evaluateJavascript(contentScript,null);
            }
        }
    };}
    private void openExternal(Uri url){
        try{ if(!"https".equals(url.getScheme()))return;
            startActivity(new Intent(Intent.ACTION_VIEW,url));
        }catch(ActivityNotFoundException e){Toast.makeText(this,"Không có trình duyệt mở liên kết",Toast.LENGTH_SHORT).show();}
    }
    private WebChromeClient pickerClient(){return new WebChromeClient(){
        @Override public boolean onShowFileChooser(WebView v,ValueCallback<Uri[]> callback,FileChooserParams params){
            if(uploadCallback!=null)uploadCallback.onReceiveValue(null);
            uploadCallback=callback;
            try{
                Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("*/*");i.addCategory(Intent.CATEGORY_OPENABLE);
                i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                startActivityForResult(i,FILE_PICKER_REQUEST);return true;
            }catch(Exception e){uploadCallback=null;return false;}
        }
    };}
    @Override protected void onActivityResult(int request,int result,Intent data){
        super.onActivityResult(request,result,data);
        if(request==FILE_PICKER_REQUEST&&uploadCallback!=null){
            Uri[] uris=(result==RESULT_OK&&data!=null&&data.getData()!=null)?new Uri[]{data.getData()}:null;
            uploadCallback.onReceiveValue(uris);uploadCallback=null;
        }
    }
    private void js(WebView w,String expression){ if(w!=null)ui.post(()->w.evaluateJavascript(expression,null)); }
    private void publish(JSONObject changes){
        if(changes.length()==0)return;
        String expr="window.__crkStorageChanged&&window.__crkStorageChanged("+JSONObject.quote(changes.toString())+");";
        js(chat,expr);js(popup,expr);js(cloud,expr);
    }
    private static final class Alarm {
        final String name;final long interval;
        final long due;
        final Runnable callback;
        Alarm(String name,long interval,long due,Runnable callback){this.name=name;this.interval=interval;this.due=due;this.callback=callback;}
    }
    private void alarmSet(String name,String encoded){
        alarmClear(name);
        try{
            JSONObject opts=new JSONObject(encoded);
            double first=opts.optDouble("delayInMinutes",opts.optDouble("periodInMinutes",1));
            long delay=Math.max(1000L,(long)(Math.max(0.02,first)*60000));
            long repeat=opts.has("periodInMinutes")?Math.max(60_000L,(long)(opts.optDouble("periodInMinutes")*60000)):0;
            Runnable job=new Runnable(){@Override public void run(){
                if(!alarms.containsKey(name))return;
                js(cloud,"window.__crkFireAlarm&&window.__crkFireAlarm("+JSONObject.quote(name)+");");
                if(repeat>0)ui.postDelayed(this,repeat);else alarms.remove(name);
            }};
            alarms.put(name,new Alarm(name,repeat,System.currentTimeMillis()+delay,job));
            ui.postDelayed(job,delay);
        }catch(Exception e){Log.w(TAG,"alarm create",e);}
    }
    private void alarmClear(String name){ Alarm a=alarms.remove(name);if(a!=null)ui.removeCallbacks(a.callback); }
    @Override public void onBackPressed(){
        if(chat.getVisibility()==View.VISIBLE&&chat.canGoBack())chat.goBack();
        else if(popup.getVisibility()==View.VISIBLE)showChat();
        else super.onBackPressed();
    }
    @Override protected void onDestroy(){
        for(Alarm a:alarms.values())ui.removeCallbacks(a.callback);alarms.clear();
        if(chat!=null)chat.destroy();if(popup!=null)popup.destroy();if(cloud!=null)cloud.destroy();
        store.close();super.onDestroy();
    }
    private final class Bridge {
        private final boolean restricted;
        Bridge(boolean restricted){this.restricted=restricted;}
        private boolean allowed(){return !restricted||chatUrl.startsWith("https://chatgpt.com/");}
        @JavascriptInterface public String getStore(String keys){return allowed()?store.get(keys,restricted).toString():"{}";}
        @JavascriptInterface public void setStore(String encoded){if(!allowed())return;
            try{publish(store.set(encoded,restricted));}catch(Exception e){Log.w(TAG,"set",e);}
        }
        @JavascriptInterface public void removeStore(String encoded){if(!allowed())return;
            try{publish(store.remove(encoded,restricted));}catch(Exception e){Log.w(TAG,"remove",e);}
        }
        @JavascriptInterface public void clearStore(){if(!allowed())return;
            try{publish(store.clear(restricted));}catch(Exception e){Log.w(TAG,"clear",e);}
        }
        @JavascriptInterface public String getActiveTab(){
            try{return new JSONObject().put("id",1).put("url",chatUrl).toString();}
            catch(Exception e){return "null";}
        }
        @JavascriptInterface public void message(String kind,String encoded,String id){
            if(restricted)return;
            ui.post(()->{
                WebView target="content".equals(kind)?chat:cloud;
                if(!"content".equals(kind)&&!"cloud".equals(kind))return;
                inFlight.put(id,popup);
                if(target==cloud&&!cloudReady){
                    deliver(id,"{\"ok\":false,\"error\":\"Cloud chua san sang\"}");
                } else {
                    js(target,"window.__crkReceive&&window.__crkReceive("+JSONObject.quote(encoded)+","+JSONObject.quote(id)+");");
                }
            });
        }
        @JavascriptInterface public void reply(String id,String json){
            if(restricted){ // ChatGPT can only reply to an existing content inspection request.
                ui.post(()->{if(inFlight.containsKey(id))deliver(id,json);});
            }else ui.post(()->deliver(id,json));
        }
        private void deliver(String id,String json){
            WebView dest=inFlight.remove(id);if(dest==null)return;
            js(dest,"window.__crkResult&&window.__crkResult("+JSONObject.quote(id)+","+JSONObject.quote(json)+");");
        }
        @JavascriptInterface public void setAlarm(String name,String options){if(!restricted)ui.post(()->alarmSet(name,options));}
        @JavascriptInterface public String getAlarm(String name){
            Alarm a=alarms.get(name);if(a==null)return "null";
            return "{\"name\":"+JSONObject.quote(name)+",\"scheduledTime\":"+a.due+"}";
        }
        @JavascriptInterface public boolean clearAlarm(String name){if(restricted)return false;ui.post(()->alarmClear(name));return true;}
        @JavascriptInterface public void copyText(String text){if(restricted)return;
            ui.post(()->{ClipboardManager c=(ClipboardManager)getSystemService(Context.CLIPBOARD_SERVICE);
                c.setPrimaryClip(ClipData.newPlainText("CRK RAW",text));
            });
        }
        @JavascriptInterface public void saveFile(String filename,String base64){if(restricted)return;
            new Thread(()->{
                try{
                    String safe=filename.replaceAll("[^a-zA-Z0-9._-]","_");
                    if(safe.length()>140)safe=safe.substring(safe.length()-140);
                    byte[] data=Base64.decode(base64,Base64.DEFAULT);
                    ContentValues row=new ContentValues();row.put(MediaStore.Downloads.DISPLAY_NAME,safe);
                    row.put(MediaStore.Downloads.MIME_TYPE,safe.endsWith(".json")?"application/json":safe.endsWith(".gz")?"application/gzip":"text/plain");
                    row.put(MediaStore.Downloads.RELATIVE_PATH,Environment.DIRECTORY_DOWNLOADS+"/CRK_RAW_Keeper");
                    Uri uri=getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI,row);
                    if(uri==null)throw new IllegalStateException("MediaStore insert failed");
                    try(OutputStream out=getContentResolver().openOutputStream(uri)){if(out==null)throw new IllegalStateException("Missing stream");out.write(data);}
                    ui.post(()->Toast.makeText(MainActivity.this,"Đã lưu: Downloads/CRK_RAW_Keeper/"+safe,Toast.LENGTH_LONG).show());
                }catch(Exception e){Log.e(TAG,"download",e);ui.post(()->Toast.makeText(MainActivity.this,"Xuất tệp thất bại: "+e.getMessage(),Toast.LENGTH_LONG).show());}
            }).start();
        }
    }
    private String load(String name)throws Exception{
        try(InputStream in=getAssets().open(name);ByteArrayOutputStream buf=new ByteArrayOutputStream()){
            byte[] bytes=new byte[8192];int count;while((count=in.read(bytes))!=-1)buf.write(bytes,0,count);
            return buf.toString("UTF-8");
        }
    }
}
