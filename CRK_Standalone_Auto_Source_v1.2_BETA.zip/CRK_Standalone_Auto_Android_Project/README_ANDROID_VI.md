# CRK Standalone + Auto UI Observer (Android BETA)

**Đúng hướng A:** CRK là một ứng dụng Android độc lập. ChatGPT chạy riêng bằng ứng dụng CHÍNH THỨC `com.openai.chatgpt`; không có WebView đăng nhập ChatGPT bên trong CRK.

## Khả năng và giới hạn

- Giao diện Campaign/Cloud/Backup của CRK gốc vẫn được giữ. Kho CRK cũ của tiện ích Chrome không tự chuyển sang APK.
- Thu thập **tự động theo thử nghiệm** bằng `AccessibilityService`, chỉ khi bạn đồng ý trong CRK và tự cấp quyền qua Cài đặt hệ thống. Cấu hình service giới hạn `com.openai.chatgpt`. Mỗi lần ChatGPT thay đổi giao diện, CRK cố gắng lấy chữ có thể đọc từ cây Accessibility đang hiển thị.
- **Chỉ là quan sát giao diện UI, chưa xác minh**. Không đọc được protocol RAW, UUID thật, message ID, toàn bộ lịch sử, bản đã xóa, nhánh Edit/Retry, nội dung chưa từng hiện trên màn hình, ảnh/âm thanh/file. Streaming hoặc tải lại UI có thể tạo nhiều snapshot; không tự nhận dạng PLAYER và GM chắc chắn.
- Nhật ký quan sát ở **SQLite riêng**, không trộn vào RAW chuẩn/Canon, không tự đẩy sang Cloud, không đọc ô nhập và không đọc app khác. Màn hình Nhật ký cho xem và xuất JSON được gắn nhãn unverified.
- Chỉ giữ 1.200 snapshot mới nhất. Bản cũ bị giới hạn vòng đời; muốn giữ lâu hãy xuất JSON định kỳ. Vì dùng Accessibility, app và hệ điều hành có thể không cung cấp nội dung chữ cần thiết.
- Tài khoản ChatGPT không được đăng nhập trong CRK.

## Bảo mật và quyền

- Android Accessibility là quyền nhạy cảm, cho phép app đọc nội dung hiển thị. Chỉ bật nếu hiểu rõ và tin tưởng mã nguồn. Sideload có thể bị hệ thống hạn chế, **không tắt Play Protect/không vượt cảnh báo bảo mật chỉ để thử**.
- Mã quan sát không gửi nội dung lên server. Giao diện Cloud riêng của CRK vẫn có thể kết nối Supabase khi bạn chủ động cấu hình, nhưng không tự lấy nhật ký quan sát.
- Không có kiểm toán bảo mật độc lập; APK debug chỉ dùng kiểm thử.
- Cài dưới tên gói MỚI `com.crk.rawkeeper.standalone`, không thay thế app CRK cũ. Dữ liệu app cũ không tự chuyển qua.

## Tạo APK trên GitHub (chỉ dùng điện thoại)

1. Đưa ZIP **CRK_Standalone_Auto_Source_v1.2_BETA.zip** lên repository `CRK-APK` (ZIP chứa thư mục `CRK_Standalone_Auto_Android_Project`).
2. Sửa file `.github/workflows/build-apk.yml` trong repository thành nội dung `CRK_Build_Standalone_Auto_GitHub.yml` cung cấp cùng ZIP.
3. Chọn Actions; workflow tạo APK debug. Tải artifact `CRK-Standalone-UI-Observer-APK`, giải nén APK để cài trên điện thoại.
4. Nếu điện thoại chặn cài đặt/quyền Accessibility bằng cảnh báo bảo mật, dừng lại. Không tắt cơ chế bảo vệ.
5. Khi app cài thành công, mở CRK -> bật thử nghiệm ghi nhận -> tự bật quyền Trợ năng ở Cài đặt nếu thấy phù hợp -> dùng app ChatGPT chính thức -> trở lại màn hình Nhật ký và kiểm tra bản quan sát.

**Lưu ý:** APK có thể biên dịch thành công nhưng chưa được chạy thử trên thiết bị thực. Mọi tính năng thu thập phụ thuộc giao diện Accessibility hiện tại của app ChatGPT.
