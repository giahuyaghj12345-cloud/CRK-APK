package com.crk.rawkeeper;

import android.accessibilityservice.AccessibilityService;
import android.os.Handler;
import android.os.Looper;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import java.util.ArrayDeque;

/** Best-effort capture of text visible in the OFFICIAL ChatGPT app, only by explicit opt-in. */
public final class ChatGPTObserverService extends AccessibilityService {
    private static final String OFFICIAL_CHATGPT_PACKAGE="com.openai.chatgpt";
    private final Handler ui=new Handler(Looper.getMainLooper());
    private final Runnable snapshot=new Runnable(){@Override public void run(){captureVisible();}};
    private ObservationStore log;
    @Override public void onServiceConnected(){ super.onServiceConnected(); log=new ObservationStore(this); }
    @Override public void onAccessibilityEvent(AccessibilityEvent event) {
        if(event==null || event.getPackageName()==null || !OFFICIAL_CHATGPT_PACKAGE.contentEquals(event.getPackageName()))return;
        if(!getSharedPreferences("observer_settings",MODE_PRIVATE).getBoolean("capture_opt_in",false))return;
        int type=event.getEventType();
        if(type!=AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED && type!=AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED && type!=AccessibilityEvent.TYPE_VIEW_SCROLLED)return;
        ui.removeCallbacks(snapshot);
        ui.postDelayed(snapshot,1600);
    }
    private void captureVisible() {
        if(!getSharedPreferences("observer_settings",MODE_PRIVATE).getBoolean("capture_opt_in",false))return;
        AccessibilityNodeInfo root=getRootInActiveWindow();
        if(root==null || root.getPackageName()==null || !OFFICIAL_CHATGPT_PACKAGE.contentEquals(root.getPackageName()))return;
        ArrayDeque<AccessibilityNodeInfo> stack=new ArrayDeque<>();stack.push(root);
        StringBuilder visible=new StringBuilder();
        String previous="";
        int examined=0;
        while(!stack.isEmpty() && examined++<800 && visible.length()<30000) {
            AccessibilityNodeInfo node=stack.pop();
            // Protect text typed into fields; never record passwords, drafts or input composition.
            if(node.isPassword() || node.isEditable())continue;
            CharSequence name=node.getClassName();
            if(name!=null && (name.toString().contains("EditText") || name.toString().contains("TextField")))continue;
            CharSequence value=node.getText();
            if(value!=null) {
                String t=value.toString().replace('\u00a0',' ').trim();
                if(t.length()>0 && !t.equals(previous)) {
                    if(t.length()>3500)t=t.substring(0,3500);
                    visible.append(t).append('\n');previous=t;
                }
            }
            // Preserve accessibility traversal order as much as practical.
            for(int k=node.getChildCount()-1;k>=0;k--) {
                AccessibilityNodeInfo child=node.getChild(k);
                if(child!=null)stack.push(child);
            }
        }
        if(log==null)log=new ObservationStore(this);
        log.save(visible.toString());
    }
    @Override public void onInterrupt() {ui.removeCallbacks(snapshot);}
    @Override public void onDestroy(){ui.removeCallbacks(snapshot);if(log!=null)log.close();super.onDestroy();}
}
