package com.crk.rawkeeper;

import android.content.Context;
import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import org.json.JSONArray;
import org.json.JSONObject;
import java.security.MessageDigest;
import java.nio.charset.StandardCharsets;

/** Separate, local-only UI observation log. Never merges into the CRK verified RAW ledger. */
final class ObservationStore extends SQLiteOpenHelper {
    private static final String TABLE = "ui_observations";
    ObservationStore(Context context) { super(context, "crk_ui_observations_v1.db", null, 1); }
    @Override public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE "+TABLE+" (id INTEGER PRIMARY KEY AUTOINCREMENT, utc_ms INTEGER NOT NULL, fingerprint TEXT NOT NULL, body TEXT NOT NULL, source TEXT NOT NULL)");
    }
    @Override public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) { }
    private String hash(String input) throws Exception {
        byte[] bytes=MessageDigest.getInstance("SHA-256").digest(input.getBytes(StandardCharsets.UTF_8));
        StringBuilder b=new StringBuilder();
        for (byte x:bytes) b.append(String.format(java.util.Locale.ROOT,"%02x",x & 0xff));
        return b.toString();
    }
    synchronized boolean save(String content) {
        if(content==null) return false;
        String text=content.trim();
        if(text.length()<20) return false;
        if(text.length()>30000) text=text.substring(0,30000);
        try {
            String fingerprint=hash(text);
            SQLiteDatabase db=getWritableDatabase();
            try(Cursor c=db.rawQuery("SELECT fingerprint FROM "+TABLE+" ORDER BY id DESC LIMIT 1",null)) {
                if(c.moveToFirst() && fingerprint.equals(c.getString(0))) return false;
            }
            ContentValues record=new ContentValues();
            record.put("utc_ms",System.currentTimeMillis());
            record.put("fingerprint",fingerprint);
            record.put("body",text);
            record.put("source","com.openai.chatgpt / accessibility-visible / unverified");
            db.insertOrThrow(TABLE,null,record);
            db.execSQL("DELETE FROM "+TABLE+" WHERE id NOT IN (SELECT id FROM "+TABLE+" ORDER BY id DESC LIMIT 1200)");
            return true;
        } catch (Exception e) {
            android.util.Log.e("CRKObserver", "Store failed",e); return false;
        }
    }
    synchronized int count() {
        try(Cursor c=getReadableDatabase().rawQuery("SELECT COUNT(*) FROM "+TABLE,null)) {return c.moveToFirst()?c.getInt(0):0;}
    }
    synchronized String recentSummary(int limit) {
        StringBuilder s=new StringBuilder();
        try(Cursor c=getReadableDatabase().rawQuery("SELECT utc_ms,body FROM "+TABLE+" ORDER BY id DESC LIMIT " + Math.min(Math.max(limit,1),30),null)) {
            while(c.moveToNext()) {
                String when=android.text.format.DateFormat.format("dd/MM HH:mm:ss",c.getLong(0)).toString();
                String body=c.getString(1); if(body.length()>1200)body=body.substring(0,1200)+"\n[...]";
                s.append("\n────────────\n").append(when).append(" | UI CHƯA XÁC MINH\n").append(body).append('\n');
            }
        }
        return s.length()==0?"Chưa có quan sát. Hãy bật quyền rồi mở app ChatGPT chính thức.":s.toString();
    }
    synchronized String exportJson() throws Exception {
        JSONArray data=new JSONArray();
        try(Cursor c=getReadableDatabase().rawQuery("SELECT utc_ms,fingerprint,body,source FROM "+TABLE+" ORDER BY id ASC",null)) {
            while(c.moveToNext()) data.put(new JSONObject()
                .put("observed_at_unix_ms",c.getLong(0))
                .put("sha256",c.getString(1))
                .put("visible_text",c.getString(2))
                .put("source",c.getString(3)));
        }
        return new JSONObject()
            .put("format","CRK_UI_OBSERVATIONS_V1")
            .put("verified_raw",false)
            .put("warning","Only Android accessibility-visible UI; not ChatGPT protocol RAW, UUID, chat history, or verified Edit/Retry.")
            .put("items",data).toString(2);
    }
    synchronized void erase() {getWritableDatabase().delete(TABLE,null,null);}
}
