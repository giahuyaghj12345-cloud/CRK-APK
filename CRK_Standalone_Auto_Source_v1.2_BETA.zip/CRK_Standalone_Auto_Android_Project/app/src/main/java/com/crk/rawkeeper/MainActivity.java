package com.crk.rawkeeper;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.provider.MediaStore;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.ValueCallback;
import android.util.Base64;
import android.util.Log;
import org.json.JSONObject;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.HashMap;
import java.util.Map;

/** CRK standalone. The official ChatGPT Android application is NEVER embedded in a WebView. */
public class MainActivity extends Activity {
    private static final String ASSET_HOST="appassets.androidplatform.net";
    private static final String PREFIX="https://appassets.androidplatform.net/assets/";
    private static final int PICK_FILE=4904;
    private final Handler ui=new Handler(Looper.getMainLooper());
    private final Map<String,Alarm> alarms=new HashMap<>();
    private final Map<String,WebView> inFlight=new HashMap<>();
    private WebView popup,cloud;
    private FrameLayout frame;
    private ScrollView observationPage;
    private TextView status, observationText;
    private Button captureButton;
    private CRKStore store;
    private ObservationStore observations;
    private boolean cloudReady=false;
    private ValueCallback<Uri[]> uploadCallback;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        store=new CRKStore(this); observations=new ObservationStore(this);
        getWindow().setStatusBarColor(Color.rgb(17,27,42));
        getWindow().setNavigationBarColor(Color.rgb(17,27,42));
        LinearLayout page=new LinearLayout(this);page.setOrientation(LinearLayout.VERTICAL);
        page.setBackgroundColor(Color.rgb(11,17,29));
        status=new TextView(this);status.setTextColor(Color.WHITE);status.setTextSize(12);
        status.setBackgroundColor(Color.rgb(25,47,69));status.setPadding(dp(12),dp(10),dp(12),dp(10));
        page.addView(status,new LinearLayout.LayoutParams(-1,-2));
        LinearLayout tools=new LinearLayout(this); tools.setOrientation(LinearLayout.HORIZONTAL);tools.setBackgroundColor(Color.rgb(17,27,42));
        tools.addView(button("📦 CRK",()->showCRK()),new LinearLayout.LayoutParams(0,dp(51),1));
        tools.addView(button("👁 Nhật ký",()->showObservations()),new LinearLayout.LayoutParams(0,dp(51),1));
        tools.addView(button("ChatGPT ↗",()->openOfficialChatGPT()),new LinearLayout.LayoutParams(0,dp(51),1));
        page.addView(tools);
        captureButton=button("",()->toggleCapture());
        page.addView(captureButton,new LinearLayout.LayoutParams(-1,dp(44)));
        frame=new FrameLayout(this);page.addView(frame,new LinearLayout.LayoutParams(-1,0,1));

        cloud=web();cloud.addJavascriptInterface(new Bridge(),"AndroidCRK");cloud.setWebViewClient(assetClient(true));
        frame.addView(cloud,new FrameLayout.LayoutParams(dp(1),dp(1),Gravity.TOP|Gravity.LEFT));
        cloud.setAlpha(0.01f);
        popup=web();popup.addJavascriptInterface(new Bridge(),"AndroidCRK");
        popup.setWebViewClient(assetClient(false));popup.setWebChromeClient(pickerClient());
        frame.addView(popup,new FrameLayout.LayoutParams(-1,-1));

        observationPage=new ScrollView(this);observationPage.setFillViewport(true);
        LinearLayout logContents=new LinearLayout(this);logContents.setOrientation(LinearLayout.VERTICAL);
        logContents.setPadding(dp(13),dp(13),dp(13),dp(13));
        TextView title=new TextView(this);title.setText("Nhật ký UI của ChatGPT (chưa xác minh RAW)");
        title.setTextSize(19);title.setTextColor(Color.WHITE);logContents.addView(title);
        TextView explain=new TextView(this); explain.setTextColor(Color.rgb(204,216,238));
        explain.setText("Chỉ đọc nội dung hiển thị khi app ChatGPT chính thức đang mở, nếu Android cho phép. Không xác định PLAYER/GM, UUID, Edit/Retry hoặc nhánh canon. Dữ liệu chỉ lưu trên máy; không tự đồng bộ Cloud.");
        explain.setPadding(0,dp(8),0,dp(8));logContents.addView(explain);
        logContents.addView(button("⟳ Tải lại nhật ký",()->refreshObservations()));
        logContents.addView(button("⬇ Xuất JSON quan sát",()->exportObservations()));
        logContents.addView(button("🗑 Xóa nhật ký quan sát",()->confirmErase()));
        observationText=new TextView(this);observationText.setTextIsSelectable(true);
        observationText.setTextColor(Color.WHITE);observationText.setTextSize(13);
        observationText.setPadding(0,dp(12),0,dp(60));logContents.addView(observationText);
        observationPage.addView(logContents);
        frame.addView(observationPage,new FrameLayout.LayoutParams(-1,-1));
        cloud.loadUrl(PREFIX+"cloud-host.html");
        popup.loadUrl(PREFIX+"popup.html");
        showCRK();setContentView(page);updateStatus();
    }
    private int dp(int n){return (int)(n*getResources().getDisplayMetrics().density+0.5f);}
    private Button button(String text,Runnable callback){Button b=new Button(this);b.setAllCaps(false);b.setText(text);b.setTextSize(12);
        b.setTextColor(Color.WHITE);b.setBackgroundColor(Color.rgb(36,60,88));b.setOnClickListener(v->callback.run());return b;}
    private void showCRK(){popup.setVisibility(View.VISIBLE);observationPage.setVisibility(View.GONE);updateStatus();}
    private void showObservations(){popup.setVisibility(View.GONE);observationPage.setVisibility(View.VISIBLE);refreshObservations();updateStatus();}
    private void refreshObservations(){observationText.setText("Đã lưu "+observations.count()+" lần chụp UI.\n"+observations.recentSummary(12));}
    private SharedPreferences prefs(){return getSharedPreferences("observer_settings",MODE_PRIVATE);}
    private boolean optIn(){return prefs().getBoolean("capture_opt_in",false);}
    private boolean isServiceEnabled(){
        String enabled=Settings.Secure.getString(getContentResolver(),Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
        return enabled!=null && enabled.contains(getPackageName()+"/com.crk.rawkeeper.ChatGPTObserverService");
    }
    private void updateStatus(){
        boolean enabled=optIn(); boolean service=isServiceEnabled();
        status.setText("CRK độc lập • UI quan sát: "+(enabled?(service?"ĐANG BẬT":"CHƯA CẤP QUYỀN"):"ĐÃ TẮT")+" • "+observations.count()+" snapshot");
        captureButton.setText(enabled?"⏹ Dừng tự động ghi UI":"⚙ Bật thử nghiệm quan sát UI ChatGPT");
    }
    private void toggleCapture(){
        if(optIn()){prefs().edit().putBoolean("capture_opt_in",false).apply();updateStatus();return;}
        new AlertDialog.Builder(this).setTitle("Quyền đọc nội dung trên màn hình")
            .setMessage("Thử nghiệm: CRK chỉ tiếp nhận các sự kiện của app ChatGPT chính thức (com.openai.chatgpt). Nội dung chữ được Android cho phép đọc sẽ lưu trong nhật ký RIÊNG trên máy. Không đọc ô nhập, không lấy mật khẩu, không tự gửi Cloud. Đây KHÔNG PHẢI RAW gốc và không thể bảo đảm đủ lịch sử hay Edit/Retry. Quyền Accessibility rất nhạy cảm. Chỉ bật nếu bạn hiểu và tin tưởng mã nguồn.")
            .setNegativeButton("Hủy",(d,w)->{})
            .setPositiveButton("Tôi đồng ý",(d,w)->{
                prefs().edit().putBoolean("capture_opt_in",true).apply();updateStatus();
                if(!isServiceEnabled()) {
                    new AlertDialog.Builder(this).setMessage("Android sẽ mở Cài đặt Trợ năng. CRK không thể tự cấp quyền. Nếu điện thoại chặn quyền vì lý do bảo mật, đừng tắt bảo vệ chỉ để dùng thử.")
                        .setPositiveButton("Mở cài đặt",(x,y)->startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)))
                        .setNegativeButton("Để sau",(x,y)->{}).show();
                }
            }).show();
    }
    private void openOfficialChatGPT(){
        try { Intent i=getPackageManager().getLaunchIntentForPackage("com.openai.chatgpt");
            if(i!=null){startActivity(i);return;}
            startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse("https://play.google.com/store/apps/details?id=com.openai.chatgpt")));
        }catch(Exception e){Toast.makeText(this,"Không mở được ChatGPT chính thức",Toast.LENGTH_LONG).show();}
    }
    private void confirmErase(){new AlertDialog.Builder(this).setTitle("Xóa nhật ký quan sát UI?")
        .setMessage("Không đụng tới Campaign, RAW khác hoặc dữ liệu của app ChatGPT.")
        .setNegativeButton("Hủy",(d,w)->{}).setPositiveButton("Xóa",(d,w)->{observations.erase();refreshObservations();updateStatus();}).show();}
    private void exportObservations(){
        new Thread(()->{
            try {
                String content=observations.exportJson();String name="crk-ui-observations-"+System.currentTimeMillis()+".json";
                saveDownloads(name,content.getBytes(java.nio.charset.StandardCharsets.UTF_8));
                ui.post(()->Toast.makeText(this,"Đã lưu Downloads/CRK_RAW_Keeper/"+name,Toast.LENGTH_LONG).show());
            }catch(Exception e){ui.post(()->Toast.makeText(this,"Không xuất được JSON: "+e.getMessage(),Toast.LENGTH_LONG).show());}
        }).start();
    }
    private void saveDownloads(String name,byte[] data)throws Exception{
        ContentValues row=new ContentValues();row.put(MediaStore.Downloads.DISPLAY_NAME,name);
        row.put(MediaStore.Downloads.MIME_TYPE,name.endsWith(".json")?"application/json":"text/plain");
        row.put(MediaStore.Downloads.RELATIVE_PATH,Environment.DIRECTORY_DOWNLOADS+"/CRK_RAW_Keeper");
        Uri uri=getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI,row);
        if(uri==null)throw new IllegalStateException("Không tạo được tệp");
        try(OutputStream out=getContentResolver().openOutputStream(uri)){
            if(out==null)throw new IllegalStateException("Không mở được tệp");out.write(data);
        }
    }
    private WebView web(){
        WebView w=new WebView(this); WebSettings s=w.getSettings();
        s.setJavaScriptEnabled(true);s.setDomStorageEnabled(true);s.setDatabaseEnabled(true);
        s.setAllowFileAccess(false);s.setAllowContentAccess(true);
        s.setJavaScriptCanOpenWindowsAutomatically(false);s.setSupportMultipleWindows(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        if(Build.VERSION.SDK_INT>=26)s.setSafeBrowsingEnabled(true);
        w.setBackgroundColor(Color.rgb(11,17,29));return w;
    }
    private WebViewClient assetClient(boolean worker){return new WebViewClient(){
        @Override public WebResourceResponse shouldInterceptRequest(WebView v,WebResourceRequest req){
            Uri uri=req.getUrl();
            if(!"https".equals(uri.getScheme())||!ASSET_HOST.equals(uri.getHost())||!uri.getPath().startsWith("/assets/"))return null;
            String path=uri.getPath().substring("/assets/".length());
            if(!path.matches("[A-Za-z0-9._-]+")||path.startsWith("."))return null;
            try { InputStream in=getAssets().open(path);
                String mime=path.endsWith(".html")?"text/html":path.endsWith(".css")?"text/css":path.endsWith(".js")?"application/javascript":"application/octet-stream";
                return new WebResourceResponse(mime,"UTF-8",in);
            }catch(Exception e){return null;}
        }
        @Override public boolean shouldOverrideUrlLoading(WebView v,WebResourceRequest req){
            Uri url=req.getUrl();
            if("https".equals(url.getScheme()) && ASSET_HOST.equals(url.getHost()) && url.getPath().startsWith("/assets/"))return false;
            if("https".equals(url.getScheme())){
                try{startActivity(new Intent(Intent.ACTION_VIEW,url));}catch(ActivityNotFoundException e){} }
            return true;
        }
        @Override public void onPageFinished(WebView v,String url){if(worker)cloudReady=true;}
    };}
    private WebChromeClient pickerClient(){return new WebChromeClient(){
        @Override public boolean onShowFileChooser(WebView v,ValueCallback<Uri[]> cb,FileChooserParams p){
            if(uploadCallback!=null)uploadCallback.onReceiveValue(null);
            uploadCallback=cb;
            try{Intent in=new Intent(Intent.ACTION_OPEN_DOCUMENT);in.setType("*/*");in.addCategory(Intent.CATEGORY_OPENABLE);
                in.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);startActivityForResult(in,PICK_FILE);return true;
            }catch(Exception e){uploadCallback=null;return false;}
        }
    };}
    @Override protected void onActivityResult(int req,int result,Intent data){super.onActivityResult(req,result,data);
        if(req==PICK_FILE && uploadCallback!=null){Uri[] value=(result==RESULT_OK&&data!=null&&data.getData()!=null)?new Uri[]{data.getData()}:null;
            uploadCallback.onReceiveValue(value);uploadCallback=null;}
    }
    private void js(WebView web,String expression){if(web!=null)ui.post(()->web.evaluateJavascript(expression,null));}
    private void publish(JSONObject changes){if(changes.length()==0)return;
        String script="window.__crkStorageChanged&&window.__crkStorageChanged("+JSONObject.quote(changes.toString())+");";
        js(popup,script);js(cloud,script);
    }
    private static final class Alarm {
        final long due;final Runnable callback;
        Alarm(long due,Runnable callback){this.due=due;this.callback=callback;}
    }
    private void alarmSet(String name,String encoded){alarmClear(name);
        try{
            JSONObject options=new JSONObject(encoded);
            double first=options.optDouble("delayInMinutes",options.optDouble("periodInMinutes",1));
            long delay=Math.max(1000L,(long)(Math.max(0.02,first)*60000));
            long repeat=options.has("periodInMinutes")?Math.max(60000L,(long)(options.optDouble("periodInMinutes")*60000)):0;
            Runnable callback=new Runnable(){@Override public void run(){
                if(!alarms.containsKey(name))return;
                js(cloud,"window.__crkFireAlarm&&window.__crkFireAlarm("+JSONObject.quote(name)+");");
                if(repeat>0)ui.postDelayed(this,repeat);else alarms.remove(name);
            }};
            alarms.put(name,new Alarm(System.currentTimeMillis()+delay,callback));ui.postDelayed(callback,delay);
        }catch(Exception e){Log.w("CRKAndroid","alarm",e);}
    }
    private void alarmClear(String name){Alarm a=alarms.remove(name);if(a!=null)ui.removeCallbacks(a.callback);}
    @Override protected void onResume(){super.onResume();if(status!=null)updateStatus();}
    @Override public void onBackPressed(){if(observationPage.getVisibility()==View.VISIBLE)showCRK();else super.onBackPressed();}
    @Override protected void onDestroy(){for(Alarm a:alarms.values())ui.removeCallbacks(a.callback);alarms.clear();
        if(popup!=null)popup.destroy();if(cloud!=null)cloud.destroy();
        store.close();observations.close();super.onDestroy();}
    private final class Bridge {
        @JavascriptInterface public String getStore(String keys){return store.get(keys,false).toString();}
        @JavascriptInterface public void setStore(String encoded){try{publish(store.set(encoded,false));}catch(Exception e){Log.w("CRKAndroid","set",e);}}
        @JavascriptInterface public void removeStore(String encoded){try{publish(store.remove(encoded,false));}catch(Exception e){Log.w("CRKAndroid","remove",e);}}
        @JavascriptInterface public void clearStore(){try{publish(store.clear(false));}catch(Exception e){Log.w("CRKAndroid","clear",e);}}
        @JavascriptInterface public String getActiveTab(){return "null";}
        @JavascriptInterface public void message(String kind,String encoded,String id){ui.post(()->{
            if(!"cloud".equals(kind)){
                js(popup,"window.__crkResult&&window.__crkResult("+JSONObject.quote(id)+","+
                    JSONObject.quote("{\"ok\":false,\"error\":\"App ChatGPT chính thức không cung cấp Chrome DOM bridge\"}")+");");
                return;
            }
            inFlight.put(id,popup);
            if(!cloudReady){deliver(id,"{\"ok\":false,\"error\":\"Cloud chưa sẵn sàng\"}");return;}
            js(cloud,"window.__crkReceive&&window.__crkReceive("+JSONObject.quote(encoded)+","+JSONObject.quote(id)+");");
        });}
        @JavascriptInterface public void reply(String id,String json){ui.post(()->deliver(id,json));}
        @JavascriptInterface public void setAlarm(String name,String options){ui.post(()->alarmSet(name,options));}
        @JavascriptInterface public String getAlarm(String name){Alarm a=alarms.get(name);
            return a==null?"null":"{\"name\":"+JSONObject.quote(name)+",\"scheduledTime\":"+a.due+"}";}
        @JavascriptInterface public boolean clearAlarm(String name){ui.post(()->alarmClear(name));return true;}
        @JavascriptInterface public void copyText(String text){ui.post(()->{
            ClipboardManager clipboard=(ClipboardManager)getSystemService(Context.CLIPBOARD_SERVICE);
            clipboard.setPrimaryClip(ClipData.newPlainText("CRK RAW",text));
        });}
        @JavascriptInterface public void saveFile(String filename,String base64){new Thread(()->{
            try{
                String safe=filename.replaceAll("[^a-zA-Z0-9._-]","_");
                if(safe.length()>140)safe=safe.substring(safe.length()-140);
                final String exported=safe;
                saveDownloads(exported,Base64.decode(base64,Base64.DEFAULT));
                ui.post(()->Toast.makeText(MainActivity.this,"Đã lưu Downloads/CRK_RAW_Keeper/"+exported,Toast.LENGTH_LONG).show());
            }catch(Exception e){ui.post(()->Toast.makeText(MainActivity.this,"Xuất tệp thất bại: "+e.getMessage(),Toast.LENGTH_LONG).show());}
        }).start();}
    }
    private void deliver(String id,String json){WebView target=inFlight.remove(id);if(target!=null)js(target,
        "window.__crkResult&&window.__crkResult("+JSONObject.quote(id)+","+JSONObject.quote(json)+");");}
}
